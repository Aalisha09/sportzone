<?php

session_start();

require_once "../includes/functions.php";


/*
|--------------------------------------------------------------------------
| ADMIN LOGIN CHECK
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['admin_id'])) {

    header("Location: login.php");
    exit();

}


/*
|--------------------------------------------------------------------------
| DATABASE CONNECTION
|--------------------------------------------------------------------------
*/

global $conn;

$message = "";
$error = "";


/*
|--------------------------------------------------------------------------
| DELETE TEAM
|--------------------------------------------------------------------------
*/

if (isset($_GET['delete'])) {

    $team_id = intval($_GET['delete']);

    if ($team_id > 0) {

        $stmt = mysqli_prepare(
            $conn,
            "DELETE FROM teams WHERE id = ?"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "i",
            $team_id
        );

        if (mysqli_stmt_execute($stmt)) {

            header("Location: manage_teams.php?msg=deleted");
            exit();

        } else {

            $error = "Unable to delete team.";

        }

        mysqli_stmt_close($stmt);
    }
}


/*
|--------------------------------------------------------------------------
| ADD TEAM
|--------------------------------------------------------------------------
*/

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    && isset($_POST['add_team'])
) {

    $team_name = trim($_POST['team_name']);
    $sport     = trim($_POST['sport']);
    $city      = trim($_POST['city']);
    $coach     = trim($_POST['coach']);
    $founded   = trim($_POST['founded']);


    if (
        empty($team_name)
        || empty($sport)
    ) {

        $error = "Team name and sport are required.";

    } else {

        $stmt = mysqli_prepare(
            $conn,
            "INSERT INTO teams
            (team_name, sport, city, coach, founded)
            VALUES (?, ?, ?, ?, ?)"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "ssssi",
            $team_name,
            $sport,
            $city,
            $coach,
            $founded
        );


        if (mysqli_stmt_execute($stmt)) {

            header("Location: manage_teams.php?msg=added");
            exit();

        } else {

            $error = "Unable to add team.";

        }

        mysqli_stmt_close($stmt);
    }
}


/*
|--------------------------------------------------------------------------
| FETCH TEAMS
|--------------------------------------------------------------------------
*/

$result = mysqli_query(
    $conn,
    "SELECT *
     FROM teams
     ORDER BY id DESC"
);

?>


<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Manage Teams | SportZone Admin
    </title>


    <!-- FONT AWESOME -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >


    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }


        body {

            font-family: Arial, sans-serif;

            background: #f4f6f9;

            color: #1f2937;

        }


        /* ================= HEADER ================= */

        .admin-header {

            background: #111827;

            color: white;

            padding: 18px 30px;

            display: flex;

            justify-content: space-between;

            align-items: center;

        }


        .admin-header h2 {

            font-size: 22px;

        }


        .admin-header a {

            color: white;

            text-decoration: none;

            margin-left: 20px;

        }


        .admin-header a:hover {

            color: #60a5fa;

        }


        /* ================= CONTAINER ================= */

        .container {

            width: 95%;

            max-width: 1400px;

            margin: 30px auto;

        }


        /* ================= TITLE ================= */

        .page-title {

            display: flex;

            justify-content: space-between;

            align-items: center;

            margin-bottom: 25px;

        }


        .page-title h1 {

            font-size: 28px;

        }


        /* ================= CARD ================= */

        .card {

            background: white;

            padding: 25px;

            border-radius: 12px;

            box-shadow:
                0 3px 15px rgba(0,0,0,0.08);

            margin-bottom: 25px;

        }


        .card h2 {

            margin-bottom: 20px;

        }


        /* ================= FORM ================= */

        .form-grid {

            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            gap: 18px;

        }


        .form-group {

            display: flex;

            flex-direction: column;

        }


        .form-group label {

            font-size: 14px;

            font-weight: bold;

            margin-bottom: 7px;

        }


        .form-group input,
        .form-group select {

            padding: 11px;

            border: 1px solid #d1d5db;

            border-radius: 7px;

            font-size: 14px;

            outline: none;

        }


        .form-group input:focus,
        .form-group select:focus {

            border-color: #2563eb;

        }


        .full-width {

            grid-column: 1 / -1;

        }


        /* ================= BUTTON ================= */

        .btn {

            border: none;

            padding: 10px 16px;

            border-radius: 7px;

            cursor: pointer;

            text-decoration: none;

            display: inline-block;

            font-size: 14px;

        }


        .btn-primary {

            background: #2563eb;

            color: white;

        }


        .btn-success {

            background: #16a34a;

            color: white;

        }


        .btn-danger {

            background: #dc2626;

            color: white;

        }


        .btn-warning {

            background: #f59e0b;

            color: white;

        }


        .btn-secondary {

            background: #374151;

            color: white;

        }


        .btn:hover {

            opacity: 0.9;

        }


        /* ================= TABLE ================= */

        .table-wrapper {

            overflow-x: auto;

        }


        table {

            width: 100%;

            border-collapse: collapse;

        }


        th {

            background: #111827;

            color: white;

            padding: 14px;

            text-align: center;

        }


        td {

            padding: 14px;

            border-bottom:
                1px solid #e5e7eb;

            text-align: center;

        }


        tr:hover {

            background: #f9fafb;

        }


        /* ================= BADGE ================= */

        .sport-badge {

            background: #dbeafe;

            color: #1d4ed8;

            padding: 5px 10px;

            border-radius: 20px;

            font-size: 12px;

            font-weight: bold;

        }


        /* ================= ACTIONS ================= */

        .actions {

            display: flex;

            justify-content: center;

            gap: 7px;

        }


        /* ================= MESSAGE ================= */

        .message {

            padding: 13px 16px;

            border-radius: 7px;

            margin-bottom: 20px;

        }


        .success {

            background: #dcfce7;

            color: #166534;

        }


        .error {

            background: #fee2e2;

            color: #991b1b;

        }


        /* ================= RESPONSIVE ================= */

        @media (max-width: 900px) {

            .form-grid {

                grid-template-columns: 1fr 1fr;

            }

        }


        @media (max-width: 600px) {

            .form-grid {

                grid-template-columns: 1fr;

            }


            .page-title {

                flex-direction: column;

                align-items: flex-start;

                gap: 15px;

            }


            .admin-header {

                flex-direction: column;

                gap: 15px;

            }

        }

    </style>

</head>


<body>


<!-- ================= ADMIN HEADER ================= -->

<header class="admin-header">


    <h2>

        <i class="fa-solid fa-futbol"></i>

        SportZone Admin

    </h2>


    <div>

        <a href="dashboard.php">

            <i class="fa-solid fa-gauge"></i>

            Dashboard

        </a>


        <a href="manage_matches.php">

            <i class="fa-solid fa-calendar-days"></i>

            Matches

        </a>


        <a href="logout.php">

            <i class="fa-solid fa-right-from-bracket"></i>

            Logout

        </a>

    </div>


</header>



<!-- ================= MAIN CONTAINER ================= -->

<div class="container">


    <!-- ================= TITLE ================= -->

    <div class="page-title">


        <h1>

            <i class="fa-solid fa-users"></i>

            Manage Teams

        </h1>


        <a
            href="dashboard.php"
            class="btn btn-secondary"
        >

            <i class="fa-solid fa-arrow-left"></i>

            Dashboard

        </a>


    </div>



    <!-- ================= MESSAGES ================= -->

    <?php if (isset($_GET['msg']) && $_GET['msg'] === 'added'): ?>

        <div class="message success">

            <i class="fa-solid fa-circle-check"></i>

            Team added successfully.

        </div>

    <?php endif; ?>


    <?php if (isset($_GET['msg']) && $_GET['msg'] === 'deleted'): ?>

        <div class="message success">

            <i class="fa-solid fa-circle-check"></i>

            Team deleted successfully.

        </div>

    <?php endif; ?>


    <?php if (!empty($error)): ?>

        <div class="message error">

            <i class="fa-solid fa-circle-exclamation"></i>

            <?php
            echo htmlspecialchars($error);
            ?>

        </div>

    <?php endif; ?>



    <!-- ================= ADD TEAM ================= -->

    <div class="card">


        <h2>

            <i class="fa-solid fa-plus"></i>

            Add New Team

        </h2>


        <form method="POST">


            <div class="form-grid">


                <!-- TEAM NAME -->

                <div class="form-group">

                    <label>
                        Team Name *
                    </label>


                    <input
                        type="text"
                        name="team_name"
                        placeholder="Enter team name"
                        required
                    >

                </div>



                <!-- SPORT -->

                <div class="form-group">

                    <label>
                        Sport *
                    </label>


                    <select
                        name="sport"
                        required
                    >

                        <option value="">
                            Select Sport
                        </option>

                        <option value="Football">
                            Football
                        </option>

                        <option value="Cricket">
                            Cricket
                        </option>

                        <option value="Basketball">
                            Basketball
                        </option>

                        <option value="Volleyball">
                            Volleyball
                        </option>

                        <option value="Hockey">
                            Hockey
                        </option>

                    </select>

                </div>



                <!-- CITY -->

                <div class="form-group">

                    <label>
                        City
                    </label>


                    <input
                        type="text"
                        name="city"
                        placeholder="Enter city"
                    >

                </div>



                <!-- COACH -->

                <div class="form-group">

                    <label>
                        Coach
                    </label>


                    <input
                        type="text"
                        name="coach"
                        placeholder="Enter coach name"
                    >

                </div>



                <!-- FOUNDED -->

                <div class="form-group">

                    <label>
                        Founded Year
                    </label>


                    <input
                        type="number"
                        name="founded"
                        placeholder="2020"
                        min="1800"
                        max="2100"
                    >

                </div>



                <!-- BUTTON -->

                <div class="form-group full-width">

                    <button
                        type="submit"
                        name="add_team"
                        class="btn btn-success"
                    >

                        <i class="fa-solid fa-plus"></i>

                        Add Team

                    </button>

                </div>


            </div>

        </form>

    </div>



    <!-- ================= TEAM LIST ================= -->

    <div class="card">


        <h2>

            <i class="fa-solid fa-list"></i>

            All Teams

        </h2>


        <div class="table-wrapper">


            <table>


                <thead>

                    <tr>

                        <th>
                            ID
                        </th>

                        <th>
                            Team
                        </th>

                        <th>
                            Sport
                        </th>

                        <th>
                            City
                        </th>

                        <th>
                            Coach
                        </th>

                        <th>
                            Founded
                        </th>

                        <th>
                            Actions
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php if (
                    $result
                    && mysqli_num_rows($result) > 0
                ): ?>


                    <?php while (
                        $team = mysqli_fetch_assoc($result)
                    ): ?>


                        <tr>


                            <!-- ID -->

                            <td>

                                #
                                <?php
                                echo $team['id'];
                                ?>

                            </td>



                            <!-- TEAM -->

                            <td>

                                <strong>

                                    <?php
                                    echo htmlspecialchars(
                                        $team['team_name']
                                    );
                                    ?>

                                </strong>

                            </td>



                            <!-- SPORT -->

                            <td>

                                <span class="sport-badge">

                                    <?php
                                    echo htmlspecialchars(
                                        $team['sport']
                                    );
                                    ?>

                                </span>

                            </td>



                            <!-- CITY -->

                            <td>

                                <?php

                                echo !empty($team['city'])
                                    ? htmlspecialchars(
                                        $team['city']
                                    )
                                    : '-';

                                ?>

                            </td>



                            <!-- COACH -->

                            <td>

                                <?php

                                echo !empty($team['coach'])
                                    ? htmlspecialchars(
                                        $team['coach']
                                    )
                                    : '-';

                                ?>

                            </td>



                            <!-- FOUNDED -->

                            <td>

                                <?php

                                echo !empty($team['founded'])
                                    ? htmlspecialchars(
                                        $team['founded']
                                    )
                                    : '-';

                                ?>

                            </td>



                            <!-- ACTIONS -->

                            <td>

                                <div class="actions">


                                    <!-- EDIT -->

                                    <a
                                        href="edit_team.php?id=<?php echo $team['id']; ?>"
                                        class="btn btn-warning"
                                        title="Edit Team"
                                    >

                                        <i
                                            class="fa-solid fa-pen"
                                        ></i>

                                    </a>



                                    <!-- DELETE -->

                                    <a
                                        href="manage_teams.php?delete=<?php echo $team['id']; ?>"
                                        class="btn btn-danger"
                                        title="Delete Team"
                                        onclick="return confirm('Are you sure you want to delete this team?');"
                                    >

                                        <i
                                            class="fa-solid fa-trash"
                                        ></i>

                                    </a>


                                </div>

                            </td>


                        </tr>


                    <?php endwhile; ?>


                <?php else: ?>


                    <tr>

                        <td
                            colspan="7"
                            style="padding:30px;"
                        >

                            <i
                                class="fa-solid fa-circle-info"
                            ></i>

                            No teams found.

                        </td>

                    </tr>


                <?php endif; ?>


                </tbody>

            </table>


        </div>

    </div>


</div>


</body>

</html>
