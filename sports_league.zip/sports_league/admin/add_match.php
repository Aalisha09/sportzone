<?php
/* =========================================================
   SPORTZONE - ADD MATCH
========================================================= */

include 'includes/function.php';

$message = "";
$message_type = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $tournament = trim($_POST['tournament']);
    $sport      = trim($_POST['sport']);
    $team1      = trim($_POST['team1']);
    $team2      = trim($_POST['team2']);
    $match_date = trim($_POST['match_date']);
    $match_time = trim($_POST['match_time']);
    $venue      = trim($_POST['venue']);
    $status     = trim($_POST['status']);

    if (
        empty($tournament) ||
        empty($sport) ||
        empty($team1) ||
        empty($team2) ||
        empty($match_date) ||
        empty($match_time) ||
        empty($venue) ||
        empty($status)
    ) {

        $message = "Please fill all fields.";
        $message_type = "error";

    } elseif ($team1 == $team2) {

        $message = "Team 1 and Team 2 cannot be the same.";
        $message_type = "error";

    } else {

        $stmt = $conn->prepare("
            INSERT INTO matches
            (tournament, sport, team1, team2, match_date, match_time, venue, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "ssssssss",
            $tournament,
            $sport,
            $team1,
            $team2,
            $match_date,
            $match_time,
            $venue,
            $status
        );

        if ($stmt->execute()) {

            $message = "Match added successfully!";
            $message_type = "success";

            $_POST = [];

        } else {

            $message = "Error adding match: " . $conn->error;
            $message_type = "error";
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Add Match | SportZone</title>

    <!-- Google Font -->
    <link rel="preconnect"
          href="https://fonts.googleapis.com">

    <link rel="preconnect"
          href="https://fonts.gstatic.com"
          crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap"
          rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            background: #080c11;
            color: #ffffff;
            min-height: 100vh;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        /* =====================================================
           HEADER
        ===================================================== */

        .header {
            height: 80px;
            background: #0b1016;
            border-bottom: 1px solid #202731;

            display: flex;
            align-items: center;

            padding: 0 5%;

            justify-content: space-between;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;

            background: #ff5b25;

            border-radius: 12px;

            display: flex;
            align-items: center;
            justify-content: center;

            font-size: 21px;
        }

        .logo-text span {
            display: block;

            font-size: 10px;
            letter-spacing: 2px;
            font-weight: 700;
        }

        .logo-text strong {
            display: block;

            color: #ff5b25;

            font-size: 20px;
            font-weight: 900;
        }

        .back-btn {
            display: flex;
            align-items: center;
            gap: 8px;

            padding: 11px 18px;

            border: 1px solid #303a46;
            border-radius: 8px;

            color: #b7c0ca;

            font-size: 12px;
            font-weight: 700;

            transition: 0.3s;
        }

        .back-btn:hover {
            background: #ff5b25;
            border-color: #ff5b25;
            color: #ffffff;
        }

        /* =====================================================
           PAGE
        ===================================================== */

        .page {
            width: 90%;
            max-width: 1000px;

            margin: 55px auto 80px;
        }

        .page-heading {
            margin-bottom: 30px;
        }

        .page-heading span {
            display: inline-block;

            color: #ff5b25;

            font-size: 11px;
            font-weight: 800;

            letter-spacing: 2px;

            margin-bottom: 10px;
        }

        .page-heading h1 {
            font-size: 38px;
            font-weight: 900;

            margin-bottom: 8px;
        }

        .page-heading h1 strong {
            color: #ff5b25;
        }

        .page-heading p {
            color: #7f8b98;
            font-size: 13px;
        }

        /* =====================================================
           FORM CARD
        ===================================================== */

        .form-card {
            background: #111820;

            border: 1px solid #27313c;

            border-radius: 18px;

            padding: 35px;

            box-shadow: 0 25px 60px rgba(0,0,0,0.25);
        }

        .form-title {
            display: flex;
            align-items: center;
            gap: 12px;

            padding-bottom: 22px;
            margin-bottom: 28px;

            border-bottom: 1px solid #27313c;
        }

        .form-title-icon {
            width: 45px;
            height: 45px;

            border-radius: 11px;

            background: rgba(255,91,37,0.12);

            color: #ff5b25;

            display: flex;
            align-items: center;
            justify-content: center;

            font-size: 18px;
        }

        .form-title h2 {
            font-size: 18px;
            font-weight: 800;
        }

        .form-title p {
            color: #71808d;
            font-size: 11px;
            margin-top: 4px;
        }

        /* =====================================================
           GRID
        ===================================================== */

        .form-grid {
            display: grid;

            grid-template-columns: repeat(2, 1fr);

            gap: 22px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group.full {
            grid-column: 1 / -1;
        }

        .form-group label {
            color: #c3cad2;

            font-size: 11px;
            font-weight: 700;

            margin-bottom: 8px;
        }

        .form-group label span {
            color: #ff5b25;
        }

        .input-box {
            position: relative;
        }

        .input-box i {
            position: absolute;

            left: 15px;
            top: 50%;

            transform: translateY(-50%);

            color: #6e7a87;

            font-size: 13px;
        }

        input,
        select {

            width: 100%;

            height: 48px;

            padding: 0 15px 0 43px;

            background: #0b1016;

            border: 1px solid #2b3540;

            border-radius: 9px;

            outline: none;

            color: #ffffff;

            font-family: inherit;

            font-size: 12px;

            transition: 0.3s;
        }

        select {
            cursor: pointer;
        }

        select option {
            background: #111820;
            color: #ffffff;
        }

        input:focus,
        select:focus {

            border-color: #ff5b25;

            box-shadow:
                0 0 0 3px rgba(255,91,37,0.10);
        }

        input::placeholder {
            color: #596572;
        }

        /* =====================================================
           ALERT
        ===================================================== */

        .alert {
            padding: 14px 17px;

            border-radius: 9px;

            margin-bottom: 25px;

            font-size: 12px;
            font-weight: 600;

            display: flex;
            align-items: center;

            gap: 10px;
        }

        .alert.success {
            background: rgba(34,197,94,0.10);
            border: 1px solid rgba(34,197,94,0.25);
            color: #4ade80;
        }

        .alert.error {
            background: rgba(239,68,68,0.10);
            border: 1px solid rgba(239,68,68,0.25);
            color: #f87171;
        }

        /* =====================================================
           BUTTONS
        ===================================================== */

        .form-actions {

            display: flex;

            justify-content: flex-end;

            gap: 12px;

            margin-top: 30px;

            padding-top: 25px;

            border-top: 1px solid #27313c;
        }

        .btn {

            height: 46px;

            padding: 0 22px;

            border-radius: 8px;

            display: inline-flex;

            align-items: center;

            justify-content: center;

            gap: 8px;

            font-family: inherit;

            font-size: 12px;

            font-weight: 800;

            cursor: pointer;

            transition: 0.3s;
        }

        .cancel-btn {

            background: transparent;

            border: 1px solid #35404c;

            color: #9ba6b2;
        }

        .cancel-btn:hover {

            border-color: #ff5b25;

            color: #ff5b25;
        }

        .submit-btn {

            background: #ff5b25;

            border: 1px solid #ff5b25;

            color: #ffffff;

            box-shadow:
                0 10px 25px rgba(255,91,37,0.15);
        }

        .submit-btn:hover {

            background: #ff713f;

            transform: translateY(-2px);
        }

        /* =====================================================
           RESPONSIVE
        ===================================================== */

        @media (max-width: 700px) {

            .header {
                padding: 0 4%;
            }

            .page {
                width: 92%;
                margin-top: 35px;
            }

            .page-heading h1 {
                font-size: 30px;
            }

            .form-card {
                padding: 22px;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .form-group.full {
                grid-column: auto;
            }

            .form-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
            }

        }

    </style>

</head>

<body>

<!-- =====================================================
     HEADER
===================================================== -->

<header class="header">

    <a href="index.php" class="logo">

        <div class="logo-icon">
            <i class="fa-solid fa-trophy"></i>
        </div>

        <div class="logo-text">
            <span>LOCAL SPORTS</span>
            <strong>SPORTZONE</strong>
        </div>

    </a>

    <a href="schedule.php" class="back-btn">
        <i class="fa-solid fa-arrow-left"></i>
        Back to Schedule
    </a>

</header>


<!-- =====================================================
     MAIN
===================================================== -->

<main class="page">

    <div class="page-heading">

        <span>
            <i class="fa-solid fa-calendar-plus"></i>
            MATCH MANAGEMENT
        </span>

        <h1>
            Add <strong>New Match</strong>
        </h1>

        <p>
            Create and schedule a new match for the SportZone league.
        </p>

    </div>


    <?php if (!empty($message)): ?>

        <div class="alert <?php echo $message_type; ?>">

            <?php if ($message_type == "success"): ?>

                <i class="fa-solid fa-circle-check"></i>

            <?php else: ?>

                <i class="fa-solid fa-circle-exclamation"></i>

            <?php endif; ?>

            <?php echo htmlspecialchars($message); ?>

        </div>

    <?php endif; ?>


    <div class="form-card">

        <div class="form-title">

            <div class="form-title-icon">
                <i class="fa-solid fa-futbol"></i>
            </div>

            <div>

                <h2>Match Information</h2>

                <p>
                    Enter the details of the upcoming match.
                </p>

            </div>

        </div>


        <form method="POST">

            <div class="form-grid">


                <!-- TOURNAMENT -->

                <div class="form-group">

                    <label>
                        Tournament <span>*</span>
                    </label>

                    <div class="input-box">

                        <i class="fa-solid fa-trophy"></i>

                        <input
                            type="text"
                            name="tournament"
                            placeholder="e.g. City Championship"
                            value="<?php echo htmlspecialchars($_POST['tournament'] ?? ''); ?>"
                            required
                        >

                    </div>

                </div>


                <!-- SPORT -->

                <div class="form-group">

                    <label>
                        Sport <span>*</span>
                    </label>

                    <div class="input-box">

                        <i class="fa-solid fa-futbol"></i>

                        <select name="sport" required>

                            <option value="">
                                Select Sport
                            </option>

                            <option value="Football"
                                <?php
                                echo (($_POST['sport'] ?? '') == 'Football')
                                    ? 'selected'
                                    : '';
                                ?>>
                                Football
                            </option>

                            <option value="Cricket"
                                <?php
                                echo (($_POST['sport'] ?? '') == 'Cricket')
                                    ? 'selected'
                                    : '';
                                ?>>
                                Cricket
                            </option>

                            <option value="Basketball"
                                <?php
                                echo (($_POST['sport'] ?? '') == 'Basketball')
                                    ? 'selected'
                                    : '';
                                ?>>
                                Basketball
                            </option>

                            <option value="Tennis"
                                <?php
                                echo (($_POST['sport'] ?? '') == 'Tennis')
                                    ? 'selected'
                                    : '';
                                ?>>
                                Tennis
                            </option>

                        </select>

                    </div>

                </div>


                <!-- TEAM 1 -->

                <div class="form-group">

                    <label>
                        Team 1 <span>*</span>
                    </label>

                    <div class="input-box">

                        <i class="fa-solid fa-shield-halved"></i>

                        <input
                            type="text"
                            name="team1"
                            placeholder="e.g. Eagles FC"
                            value="<?php echo htmlspecialchars($_POST['team1'] ?? ''); ?>"
                            required
                        >

                    </div>

                </div>


                <!-- TEAM 2 -->

                <div class="form-group">

                    <label>
                        Team 2 <span>*</span>
                    </label>

                    <div class="input-box">

                        <i class="fa-solid fa-shield-halved"></i>

                        <input
                            type="text"
                            name="team2"
                            placeholder="e.g. Tigers United"
                            value="<?php echo htmlspecialchars($_POST['team2'] ?? ''); ?>"
                            required
                        >

                    </div>

                </div>


                <!-- DATE -->

                <div class="form-group">

                    <label>
                        Match Date <span>*</span>
                    </label>

                    <div class="input-box">

                        <i class="fa-solid fa-calendar"></i>

                        <input
                            type="date"
                            name="match_date"
                            value="<?php echo htmlspecialchars($_POST['match_date'] ?? ''); ?>"
                            required
                        >

                    </div>

                </div>


                <!-- TIME -->

                <div class="form-group">

                    <label>
                        Match Time <span>*</span>
                    </label>

                    <div class="input-box">

                        <i class="fa-solid fa-clock"></i>

                        <input
                            type="time"
                            name="match_time"
                            value="<?php echo htmlspecialchars($_POST['match_time'] ?? ''); ?>"
                            required
                        >

                    </div>

                </div>


                <!-- VENUE -->

                <div class="form-group">

                    <label>
                        Venue <span>*</span>
                    </label>

                    <div class="input-box">

                        <i class="fa-solid fa-location-dot"></i>

                        <input
                            type="text"
                            name="venue"
                            placeholder="e.g. City Sports Arena"
                            value="<?php echo htmlspecialchars($_POST['venue'] ?? ''); ?>"
                            required
                        >

                    </div>

                </div>


                <!-- STATUS -->

                <div class="form-group">

                    <label>
                        Match Status <span>*</span>
                    </label>

                    <div class="input-box">

                        <i class="fa-solid fa-circle-play"></i>

                        <select name="status" required>

                            <option value="">
                                Select Status
                            </option>

                            <option value="Upcoming"
                                <?php
                                echo (($_POST['status'] ?? '') == 'Upcoming')
                                    ? 'selected'
                                    : '';
                                ?>>
                                Upcoming
                            </option>

                            <option value="Live"
                                <?php
                                echo (($_POST['status'] ?? '') == 'Live')
                                    ? 'selected'
                                    : '';
                                ?>>
                                Live
                            </option>

                            <option value="Completed"
                                <?php
                                echo (($_POST['status'] ?? '') == 'Completed')
                                    ? 'selected'
                                    : '';
                                ?>>
                                Completed
                            </option>

                        </select>

                    </div>

                </div>


            </div>


            <!-- BUTTONS -->

            <div class="form-actions">

                <a href="schedule.php"
                   class="btn cancel-btn">

                    <i class="fa-solid fa-xmark"></i>

                    Cancel

                </a>


                <button type="submit"
                        class="btn submit-btn">

                    <i class="fa-solid fa-plus"></i>

                    Add Match

                </button>

            </div>

        </form>

    </div>

</main>

</body>
</html>