<?php
session_start();

require_once "../includes/functions.php";

/*
|--------------------------------------------------------------------------
| Admin Login Check
|--------------------------------------------------------------------------
*/
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}


/*
|--------------------------------------------------------------------------
| Database Connection
|--------------------------------------------------------------------------
| Agar functions.php me $conn available hai to ye use hoga.
*/
global $conn;


/*
|--------------------------------------------------------------------------
| DELETE MATCH
|--------------------------------------------------------------------------
*/
if (isset($_GET['delete'])) {

    $match_id = intval($_GET['delete']);

    $stmt = mysqli_prepare($conn, "DELETE FROM matches WHERE id = ?");

    mysqli_stmt_bind_param($stmt, "i", $match_id);

    if (mysqli_stmt_execute($stmt)) {

        header("Location: manage_matches.php?msg=deleted");
        exit();

    } else {

        $error = "Unable to delete match.";

    }

    mysqli_stmt_close($stmt);
}


/*
|--------------------------------------------------------------------------
| ADD MATCH
|--------------------------------------------------------------------------
*/
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_match'])) {

    $home_team = trim($_POST['home_team']);
    $away_team = trim($_POST['away_team']);
    $sport = trim($_POST['sport']);
    $match_date = trim($_POST['match_date']);
    $match_time = trim($_POST['match_time']);
    $venue = trim($_POST['venue']);
    $home_score = intval($_POST['home_score']);
    $away_score = intval($_POST['away_score']);
    $status = trim($_POST['status']);

    if (
        empty($home_team) ||
        empty($away_team) ||
        empty($sport) ||
        empty($match_date) ||
        empty($match_time)
    ) {

        $error = "Please fill all required fields.";

    } else {

        $stmt = mysqli_prepare(
            $conn,
            "INSERT INTO matches
            (home_team, away_team, sport, match_date, match_time, venue, home_score, away_score, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "ssssssiis",
            $home_team,
            $away_team,
            $sport,
            $match_date,
            $match_time,
            $venue,
            $home_score,
            $away_score,
            $status
        );

        if (mysqli_stmt_execute($stmt)) {

            header("Location: manage_matches.php?msg=added");
            exit();

        } else {

            $error = "Unable to add match.";

        }

        mysqli_stmt_close($stmt);
    }
}


/*
|--------------------------------------------------------------------------
| FETCH MATCHES
|--------------------------------------------------------------------------
*/
$result = mysqli_query(
    $conn,
    "SELECT * FROM matches ORDER BY match_date DESC, match_time DESC"
);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Manage Matches | SportZone Admin</title>

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            color: #222;
        }

        .admin-header {
            background: #111827;
            color: white;
            padding: 18px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .admin-header h2 {
            font-size: 22px;
        }

        .admin-header a {
            color: white;
            text-decoration: none;
            margin-left: 15px;
        }

        .container {
            width: 95%;
            max-width: 1400px;
            margin: 30px auto;
        }

        .page-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .page-title h1 {
            font-size: 28px;
        }

        .btn {
            border: none;
            padding: 10px 16px;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
        }

        .btn-primary {
            background: #2563eb;
            color: white;
        }

        .btn-success {
            background: #16a34a;
            color: white;
        }

        .btn-danger {
            background: #dc2626;
            color: white;
        }

        .btn-warning {
            background: #f59e0b;
            color: white;
        }

        .card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.08);
        }

        .card h2 {
            margin-bottom: 20px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            margin-bottom: 7px;
            font-weight: bold;
            font-size: 14px;
        }

        .form-group input,
        .form-group select {
            padding: 11px;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            outline: none;
        }

        .form-group input:focus,
        .form-group select:focus {
            border-color: #2563eb;
        }

        .full-width {
            grid-column: 1 / -1;
        }

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #111827;
            color: white;
            padding: 13px;
            text-align: left;
        }

        td {
            padding: 13px;
            border-bottom: 1px solid #e5e7eb;
        }

        tr:hover {
            background: #f9fafb;
        }

        .status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .live {
            background: #fee2e2;
            color: #dc2626;
        }

        .upcoming {
            background: #dbeafe;
            color: #2563eb;
        }

        .completed {
            background: #dcfce7;
            color: #15803d;
        }

        .actions {
            display: flex;
            gap: 7px;
        }

        .message {
            padding: 12px 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .success-message {
            background: #dcfce7;
            color: #166534;
        }

        .error-message {
            background: #fee2e2;
            color: #991b1b;
        }

        @media (max-width: 900px) {

            .form-grid {
                grid-template-columns: 1fr 1fr;
            }

        }

        @media (max-width: 600px) {

            .form-grid {
                grid-template-columns: 1fr;
            }

            .page-title {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

        }

    </style>

</head>

<body>


<!-- ================= ADMIN HEADER ================= -->

<header class="admin-header">

    <h2>
        <i class="fa-solid fa-futbol"></i>
        SportZone Admin
    </h2>

    <div>

        <a href="dashboard.php">
            <i class="fa-solid fa-gauge"></i>
            Dashboard
        </a>

        <a href="logout.php">
            <i class="fa-solid fa-right-from-bracket"></i>
            Logout
        </a>

    </div>

</header>


<div class="container">


    <!-- ================= PAGE TITLE ================= -->

    <div class="page-title">

        <h1>
            <i class="fa-solid fa-calendar-days"></i>
            Manage Matches
        </h1>

        <a href="dashboard.php" class="btn btn-primary">
            <i class="fa-solid fa-arrow-left"></i>
            Back to Dashboard
        </a>

    </div>


    <!-- ================= MESSAGES ================= -->

    <?php if (isset($_GET['msg']) && $_GET['msg'] == 'added'): ?>

        <div class="message success-message">
            <i class="fa-solid fa-circle-check"></i>
            Match added successfully.
        </div>

    <?php endif; ?>


    <?php if (isset($_GET['msg']) && $_GET['msg'] == 'deleted'): ?>

        <div class="message success-message">
            <i class="fa-solid fa-circle-check"></i>
            Match deleted successfully.
        </div>

    <?php endif; ?>


    <?php if (isset($error)): ?>

        <div class="message error-message">
            <i class="fa-solid fa-circle-exclamation"></i>
            <?php echo htmlspecialchars($error); ?>
        </div>

    <?php endif; ?>


    <!-- ================= ADD MATCH ================= -->

    <div class="card">

        <h2>
            <i class="fa-solid fa-plus"></i>
            Add New Match
        </h2>


        <form method="POST">

            <div class="form-grid">


                <div class="form-group">

                    <label>Home Team *</label>

                    <input
                        type="text"
                        name="home_team"
                        placeholder="Enter home team"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Away Team *</label>

                    <input
                        type="text"
                        name="away_team"
                        placeholder="Enter away team"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Sport *</label>

                    <select name="sport" required>

                        <option value="">Select Sport</option>

                        <option value="Football">Football</option>

                        <option value="Cricket">Cricket</option>

                        <option value="Basketball">Basketball</option>

                        <option value="Volleyball">Volleyball</option>

                        <option value="Hockey">Hockey</option>

                    </select>

                </div>


                <div class="form-group">

                    <label>Match Date *</label>

                    <input
                        type="date"
                        name="match_date"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Match Time *</label>

                    <input
                        type="time"
                        name="match_time"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>Venue</label>

                    <input
                        type="text"
                        name="venue"
                        placeholder="Enter venue"
                    >

                </div>


                <div class="form-group">

                    <label>Home Score</label>

                    <input
                        type="number"
                        name="home_score"
                        value="0"
                        min="0"
                    >

                </div>


                <div class="form-group">

                    <label>Away Score</label>

                    <input
                        type="number"
                        name="away_score"
                        value="0"
                        min="0"
                    >

                </div>


                <div class="form-group">

                    <label>Status</label>

                    <select name="status">

                        <option value="Upcoming">
                            Upcoming
                        </option>

                        <option value="Live">
                            Live
                        </option>

                        <option value="Completed">
                            Completed
                        </option>

                    </select>

                </div>


                <div class="form-group full-width">

                    <button
                        type="submit"
                        name="add_match"
                        class="btn btn-success"
                    >

                        <i class="fa-solid fa-plus"></i>

                        Add Match

                    </button>

                </div>


            </div>

        </form>

    </div>


    <!-- ================= MATCH LIST ================= -->

    <div class="card">

        <h2>
            <i class="fa-solid fa-list"></i>
            All Matches
        </h2>


        <div class="table-wrapper">

            <table>

                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Sport</th>

                        <th>Home Team</th>

                        <th>Score</th>

                        <th>Away Team</th>

                        <th>Date</th>

                        <th>Time</th>

                        <th>Venue</th>

                        <th>Status</th>

                        <th>Action</th>

                    </tr>

                </thead>


                <tbody>

                <?php if ($result && mysqli_num_rows($result) > 0): ?>

                    <?php while ($match = mysqli_fetch_assoc($result)): ?>

                        <tr>

                            <td>
                                <?php echo $match['id']; ?>
                            </td>


                            <td>
                                <?php echo htmlspecialchars($match['sport']); ?>
                            </td>


                            <td>
                                <?php echo htmlspecialchars($match['home_team']); ?>
                            </td>


                            <td>
                                <strong>
                                    <?php echo $match['home_score']; ?>
                                    -
                                    <?php echo $match['away_score']; ?>
                                </strong>
                            </td>


                            <td>
                                <?php echo htmlspecialchars($match['away_team']); ?>
                            </td>


                            <td>
                                <?php echo htmlspecialchars($match['match_date']); ?>
                            </td>


                            <td>
                                <?php echo htmlspecialchars($match['match_time']); ?>
                            </td>


                            <td>
                                <?php echo htmlspecialchars($match['venue']); ?>
                            </td>


                            <td>

                                <?php

                                $status_class = '';

                                if ($match['status'] == 'Live') {

                                    $status_class = 'live';

                                } elseif ($match['status'] == 'Completed') {

                                    $status_class = 'completed';

                                } else {

                                    $status_class = 'upcoming';

                                }

                                ?>

                                <span class="status <?php echo $status_class; ?>">

                                    <?php echo htmlspecialchars($match['status']); ?>

                                </span>

                            </td>


                            <td>

                                <div class="actions">

                                    <a
                                        href="edit_match.php?id=<?php echo $match['id']; ?>"
                                        class="btn btn-warning"
                                    >

                                        <i class="fa-solid fa-pen"></i>

                                    </a>


                                    <a
                                        href="manage_matches.php?delete=<?php echo $match['id']; ?>"
                                        class="btn btn-danger"
                                        onclick="return confirm('Are you sure you want to delete this match?');"
                                    >

                                        <i class="fa-solid fa-trash"></i>

                                    </a>

                                </div>

                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="10" style="text-align:center;">

                            No matches found.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


</body>

</html>

