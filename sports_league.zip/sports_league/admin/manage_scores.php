
<?php
session_start();

require_once "../includes/functions.php";

// Admin login check
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection
global $conn;

$message = "";
$error = "";


/*
|--------------------------------------------------------------------------
| UPDATE SCORE
|--------------------------------------------------------------------------
*/
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update_score'])) {

    $match_id   = intval($_POST['match_id']);
    $home_score = intval($_POST['home_score']);
    $away_score = intval($_POST['away_score']);
    $status     = trim($_POST['status']);

    if ($match_id <= 0) {

        $error = "Invalid match selected.";

    } elseif ($home_score < 0 || $away_score < 0) {

        $error = "Score cannot be negative.";

    } else {

        $stmt = mysqli_prepare(
            $conn,
            "UPDATE matches
             SET home_score = ?,
                 away_score = ?,
                 status = ?
             WHERE id = ?"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "iisi",
            $home_score,
            $away_score,
            $status,
            $match_id
        );

        if (mysqli_stmt_execute($stmt)) {

            $message = "Score updated successfully.";

        } else {

            $error = "Unable to update score.";

        }

        mysqli_stmt_close($stmt);
    }
}


/*
|--------------------------------------------------------------------------
| GET ALL MATCHES
|--------------------------------------------------------------------------
*/
$result = mysqli_query(
    $conn,
    "SELECT *
     FROM matches
     ORDER BY match_date DESC, match_time DESC"
);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Manage Scores | SportZone Admin</title>

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            color: #1f2937;
        }

        /* HEADER */

        .admin-header {
            background: #111827;
            color: white;
            padding: 18px 30px;

            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .admin-header h2 {
            font-size: 22px;
        }

        .admin-header a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
        }

        .admin-header a:hover {
            color: #60a5fa;
        }

        /* CONTAINER */

        .container {
            width: 95%;
            max-width: 1400px;
            margin: 30px auto;
        }

        .page-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .page-title h1 {
            font-size: 28px;
        }

        /* CARD */

        .card {
            background: white;
            padding: 25px;
            border-radius: 12px;

            box-shadow: 0 3px 15px rgba(0,0,0,0.08);

            margin-bottom: 25px;
        }

        .card h2 {
            margin-bottom: 20px;
        }

        /* MESSAGE */

        .message {
            padding: 13px 16px;
            border-radius: 7px;
            margin-bottom: 20px;
        }

        .success {
            background: #dcfce7;
            color: #166534;
        }

        .error {
            background: #fee2e2;
            color: #991b1b;
        }

        /* TABLE */

        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #111827;
            color: white;
            padding: 14px;
            text-align: center;
        }

        td {
            padding: 14px;
            border-bottom: 1px solid #e5e7eb;
            text-align: center;
        }

        tr:hover {
            background: #f9fafb;
        }

        /* TEAM */

        .team {
            font-weight: 700;
            font-size: 15px;
        }

        .vs {
            font-weight: bold;
            color: #6b7280;
            padding: 0 8px;
        }

        /* SCORE INPUT */

        .score-box {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .score-input {
            width: 65px;
            padding: 10px;

            text-align: center;

            border: 2px solid #d1d5db;
            border-radius: 7px;

            font-size: 18px;
            font-weight: bold;
        }

        .score-input:focus {
            outline: none;
            border-color: #2563eb;
        }

        /* STATUS */

        .status-select {
            padding: 9px;

            border: 1px solid #d1d5db;
            border-radius: 6px;

            cursor: pointer;
        }

        /* BUTTON */

        .update-btn {
            background: #2563eb;
            color: white;

            border: none;

            padding: 9px 14px;

            border-radius: 6px;

            cursor: pointer;

            font-weight: 600;
        }

        .update-btn:hover {
            background: #1d4ed8;
        }

        .back-btn {
            background: #374151;
            color: white;

            padding: 10px 16px;

            border-radius: 7px;

            text-decoration: none;
        }

        .back-btn:hover {
            background: #1f2937;
        }

        /* STATUS BADGES */

        .badge {
            padding: 5px 10px;
            border-radius: 20px;

            font-size: 12px;
            font-weight: bold;
        }

        .live {
            background: #fee2e2;
            color: #dc2626;
        }

        .upcoming {
            background: #dbeafe;
            color: #2563eb;
        }

        .completed {
            background: #dcfce7;
            color: #15803d;
        }

        /* RESPONSIVE */

        @media (max-width: 800px) {

            .admin-header {
                flex-direction: column;
                gap: 15px;
            }

            .page-title {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            th,
            td {
                white-space: nowrap;
            }

        }

    </style>

</head>


<body>


<!-- ================= ADMIN HEADER ================= -->

<header class="admin-header">

    <h2>
        <i class="fa-solid fa-futbol"></i>
        SportZone Admin
    </h2>

    <div>

        <a href="dashboard.php">
            <i class="fa-solid fa-gauge"></i>
            Dashboard
        </a>

        <a href="manage_matches.php">
            <i class="fa-solid fa-calendar-days"></i>
            Matches
        </a>

        <a href="logout.php">
            <i class="fa-solid fa-right-from-bracket"></i>
            Logout
        </a>

    </div>

</header>


<!-- ================= MAIN ================= -->

<div class="container">


    <!-- PAGE TITLE -->

    <div class="page-title">

        <h1>
            <i class="fa-solid fa-stopwatch"></i>
            Manage Scores
        </h1>

        <a href="dashboard.php" class="back-btn">
            <i class="fa-solid fa-arrow-left"></i>
            Dashboard
        </a>

    </div>


    <!-- SUCCESS MESSAGE -->

    <?php if (!empty($message)): ?>

        <div class="message success">

            <i class="fa-solid fa-circle-check"></i>

            <?php echo htmlspecialchars($message); ?>

        </div>

    <?php endif; ?>


    <!-- ERROR MESSAGE -->

    <?php if (!empty($error)): ?>

        <div class="message error">

            <i class="fa-solid fa-circle-exclamation"></i>

            <?php echo htmlspecialchars($error); ?>

        </div>

    <?php endif; ?>


    <!-- SCORE MANAGEMENT -->

    <div class="card">

        <h2>
            <i class="fa-solid fa-pen-to-square"></i>
            Update Match Scores
        </h2>


        <div class="table-wrapper">

            <table>

                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Sport</th>

                        <th>Match</th>

                        <th>Date</th>

                        <th>Score</th>

                        <th>Status</th>

                        <th>Update</th>

                    </tr>

                </thead>


                <tbody>

                <?php if ($result && mysqli_num_rows($result) > 0): ?>

                    <?php while ($match = mysqli_fetch_assoc($result)): ?>

                        <tr>


                            <!-- ID -->

                            <td>

                                #<?php echo $match['id']; ?>

                            </td>


                            <!-- SPORT -->

                            <td>

                                <strong>
                                    <?php echo htmlspecialchars($match['sport']); ?>
                                </strong>

                            </td>


                            <!-- TEAMS -->

                            <td>

                                <span class="team">

                                    <?php
                                    echo htmlspecialchars($match['home_team']);
                                    ?>

                                </span>

                                <span class="vs">
                                    VS
                                </span>

                                <span class="team">

                                    <?php
                                    echo htmlspecialchars($match['away_team']);
                                    ?>

                                </span>

                            </td>


                            <!-- DATE -->

                            <td>

                                <?php
                                echo htmlspecialchars($match['match_date']);
                                ?>

                                <br>

                                <small>

                                    <?php
                                    echo htmlspecialchars($match['match_time']);
                                    ?>

                                </small>

                            </td>


                            <!-- SCORE -->

                            <td>

                                <form
                                    method="POST"
                                    class="score-box"
                                >

                                    <input
                                        type="hidden"
                                        name="match_id"
                                        value="<?php echo $match['id']; ?>"
                                    >


                                    <input
                                        type="number"
                                        name="home_score"
                                        class="score-input"
                                        value="<?php echo $match['home_score']; ?>"
                                        min="0"
                                        required
                                    >


                                    <span class="vs">
                                        -
                                    </span>


                                    <input
                                        type="number"
                                        name="away_score"
                                        class="score-input"
                                        value="<?php echo $match['away_score']; ?>"
                                        min="0"
                                        required
                                    >

                            </td>


                            <!-- STATUS -->

                            <td>

                                <select
                                    name="status"
                                    class="status-select"
                                >

                                    <option
                                        value="Upcoming"
                                        <?php
                                        echo ($match['status'] == 'Upcoming')
                                            ? 'selected'
                                            : '';
                                        ?>
                                    >
                                        Upcoming
                                    </option>


                                    <option
                                        value="Live"
                                        <?php
                                        echo ($match['status'] == 'Live')
                                            ? 'selected'
                                            : '';
                                        ?>
                                    >
                                        Live
                                    </option>


                                    <option
                                        value="Completed"
                                        <?php
                                        echo ($match['status'] == 'Completed')
                                            ? 'selected'
                                            : '';
                                        ?>
                                    >
                                        Completed
                                    </option>

                                </select>

                            </td>


                            <!-- UPDATE -->

                            <td>

                                    <button
                                        type="submit"
                                        name="update_score"
                                        class="update-btn"
                                    >

                                        <i class="fa-solid fa-floppy-disk"></i>

                                        Update

                                    </button>

                                </form>

                            </td>

                        </tr>

                    <?php endwhile; ?>


                <?php else: ?>

                    <tr>

                        <td colspan="7">

                            <i class="fa-solid fa-circle-info"></i>

                            No matches available.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>


</div>


</body>

</html>
