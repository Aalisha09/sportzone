<?php
session_start();

// Saare session variables remove karo
$_SESSION = array();

// Session destroy karo
session_destroy();

// Login page par redirect karo
header("Location: login.php");
exit();
?>