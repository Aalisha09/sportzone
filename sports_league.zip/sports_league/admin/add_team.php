
<?php
/* =========================================================
   SPORTZONE - ADD TEAM
   ========================================================= */

require_once __DIR__ . '/../includes/functions.php';

$message = "";
$message_type = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $team_name    = trim($_POST['team_name'] ?? '');
    $sport        = trim($_POST['sport'] ?? '');
    $city         = trim($_POST['city'] ?? '');
    $coach        = trim($_POST['coach'] ?? '');
    $founded_year = trim($_POST['founded_year'] ?? '');

    /* =====================================================
       VALIDATION
    ===================================================== */

    if (
        empty($team_name) ||
        empty($sport) ||
        empty($city) ||
        empty($coach) ||
        empty($founded_year)
    ) {

        $message = "Please fill all fields.";
        $message_type = "error";

    } elseif (
        !is_numeric($founded_year) ||
        $founded_year < 1900 ||
        $founded_year > date("Y")
    ) {

        $message = "Please enter a valid founded year.";
        $message_type = "error";

    } else {

        /* =================================================
           CHECK DUPLICATE TEAM
        ================================================= */

        $check = $conn->prepare("
            SELECT id
            FROM teams
            WHERE team_name = ?
        ");

        if (!$check) {

            $message = "Database error: " . $conn->error;
            $message_type = "error";

        } else {

            $check->bind_param("s", $team_name);
            $check->execute();
            $check->store_result();

            if ($check->num_rows > 0) {

                $message = "This team already exists.";
                $message_type = "error";

            } else {

                /* =============================================
                   INSERT TEAM

                   NOTE:
                   captain column is NOT used because the
                   current teams table does not contain it.
                ============================================= */

                $stmt = $conn->prepare("
                    INSERT INTO teams
                    (
                        team_name,
                        city,
                        coach,
                        founded_year
                    )
                    VALUES (?, ?, ?, ?)
                ");

                if (!$stmt) {

                    $message = "Database error: " . $conn->error;
                    $message_type = "error";

                } else {

                    $founded_year = (int)$founded_year;

                    $stmt->bind_param(
                        "sssi",
                        $team_name,
                        $city,
                        $coach,
                        $founded_year
                    );

                    if ($stmt->execute()) {

                        $message = "Team added successfully!";
                        $message_type = "success";

                        $_POST = [];

                    } else {

                        $message = "Error adding team: " . $stmt->error;
                        $message_type = "error";
                    }

                    $stmt->close();
                }
            }

            $check->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Add Team | SportZone</title>

    <!-- Google Font -->
    <link rel="preconnect"
          href="https://fonts.googleapis.com">

    <link rel="preconnect"
          href="https://fonts.gstatic.com"
          crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap"
          rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>

        /* =====================================================
           RESET
        ===================================================== */

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            background: #080c11;
            color: #ffffff;
            min-height: 100vh;
        }

        a {
            text-decoration: none;
            color: inherit;
        }


        /* =====================================================
           HEADER
        ===================================================== */

        .header {
            height: 80px;
            background: #0b1016;
            border-bottom: 1px solid #202731;

            display: flex;
            align-items: center;
            justify-content: space-between;

            padding: 0 5%;
        }


        /* =====================================================
           LOGO
        ===================================================== */

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;

            border-radius: 12px;
            background: #ff5b25;

            display: flex;
            align-items: center;
            justify-content: center;

            font-size: 20px;
        }

        .logo-text span {
            display: block;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 2px;
        }

        .logo-text strong {
            display: block;
            color: #ff5b25;
            font-size: 20px;
            font-weight: 900;
        }


        /* =====================================================
           BACK BUTTON
        ===================================================== */

        .back-btn {
            display: flex;
            align-items: center;
            gap: 8px;

            padding: 11px 18px;

            border: 1px solid #303a46;
            border-radius: 8px;

            color: #aeb7c2;

            font-size: 12px;
            font-weight: 700;

            transition: 0.3s;
        }

        .back-btn:hover {
            background: #ff5b25;
            border-color: #ff5b25;
            color: #ffffff;
        }


        /* =====================================================
           PAGE
        ===================================================== */

        .page {
            width: 90%;
            max-width: 1000px;

            margin: 55px auto 80px;
        }


        /* =====================================================
           PAGE HEADING
        ===================================================== */

        .page-heading {
            margin-bottom: 30px;
        }

        .page-heading > span {
            display: inline-block;

            color: #ff5b25;

            font-size: 11px;
            font-weight: 800;

            letter-spacing: 2px;

            margin-bottom: 10px;
        }

        .page-heading h1 {
            font-size: 38px;
            font-weight: 900;
            margin-bottom: 8px;
        }

        .page-heading h1 strong {
            color: #ff5b25;
        }

        .page-heading p {
            color: #7f8b98;
            font-size: 13px;
        }


        /* =====================================================
           FORM CARD
        ===================================================== */

        .form-card {
            background: #111820;

            border: 1px solid #27313c;
            border-radius: 18px;

            padding: 35px;

            box-shadow:
                0 25px 60px rgba(0, 0, 0, 0.25);
        }


        /* =====================================================
           FORM TITLE
        ===================================================== */

        .form-title {
            display: flex;
            align-items: center;
            gap: 12px;

            padding-bottom: 22px;
            margin-bottom: 28px;

            border-bottom: 1px solid #27313c;
        }

        .form-title-icon {
            width: 45px;
            height: 45px;

            border-radius: 11px;

            background: rgba(255, 91, 37, 0.12);
            color: #ff5b25;

            display: flex;
            align-items: center;
            justify-content: center;

            font-size: 18px;
        }

        .form-title h2 {
            font-size: 18px;
            font-weight: 800;
        }

        .form-title p {
            color: #71808d;
            font-size: 11px;
            margin-top: 4px;
        }


        /* =====================================================
           FORM GRID
        ===================================================== */

        .form-grid {
            display: grid;

            grid-template-columns: repeat(2, 1fr);

            gap: 22px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group.full {
            grid-column: 1 / -1;
        }

        .form-group label {
            color: #c3cad2;

            font-size: 11px;
            font-weight: 700;

            margin-bottom: 8px;
        }

        .form-group label span {
            color: #ff5b25;
        }


        /* =====================================================
           INPUT
        ===================================================== */

        .input-box {
            position: relative;
        }

        .input-box i {
            position: absolute;

            left: 15px;
            top: 50%;

            transform: translateY(-50%);

            color: #6e7a87;

            font-size: 13px;

            z-index: 2;
        }

        input,
        select {

            width: 100%;
            height: 48px;

            padding: 0 15px 0 43px;

            background: #0b1016;

            border: 1px solid #2b3540;
            border-radius: 9px;

            outline: none;

            color: #ffffff;

            font-family: inherit;
            font-size: 12px;

            transition: 0.3s;
        }

        select {
            cursor: pointer;
        }

        select option {
            background: #111820;
            color: #ffffff;
        }

        input::placeholder {
            color: #596572;
        }

        input:focus,
        select:focus {

            border-color: #ff5b25;

            box-shadow:
                0 0 0 3px rgba(255, 91, 37, 0.10);
        }


        /* =====================================================
           ALERT
        ===================================================== */

        .alert {

            padding: 14px 17px;

            border-radius: 9px;

            margin-bottom: 25px;

            font-size: 12px;
            font-weight: 600;

            display: flex;
            align-items: center;

            gap: 10px;
        }

        .alert.success {

            background: rgba(34, 197, 94, 0.10);

            border: 1px solid rgba(34, 197, 94, 0.25);

            color: #4ade80;
        }

        .alert.error {

            background: rgba(239, 68, 68, 0.10);

            border: 1px solid rgba(239, 68, 68, 0.25);

            color: #f87171;
        }


        /* =====================================================
           BUTTONS
        ===================================================== */

        .form-actions {

            display: flex;

            justify-content: flex-end;

            gap: 12px;

            margin-top: 30px;

            padding-top: 25px;

            border-top: 1px solid #27313c;
        }

        .btn {

            height: 46px;

            padding: 0 22px;

            border-radius: 8px;

            display: inline-flex;

            align-items: center;
            justify-content: center;

            gap: 8px;

            font-family: inherit;

            font-size: 12px;
            font-weight: 800;

            cursor: pointer;

            transition: 0.3s;
        }

        .cancel-btn {

            background: transparent;

            border: 1px solid #35404c;

            color: #9ba6b2;
        }

        .cancel-btn:hover {

            border-color: #ff5b25;

            color: #ff5b25;
        }

        .submit-btn {

            background: #ff5b25;

            border: 1px solid #ff5b25;

            color: #ffffff;

            box-shadow:
                0 10px 25px rgba(255, 91, 37, 0.15);
        }

        .submit-btn:hover {

            background: #ff713f;

            transform: translateY(-2px);
        }


        /* =====================================================
           MOBILE
        ===================================================== */

        @media (max-width: 700px) {

            .header {
                padding: 0 4%;
            }

            .page {

                width: 92%;

                margin-top: 35px;
            }

            .page-heading h1 {
                font-size: 30px;
            }

            .form-card {
                padding: 22px;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .form-group.full {
                grid-column: auto;
            }

            .form-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
            }

            .logo-text {
                display: none;
            }

        }

    </style>

</head>


<body>


<!-- =====================================================
     HEADER
===================================================== -->

<header class="header">

    <a href="index.php" class="logo">

        <div class="logo-icon">
            <i class="fa-solid fa-trophy"></i>
        </div>

        <div class="logo-text">

            <span>LOCAL SPORTS</span>

            <strong>SPORTZONE</strong>

        </div>

    </a>


    <a href="index.php" class="back-btn">

        <i class="fa-solid fa-arrow-left"></i>

        Back to Teams

    </a>

</header>



<!-- =====================================================
     MAIN
===================================================== -->

<main class="page">


    <div class="page-heading">

        <span>

            <i class="fa-solid fa-users"></i>

            TEAM MANAGEMENT

        </span>


        <h1>

            Add <strong>New Team</strong>

        </h1>


        <p>

            Register a new team for the SportZone local sports league.

        </p>

    </div>



    <!-- =====================================================
         MESSAGE
    ===================================================== -->

    <?php if (!empty($message)): ?>

        <div class="alert <?php echo $message_type; ?>">

            <?php if ($message_type == "success"): ?>

                <i class="fa-solid fa-circle-check"></i>

            <?php else: ?>

                <i class="fa-solid fa-circle-exclamation"></i>

            <?php endif; ?>


            <?php echo htmlspecialchars($message); ?>

        </div>

    <?php endif; ?>



    <!-- =====================================================
         FORM
    ===================================================== -->

    <div class="form-card">


        <div class="form-title">

            <div class="form-title-icon">

                <i class="fa-solid fa-shield-halved"></i>

            </div>


            <div>

                <h2>Team Information</h2>

                <p>
                    Enter the basic details of the new team.
                </p>

            </div>

        </div>



        <form method="POST">

            <div class="form-grid">


                <!-- TEAM NAME -->

                <div class="form-group">

                    <label>

                        Team Name <span>*</span>

                    </label>


                    <div class="input-box">

                        <i class="fa-solid fa-users"></i>


                        <input
                            type="text"
                            name="team_name"
                            placeholder="e.g. Eagles FC"
                            value="<?php echo htmlspecialchars($_POST['team_name'] ?? ''); ?>"
                            required
                        >

                    </div>

                </div>



                <!-- SPORT -->

                <div class="form-group">

                    <label>

                        Sport <span>*</span>

                    </label>


                    <div class="input-box">

                        <i class="fa-solid fa-futbol"></i>


                        <select name="sport" required>

                            <option value="">
                                Select Sport
                            </option>


                            <option value="Football"
                                <?php
                                echo (($_POST['sport'] ?? '') == 'Football')
                                    ? 'selected'
                                    : '';
                                ?>>
                                Football
                            </option>


                            <option value="Cricket"
                                <?php
                                echo (($_POST['sport'] ?? '') == 'Cricket')
                                    ? 'selected'
                                    : '';
                                ?>>
                                Cricket
                            </option>


                            <option value="Basketball"
                                <?php
                                echo (($_POST['sport'] ?? '') == 'Basketball')
                                    ? 'selected'
                                    : '';
                                ?>>
                                Basketball
                            </option>


                            <option value="Tennis"
                                <?php
                                echo (($_POST['sport'] ?? '') == 'Tennis')
                                    ? 'selected'
                                    : '';
                                ?>>
                                Tennis
                            </option>

                        </select>

                    </div>

                </div>



                <!-- CITY -->

                <div class="form-group">

                    <label>

                        City <span>*</span>

                    </label>


                    <div class="input-box">

                        <i class="fa-solid fa-location-dot"></i>


                        <input
                            type="text"
                            name="city"
                            placeholder="e.g. Ahmedabad"
                            value="<?php echo htmlspecialchars($_POST['city'] ?? ''); ?>"
                            required
                        >

                    </div>

                </div>



                <!-- COACH -->

                <div class="form-group">

                    <label>

                        Coach Name <span>*</span>

                    </label>


                    <div class="input-box">

                        <i class="fa-solid fa-user-tie"></i>


                        <input
                            type="text"
                            name="coach"
                            placeholder="e.g. Rahul Sharma"
                            value="<?php echo htmlspecialchars($_POST['coach'] ?? ''); ?>"
                            required
                        >

                    </div>

                </div>



                <!-- FOUNDED YEAR -->

                <div class="form-group">

                    <label>

                        Founded Year <span>*</span>

                    </label>


                    <div class="input-box">

                        <i class="fa-solid fa-calendar"></i>


                        <input
                            type="number"
                            name="founded_year"
                            placeholder="e.g. 2020"
                            min="1900"
                            max="<?php echo date('Y'); ?>"
                            value="<?php echo htmlspecialchars($_POST['founded_year'] ?? ''); ?>"
                            required
                        >

                    </div>

                </div>


            </div>



            <!-- =================================================
                 ACTION BUTTONS
            ================================================== -->

            <div class="form-actions">


                <a href="teams.php"
                   class="btn cancel-btn">

                    <i class="fa-solid fa-xmark"></i>

                    Cancel

                </a>


                <button
                    type="submit"
                    class="btn submit-btn">

                    <i class="fa-solid fa-plus"></i>

                    Add Team

                </button>


            </div>


        </form>

    </div>


</main>


</body>

</html>

