<?php
session_start();

/*
|--------------------------------------------------------------------------
| Database / Functions File
|--------------------------------------------------------------------------
| login.php admin folder ke andar hai
| isliye ../includes/functions.php use hoga
*/

require_once __DIR__ . '/../includes/functions.php';

$error = "";


/*
|--------------------------------------------------------------------------
| Already Logged In
|--------------------------------------------------------------------------
*/

if (isset($_SESSION["admin_id"])) {

    header("Location: dashboard.php");
    exit();

}


/*
|--------------------------------------------------------------------------
| Login Process
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";


    if (empty($email) || empty($password)) {

        $error = "Please enter email and password.";

    } else {

        /*
        |--------------------------------------------------------------------------
        | IMPORTANT:
        | We are using ADMINS table, NOT users table.
        |--------------------------------------------------------------------------
        */

        $sql = "SELECT id, username, email, password
                FROM admins
                WHERE email = ?
                LIMIT 1";

        $stmt = mysqli_prepare($conn, $sql);


        if ($stmt) {

            mysqli_stmt_bind_param(
                $stmt,
                "s",
                $email
            );

            mysqli_stmt_execute($stmt);

            $result = mysqli_stmt_get_result($stmt);


            if ($result && mysqli_num_rows($result) === 1) {

                $admin = mysqli_fetch_assoc($result);


                /*
                |--------------------------------------------------------------------------
                | Verify Password
                |--------------------------------------------------------------------------
                */

                if (password_verify($password, $admin["password"])) {


                    /*
                    |--------------------------------------------------------------------------
                    | Admin Session
                    |--------------------------------------------------------------------------
                    */

                    $_SESSION["admin_id"] = $admin["id"];

                    $_SESSION["admin_username"] =
                        $admin["username"];

                    $_SESSION["admin_email"] =
                        $admin["email"];


                    /*
                    |--------------------------------------------------------------------------
                    | Dashboard
                    |--------------------------------------------------------------------------
                    */

                    header("Location: dashboard.php");

                    exit();


                } else {

                    $error = "Invalid email or password.";

                }


            } else {

                $error = "Invalid email or password.";

            }


            mysqli_stmt_close($stmt);


        } else {

            $error = "Database query failed.";

        }

    }

}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Admin Login | SportZone</title>


    <!-- Google Font -->

    <link rel="preconnect"
          href="https://fonts.googleapis.com">

    <link rel="preconnect"
          href="https://fonts.gstatic.com"
          crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap"
          rel="stylesheet">


    <!-- Font Awesome -->

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


<style>

* {

    margin: 0;
    padding: 0;

    box-sizing: border-box;

}


body {

    min-height: 100vh;

    font-family: 'Montserrat', sans-serif;

    background:

        radial-gradient(
            circle at 20% 20%,
            rgba(255, 91, 37, 0.15),
            transparent 30%
        ),

        radial-gradient(
            circle at 80% 80%,
            rgba(255, 91, 37, 0.12),
            transparent 30%
        ),

        #080c11;

    color: #ffffff;

    display: flex;

    align-items: center;

    justify-content: center;

    padding: 25px;

    overflow-x: hidden;

}


/* Background circles */

body::before {

    content: "";

    position: fixed;

    width: 400px;

    height: 400px;

    border: 1px solid rgba(255, 91, 37, 0.08);

    border-radius: 50%;

    top: -180px;

    right: -100px;

    pointer-events: none;

}


body::after {

    content: "";

    position: fixed;

    width: 300px;

    height: 300px;

    border: 1px solid rgba(255, 91, 37, 0.08);

    border-radius: 50%;

    bottom: -150px;

    left: -100px;

    pointer-events: none;

}


/* Main Wrapper */

.login-wrapper {

    width: 100%;

    max-width: 1050px;

    min-height: 620px;

    display: grid;

    grid-template-columns: 1fr 1fr;

    background: #111820;

    border: 1px solid #29343f;

    border-radius: 22px;

    overflow: hidden;

    box-shadow:
        0 30px 80px rgba(0, 0, 0, 0.55);

    position: relative;

    z-index: 2;

}


/* Left Side */

.login-left {

    padding: 55px;

    display: flex;

    flex-direction: column;

    justify-content: center;

    background:

        linear-gradient(
            135deg,
            #101720,
            #0b1118
        );

    position: relative;

    overflow: hidden;

}


.login-left::before {

    content: "";

    position: absolute;

    width: 280px;

    height: 280px;

    background:
        rgba(255, 91, 37, 0.08);

    border-radius: 50%;

    right: -120px;

    top: -120px;

}


.login-left::after {

    content: "";

    position: absolute;

    width: 220px;

    height: 220px;

    border: 30px solid rgba(255, 91, 37, 0.04);

    border-radius: 50%;

    left: -100px;

    bottom: -100px;

}


/* Logo */

.logo {

    display: flex;

    align-items: center;

    gap: 12px;

    margin-bottom: 55px;

    position: relative;

    z-index: 2;

}


.logo-icon {

    width: 55px;

    height: 55px;

    border-radius: 13px;

    display: flex;

    align-items: center;

    justify-content: center;

    background: #ff5b25;

    color: #ffffff;

    font-size: 25px;

    box-shadow:
        0 10px 30px rgba(255, 91, 37, 0.25);

}


.logo-text {

    display: flex;

    flex-direction: column;

    line-height: 1;

}


.logo-text span {

    font-size: 11px;

    font-weight: 700;

    letter-spacing: 3px;

    color: #ffffff;

}


.logo-text strong {

    margin-top: 4px;

    font-size: 23px;

    color: #ff5b25;

    font-weight: 900;

    letter-spacing: 1px;

}


/* Left Content */

.login-left h1 {

    font-size: 48px;

    line-height: 1.05;

    font-weight: 900;

    margin-bottom: 20px;

    position: relative;

    z-index: 2;

}


.login-left h1 span {

    color: #ff5b25;

}


.login-left > p {

    max-width: 450px;

    color: #8d99a6;

    font-size: 14px;

    line-height: 1.8;

    position: relative;

    z-index: 2;

}


/* Features */

.features {

    margin-top: 35px;

    display: grid;

    gap: 15px;

    position: relative;

    z-index: 2;

}


.feature {

    display: flex;

    align-items: center;

    gap: 13px;

    color: #b7c0ca;

    font-size: 12px;

    font-weight: 600;

}


.feature i {

    width: 34px;

    height: 34px;

    display: flex;

    align-items: center;

    justify-content: center;

    background:
        rgba(255, 91, 37, 0.12);

    color: #ff5b25;

    border-radius: 9px;

}


/* Right Side */

.login-right {

    background: #ffffff;

    padding: 55px;

    display: flex;

    align-items: center;

    justify-content: center;

}


.login-form-box {

    width: 100%;

    max-width: 390px;

}


/* Heading */

.form-heading {

    margin-bottom: 30px;

}


.form-heading small {

    color: #ff5b25;

    font-size: 11px;

    font-weight: 900;

    letter-spacing: 2px;

}


.form-heading h2 {

    margin-top: 8px;

    color: #111827;

    font-size: 32px;

    font-weight: 900;

}


.form-heading p {

    margin-top: 8px;

    color: #6b7280;

    font-size: 12px;

}


/* Error */

.error-message {

    display: flex;

    align-items: center;

    gap: 10px;

    padding: 12px 14px;

    margin-bottom: 20px;

    border-radius: 9px;

    background: #fff1f1;

    border: 1px solid #fecaca;

    color: #dc2626;

    font-size: 12px;

    font-weight: 600;

}


/* Form */

.form-group {

    margin-bottom: 20px;

}


.form-group label {

    display: block;

    margin-bottom: 8px;

    color: #374151;

    font-size: 12px;

    font-weight: 800;

}


.input-box {

    position: relative;

}


.input-box > i {

    position: absolute;

    left: 15px;

    top: 50%;

    transform: translateY(-50%);

    color: #9ca3af;

    font-size: 14px;

}


.input-box input {

    width: 100%;

    height: 50px;

    padding: 0 45px;

    border: 1px solid #dfe3e8;

    border-radius: 9px;

    background: #f9fafb;

    color: #111827;

    outline: none;

    font-family: inherit;

    font-size: 13px;

    transition: 0.3s;

}


.input-box input:focus {

    border-color: #ff5b25;

    background: #ffffff;

    box-shadow:
        0 0 0 3px rgba(255, 91, 37, 0.10);

}


/* Password */

.password-toggle {

    position: absolute;

    right: 15px;

    top: 50%;

    transform: translateY(-50%);

    border: none;

    background: none;

    color: #9ca3af;

    cursor: pointer;

    font-size: 14px;

}


.password-toggle:hover {

    color: #ff5b25;

}


/* Remember */

.form-options {

    display: flex;

    align-items: center;

    justify-content: space-between;

    margin-bottom: 25px;

    font-size: 11px;

}


.remember {

    display: flex;

    align-items: center;

    gap: 7px;

    color: #6b7280;

    cursor: pointer;

}


.remember input {

    accent-color: #ff5b25;

    cursor: pointer;

}


.forgot {

    color: #ff5b25;

    font-weight: 700;

    text-decoration: none;

}


/* Login Button */

.login-btn {

    width: 100%;

    height: 52px;

    border: none;

    border-radius: 9px;

    background: #ff5b25;

    color: #ffffff;

    font-family: inherit;

    font-size: 13px;

    font-weight: 800;

    cursor: pointer;

    display: flex;

    align-items: center;

    justify-content: center;

    gap: 10px;

    transition: 0.3s;

    box-shadow:
        0 10px 25px rgba(255, 91, 37, 0.20);

}


.login-btn:hover {

    background: #ff713f;

    transform: translateY(-2px);

    box-shadow:
        0 15px 30px rgba(255, 91, 37, 0.25);

}


/* Back Home */

.back-home {

    text-align: center;

    margin-top: 25px;

    color: #6b7280;

    font-size: 11px;

}


.back-home a {

    color: #ff5b25;

    font-weight: 800;

    text-decoration: none;

}


.back-home a:hover {

    text-decoration: underline;

}


/* Mobile */

@media (max-width: 800px) {

    body {

        padding: 15px;

    }

    .login-wrapper {

        grid-template-columns: 1fr;

        max-width: 500px;

    }

    .login-left {

        padding: 35px;

        min-height: 300px;

    }

    .logo {

        margin-bottom: 30px;

    }

    .login-left h1 {

        font-size: 36px;

    }

    .features {

        display: none;

    }

    .login-right {

        padding: 35px;

    }

}


@media (max-width: 480px) {

    .login-left {

        padding: 28px;

    }

    .login-right {

        padding: 28px 22px;

    }

    .login-left h1 {

        font-size: 31px;

    }

    .form-heading h2 {

        font-size: 27px;

    }

}

</style>

</head>


<body>


<div class="login-wrapper">


    <!-- =================================================
         LEFT SIDE
    ================================================== -->

    <div class="login-left">


        <div class="logo">

            <div class="logo-icon">

                <i class="fa-solid fa-trophy"></i>

            </div>


            <div class="logo-text">

                <span>LOCAL SPORTS</span>

                <strong>SPORTZONE</strong>

            </div>

        </div>


        <h1>

            Welcome Back to

            <span>SportZone.</span>

        </h1>


        <p>

            Manage your local sports league, teams,
            matches, schedules and live scores from
            one powerful platform.

        </p>


        <div class="features">


            <div class="feature">

                <i class="fa-solid fa-chart-line"></i>

                <span>

                    Track live scores and match results

                </span>

            </div>


            <div class="feature">

                <i class="fa-solid fa-users"></i>

                <span>

                    Manage teams and players

                </span>

            </div>


            <div class="feature">

                <i class="fa-solid fa-calendar-days"></i>

                <span>

                    Organize tournament schedules

                </span>

            </div>


        </div>


    </div>


    <!-- =================================================
         RIGHT SIDE
    ================================================== -->

    <div class="login-right">


        <div class="login-form-box">


            <div class="form-heading">

                <small>ADMIN LOGIN</small>

                <h2>Sign In</h2>

                <p>

                    Enter your account details to continue.

                </p>

            </div>


            <?php if (!empty($error)): ?>

                <div class="error-message">

                    <i class="fa-solid fa-circle-exclamation"></i>

                    <?php
                    echo htmlspecialchars($error);
                    ?>

                </div>

            <?php endif; ?>


            <form method="POST"
                  action="">


                <!-- EMAIL -->

                <div class="form-group">

                    <label for="email">

                        Email Address

                    </label>


                    <div class="input-box">

                        <i class="fa-solid fa-envelope"></i>

                        <input

                            type="email"

                            id="email"

                            name="email"

                            placeholder="admin@sportzone.com"

                            autocomplete="email"

                            value="<?php
                            echo htmlspecialchars(
                                $_POST["email"] ?? ""
                            );
                            ?>"

                            required

                        >

                    </div>

                </div>


                <!-- PASSWORD -->

                <div class="form-group">

                    <label for="password">

                        Password

                    </label>


                    <div class="input-box">

                        <i class="fa-solid fa-lock"></i>


                        <input

                            type="password"

                            id="password"

                            name="password"

                            placeholder="Enter your password"

                            autocomplete="current-password"

                            required

                        >


                        <button

                            type="button"

                            class="password-toggle"

                            onclick="togglePassword()"

                        >

                            <i

                                class="fa-solid fa-eye"

                                id="eyeIcon"

                            ></i>

                        </button>


                    </div>

                </div>


                <!-- OPTIONS -->

                <div class="form-options">


                    <label class="remember">

                        <input

                            type="checkbox"

                            name="remember"

                        >

                        Remember me

                    </label>


                    <a href="#"
                       class="forgot">

                        Forgot Password?

                    </a>


                </div>


                <!-- BUTTON -->

                <button

                    type="submit"

                    class="login-btn"

                >

                    <i class="fa-solid fa-right-to-bracket"></i>

                    Login to Dashboard

                </button>


            </form>


            <div class="back-home">

                <i class="fa-solid fa-arrow-left"></i>

                <a href="../index.php">

                    Back to SportZone

                </a>

            </div>


        </div>


    </div>


</div>


<script>

function togglePassword() {

    const password =
        document.getElementById("password");

    const eyeIcon =
        document.getElementById("eyeIcon");


    if (password.type === "password") {

        password.type = "text";

        eyeIcon.classList.remove("fa-eye");

        eyeIcon.classList.add("fa-eye-slash");

    } else {

        password.type = "password";

        eyeIcon.classList.remove("fa-eye-slash");

        eyeIcon.classList.add("fa-eye");

    }

}

</script>


</body>

</html>