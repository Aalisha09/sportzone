<!-- ================= FOOTER ================= -->

<footer class="footer">

<div class="container">

    <div class="footer-grid">

        <!-- ================= ABOUT ================= -->

        <div class="footer-about">

            <a href="/sports_league/index.php" class="logo footer-logo">

                <div class="logo-icon">
                    <i class="fa-solid fa-trophy"></i>
                </div>

                <div class="logo-text">
                    <span>SPORT</span>
                    <strong>ZONE</strong>
                </div>

            </a>

            <p>
                Your local sports league destination
                for live scores, tournaments, schedules,
                standings and team updates.
            </p>


            <!-- Social Media -->

            <div class="social-icons">

                <!-- Facebook -->
                <a href="https://www.facebook.com/"
                   target="_blank"
                   rel="noopener noreferrer"
                   class="social-btn facebook"
                   title="Follow us on Facebook">

                    <i class="fa-brands fa-facebook-f"></i>

                </a>


                <!-- Instagram -->
                <a href="https://www.instagram.com/"
                   target="_blank"
                   rel="noopener noreferrer"
                   class="social-btn instagram"
                   title="Follow us on Instagram">

                    <i class="fa-brands fa-instagram"></i>

                </a>


                <!-- X -->
                <a href="https://x.com/"
                   target="_blank"
                   rel="noopener noreferrer"
                   class="social-btn twitter"
                   title="Follow us on X">

                    <i class="fa-brands fa-x-twitter"></i>

                </a>


                <!-- YouTube -->
                <a href="https://www.youtube.com/"
                   target="_blank"
                   rel="noopener noreferrer"
                   class="social-btn youtube"
                   title="Subscribe on YouTube">

                    <i class="fa-brands fa-youtube"></i>

                </a>

            </div>

        </div>


        <!-- ================= QUICK LINKS ================= -->

        <div class="footer-column">

            <h3>Quick Links</h3>

            <a href="/sports_league/index.php">
                <i class="fa-solid fa-house"></i>
                Home
            </a>

            <a href="/sports_league/pages/live-scores.php">
                <i class="fa-solid fa-bolt"></i>
                Live Scores
            </a>

            <a href="/sports_league/pages/schedule.php">
                <i class="fa-solid fa-calendar-days"></i>
                Schedule
            </a>

            <a href="/sports_league/pages/standing.php">
                <i class="fa-solid fa-ranking-star"></i>
                Standings
            </a>

            <a href="/sports_league/pages/teams.php">
                <i class="fa-solid fa-people-group"></i>
                Teams
            </a>

            <a href="/sports_league/pages/players.php">
                <i class="fa-solid fa-people-group"></i>
                Players
            </a>


        </div>


        <!-- ================= SPORTS ================= -->

        <div class="footer-column">

            <h3>Sports</h3>

            <a href="/sports_league/pages/football.php">
                <i class="fa-solid fa-futbol"></i>
                Football
            </a>

            <a href="/sports_league/pages/basketball.php">
                <i class="fa-solid fa-basketball"></i>
                Basketball
            </a>

            <a href="/sports_league/pages/cricket.php">
                <i class="fa-solid fa-baseball-bat-ball"></i>
                Cricket
            </a>

            <a href="/sports_league/pages/volleyball.php">
                <i class="fa-solid fa-volleyball"></i>
                Volleyball
            </a>

        </div>


        <!-- ================= CONTACT ================= -->

        <div class="footer-column">

            <h3>Contact Us</h3>

            <p>
                <i class="fa-solid fa-location-dot"></i>
                Local Sports Arena
            </p>

            <p>
                <i class="fa-solid fa-envelope"></i>

                <a href="mailto:info@sportzone.com">
                    info@sportzone.com
                </a>

            </p>

            <p>
                <i class="fa-solid fa-phone"></i>

                <a href="tel:+919876543210">
                    +91 98765 43210
                </a>

            </p>

            <p>
                <i class="fa-solid fa-clock"></i>
                Mon - Sat: 9:00 AM - 6:00 PM
            </p>

        </div>

    </div>


    <!-- ================= FOOTER BOTTOM ================= -->

    <div class="footer-bottom">

        <p>
            © 2026 <strong>SportZone</strong>.
            All Rights Reserved.
        </p>

        <div class="footer-bottom-links">

            <a href="/sports_league/pages/privacy.php">
                Privacy Policy
            </a>

            <a href="/sports_league/pages/terms.php">
                Terms & Conditions
            </a>

        </div>

    </div>

</div>


</footer>

<!-- ================= BACK TO TOP ================= -->

<button id="backToTop"
     class="back-to-top"
     title="Back to top">


<i class="fa-solid fa-arrow-up"></i>


</button>

<!-- ================= AOS ================= -->

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<!-- ================= MAIN JS ================= -->

<script src="/sports_league/assets/js/script.js"></script>

<script>
    // Initialize AOS
    if (typeof AOS !== "undefined") {
        AOS.init({
            duration: 800,
            once: true
        });
    }


    // Back To Top
    const backToTop = document.getElementById("backToTop");

    if (backToTop) {

        window.addEventListener("scroll", function () {

            if (window.scrollY > 300) {
                backToTop.classList.add("show");
            } else {
                backToTop.classList.remove("show");
            }

        });


        backToTop.addEventListener("click", function () {

            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });

        });

    }
</script>

</body>

</html>
