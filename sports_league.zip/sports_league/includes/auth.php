<?php
/**
 * SPORTSHUB - Auth Helpers
 * includes/auth.php
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isLoggedIn() && $_SESSION['role'] === 'admin';
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . rootUrl() . 'login.php');
        exit;
    }
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: ' . rootUrl() . 'index.php');
        exit;
    }
}

/** Returns a relative path back to the site root regardless of current folder depth */
function rootUrl() {
    $script = $_SERVER['SCRIPT_NAME'];
    if (strpos($script, '/admin/') !== false || strpos($script, '/pages/') !== false) {
        return '../';
    }
    return '';
}

function clean($conn, $value) {
    return mysqli_real_escape_string($conn, htmlspecialchars(trim($value ?? ''), ENT_QUOTES, 'UTF-8'));
}

function flash($key, $message = null) {
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return;
    }
    if (!empty($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}