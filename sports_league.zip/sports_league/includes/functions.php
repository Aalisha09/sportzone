<?php
/* =========================================================
   SPORTZONE - DATABASE & COMMON FUNCTIONS
========================================================= */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/* =========================================================
   DATABASE CONNECTION
========================================================= */

$host = "localhost";
$username = "root";
$password = "";
$database = "sports_league";

$conn = new mysqli(
    $host,
    $username,
    $password,
    $database
);

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");


/* =========================================================
   SECURITY / ESCAPE FUNCTION
========================================================= */

function clean($value)
{
    global $conn;

    return mysqli_real_escape_string(
        $conn,
        trim($value)
    );
}


/* =========================================================
   DISPLAY SAFE TEXT
========================================================= */

function e($value)
{
    return htmlspecialchars(
        $value ?? '',
        ENT_QUOTES,
        'UTF-8'
    );
}


/* =========================================================
   ADMIN LOGIN CHECK
========================================================= */

function isAdminLoggedIn()
{
    return isset($_SESSION['admin_id']);
}


/* =========================================================
   REQUIRE ADMIN LOGIN
========================================================= */

function requireAdmin()
{
    if (!isAdminLoggedIn()) {
        header("Location: login.php");
        exit;
    }
}


/* =========================================================
   ADMIN LOGOUT
========================================================= */

function adminLogout()
{
    $_SESSION = [];

    if (ini_get("session.use_cookies")) {

        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }

    session_destroy();

    header("Location: login.php");
    exit;
}


/* =========================================================
   REDIRECT FUNCTION
========================================================= */

function redirect($url)
{
    header("Location: " . $url);
    exit;
}


/* =========================================================
   CHECK DATABASE TABLE
========================================================= */

function tableExists($table)
{
    global $conn;

    $table = clean($table);

    $result = $conn->query(
        "SHOW TABLES LIKE '$table'"
    );

    return $result && $result->num_rows > 0;
}


/* =========================================================
   GET TOTAL RECORDS
========================================================= */

function getTotal($table)
{
    global $conn;

    $allowedTables = [
        'admins',
        'teams',
        'matches',
        'players',
        'tournaments',
        'venues'
    ];

    if (!in_array($table, $allowedTables)) {
        return 0;
    }

    $result = $conn->query(
        "SELECT COUNT(*) AS total FROM `$table`"
    );

    if ($result) {

        $row = $result->fetch_assoc();

        return (int)$row['total'];
    }

    return 0;
}


/* =========================================================
   GET ADMIN BY EMAIL
========================================================= */

function getAdminByEmail($email)
{
    global $conn;

    $stmt = $conn->prepare(
        "SELECT * FROM admins WHERE email = ? LIMIT 1"
    );

    if (!$stmt) {
        return null;
    }

    $stmt->bind_param("s", $email);

    $stmt->execute();

    $result = $stmt->get_result();

    return $result->fetch_assoc();
}


/* =========================================================
   GET ADMIN BY USERNAME
========================================================= */

function getAdminByUsername($username)
{
    global $conn;

    $stmt = $conn->prepare(
        "SELECT * FROM admins WHERE username = ? LIMIT 1"
    );

    if (!$stmt) {
        return null;
    }

    $stmt->bind_param("s", $username);

    $stmt->execute();

    $result = $stmt->get_result();

    return $result->fetch_assoc();
}


/* =========================================================
   VERIFY ADMIN PASSWORD
========================================================= */

function verifyAdminPassword($password, $hashedPassword)
{
    return password_verify(
        $password,
        $hashedPassword
    );
}


/* =========================================================
   LOGIN ADMIN
========================================================= */

function loginAdmin($admin)
{
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['admin_email'] = $admin['email'];

    session_regenerate_id(true);
}


/* =========================================================
   GET CURRENT ADMIN
========================================================= */

function currentAdmin()
{
    global $conn;

    if (!isset($_SESSION['admin_id'])) {
        return null;
    }

    $id = (int)$_SESSION['admin_id'];

    $stmt = $conn->prepare(
        "SELECT * FROM admins WHERE id = ? LIMIT 1"
    );

    if (!$stmt) {
        return null;
    }

    $stmt->bind_param("i", $id);

    $stmt->execute();

    $result = $stmt->get_result();

    return $result->fetch_assoc();
}


/* =========================================================
   FLASH MESSAGE
========================================================= */

function setMessage($type, $message)
{
    $_SESSION['flash_type'] = $type;
    $_SESSION['flash_message'] = $message;
}


/* =========================================================
   GET FLASH MESSAGE
========================================================= */

function getMessage()
{
    if (
        isset($_SESSION['flash_message']) &&
        isset($_SESSION['flash_type'])
    ) {

        $message = [
            'type' => $_SESSION['flash_type'],
            'text' => $_SESSION['flash_message']
        ];

        unset($_SESSION['flash_type']);
        unset($_SESSION['flash_message']);

        return $message;
    }

    return null;
}


/* =========================================================
   DATE FORMAT
========================================================= */

function formatDate($date)
{
    if (empty($date)) {
        return '';
    }

    return date(
        "d M Y",
        strtotime($date)
    );
}


/* =========================================================
   TIME FORMAT
========================================================= */

function formatTime($time)
{
    if (empty($time)) {
        return '';
    }

    return date(
        "h:i A",
        strtotime($time)
    );
}


/* =========================================================
   STATUS BADGE CLASS
========================================================= */

function statusClass($status)
{
    switch (strtolower($status)) {

        case 'live':
            return 'status-live';

        case 'completed':
            return 'status-completed';

        case 'upcoming':
            return 'status-upcoming';

        case 'cancelled':
            return 'status-cancelled';

        default:
            return 'status-default';
    }
}
?>