<?php
$base = '/sports_league/';
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>
        <?php echo isset($page_title) ? $page_title : 'SportZone | Local Sports League'; ?>
    </title>


    <!-- Google Fonts -->

    <link rel="preconnect"
          href="https://fonts.googleapis.com">

    <link rel="preconnect"
          href="https://fonts.gstatic.com"
          crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap"
        rel="stylesheet">


    <!-- Font Awesome -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


    <!-- AOS Animation -->

    <link
        rel="stylesheet"
        href="https://unpkg.com/aos@2.3.1/dist/aos.css">


    <!-- YOUR CSS -->

    <link
        rel="stylesheet"
        href="<?php echo $base; ?>assets/css/style.css">

</head>


<body>


<!-- ================= NAVBAR ================= -->

<header class="main-header">

    <div class="container nav-container">


        <!-- LOGO -->

        <a
            href="<?php echo $base; ?>index.php"
            class="logo"
        >

            <img
                src="<?php echo $base; ?>assets/images/logo.png"
                alt="SportZone Logo"
                class="logo-image"
            >

            <div class="logo-text">

                <span>LOCAL</span>

                <strong>SPORTZONE</strong>

            </div>

        </a>


        <!-- MOBILE BUTTON -->

        <button
            class="menu-toggle"
            id="menuToggle"
            type="button"
        >

            <i class="fa-solid fa-bars"></i>

        </button>


        <!-- NAVIGATION -->

        <nav
            class="navbar"
            id="navbar"
        >

            <a href="<?php echo $base; ?>index.php">

                <i class="fa-solid fa-house"></i>

                Home

            </a>


            <a href="<?php echo $base; ?>pages/about.php">

                <i class="fa-solid fa-circle-info"></i>

                About

            </a>


            <a href="<?php echo $base; ?>pages/live-scores.php">

                <i class="fa-solid fa-bolt"></i>

                Live Scores

            </a>


            <a href="<?php echo $base; ?>pages/schedule.php">

                <i class="fa-solid fa-calendar-days"></i>

                Schedule

            </a>


            <a href="<?php echo $base; ?>pages/standing.php">

                <i class="fa-solid fa-ranking-star"></i>

                Standings

            </a>


            <a href="<?php echo $base; ?>pages/teams.php">

                <i class="fa-solid fa-users"></i>

                Teams

            </a>

            <a href="<?php echo $base; ?>pages/players.php">

                <i class="fa-solid fa-users"></i>

                Players

            </a>

        </nav>


        <!-- LOGIN -->

        <a
            href="<?php echo $base; ?>admin/login.php"
            class="header-btn"
        >

            <i class="fa-solid fa-user"></i>

            Admin Login

        </a>

    </div>

</header>


<!-- ================= LIVE TICKER ================= -->

<div class="live-ticker">

    <div class="ticker-label">

        <span class="live-dot"></span>

        LIVE NOW

    </div>


    <div class="ticker-content">


        <span>
            ⚽ Eagles FC 2 - 1 Tigers United
        </span>


        <span>
            🏀 Warriors 78 - 72 Panthers
        </span>


        <span>
            🏏 Ahmedabad Kings 145/6
        </span>


        <span>
            ⚽ City FC 3 - 2 United FC
        </span>


    </div>

</div>


<!-- ================= AOS ================= -->

<script
    src="https://unpkg.com/aos@2.3.1/dist/aos.js">
</script>

<script>

    AOS.init({
        duration: 800,
        once: true
    });


    /* MOBILE MENU */

    const menuToggle = document.getElementById('menuToggle');

    const navbar = document.getElementById('navbar');


    if (menuToggle && navbar) {

        menuToggle.addEventListener('click', function () {

            navbar.classList.toggle('active');

        });

    }

</script>