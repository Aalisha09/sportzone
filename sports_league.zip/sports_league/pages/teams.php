<?php
$page_title = "Teams | SportZone";
require_once '../includes/header.php';
?>

<style>

/* =========================================================
   TEAMS PAGE
========================================================= */

.teams-page {
    background: #05090e;
    color: #ffffff;
    min-height: 100vh;
}


/* =========================================================
   HERO
========================================================= */

.teams-hero {
    min-height: 380px;
    display: flex;
    align-items: center;
    position: relative;
    overflow: hidden;

    background:
        radial-gradient(
            circle at 80% 40%,
            rgba(255, 91, 37, 0.18),
            transparent 35%
        ),
        linear-gradient(
            90deg,
            #05090e 0%,
            #080d13 60%,
            #0b1118 100%
        );
}

.teams-hero::before {
    content: "";

    position: absolute;

    width: 500px;
    height: 500px;

    right: -180px;
    top: -180px;

    border-radius: 50%;

    background: rgba(255, 91, 37, 0.08);

    animation: heroGlow 5s ease-in-out infinite alternate;
}

@keyframes heroGlow {

    from {
        transform: scale(1);
    }

    to {
        transform: scale(1.15);
    }

}

.teams-hero-content {
    width: min(1150px, 92%);
    margin: auto;

    position: relative;
    z-index: 2;
}

.hero-label {
    color: #ff5b25;

    font-size: 12px;
    font-weight: 800;

    letter-spacing: 2px;

    margin-bottom: 18px;
}

.hero-label i {
    margin-right: 7px;
}

.teams-hero h1 {
    margin: 0 0 20px;

    font-size: clamp(45px, 6vw, 72px);

    font-weight: 900;

    letter-spacing: -2px;
}

.teams-hero h1 span {
    color: #ff5b25;
}

.teams-hero p {
    max-width: 650px;

    color: #9da8b3;

    font-size: 15px;

    line-height: 1.8;
}


/* =========================================================
   MAIN
========================================================= */

.teams-section {
    padding: 80px 0;
}

.teams-container {
    width: min(1150px, 92%);
    margin: auto;
}


/* =========================================================
   SECTION HEADING
========================================================= */

.section-heading {
    text-align: center;
    margin-bottom: 45px;
}

.section-label {
    color: #ff5b25;

    font-size: 11px;
    font-weight: 800;

    letter-spacing: 2px;

    margin-bottom: 12px;
}

.section-label i {
    margin-right: 7px;
}

.section-heading h2 {
    font-size: 38px;
    font-weight: 900;

    margin-bottom: 12px;
}

.section-heading h2 span {
    color: #ff5b25;
}

.section-heading p {
    color: #77828e;
    font-size: 12px;
}


/* =========================================================
   FILTERS
========================================================= */

.team-filters {
    display: flex;

    justify-content: center;

    gap: 10px;

    flex-wrap: wrap;

    margin-bottom: 45px;
}

.team-filter {
    border: 1px solid #29343f;

    background: #0d131a;

    color: #8d98a3;

    padding: 11px 18px;

    border-radius: 8px;

    font-family: inherit;

    font-size: 10px;

    font-weight: 800;

    cursor: pointer;

    transition: 0.3s;
}

.team-filter:hover,
.team-filter.active {
    background: #ff5b25;
    border-color: #ff5b25;

    color: #ffffff;
}


/* =========================================================
   TEAM GRID
========================================================= */

.team-grid {

    display: grid;

    grid-template-columns: repeat(3, 1fr);

    gap: 22px;
}


/* =========================================================
   TEAM CARD
========================================================= */

.team-card {

    position: relative;

    background: #0d131a;

    border: 1px solid #242e38;

    border-radius: 16px;

    padding: 28px 24px;

    text-align: center;

    overflow: hidden;

    transition: 0.35s ease;
}

.team-card::before {

    content: "";

    position: absolute;

    top: 0;
    left: 0;

    width: 100%;
    height: 3px;

    background: #ff5b25;

    transform: scaleX(0);

    transform-origin: left;

    transition: 0.35s;
}

.team-card:hover::before {
    transform: scaleX(1);
}

.team-card:hover {

    transform: translateY(-7px);

    border-color: #ff5b25;

    box-shadow:
        0 20px 45px rgba(0,0,0,0.35);
}


/* =========================================================
   TEAM LOGO
========================================================= */

.team-logo-box {

    width: 90px;
    height: 90px;

    margin: 0 auto 20px;

    border-radius: 50%;

    display: flex;

    align-items: center;
    justify-content: center;

    background: #151d26;

    border: 1px solid #303b47;

    color: #ff5b25;

    font-size: 35px;

    transition: 0.35s;
}

.team-card:hover .team-logo-box {

    transform: scale(1.08);

    background: rgba(255,91,37,0.10);

    box-shadow:
        0 0 30px rgba(255,91,37,0.12);
}


/* =========================================================
   TEAM CONTENT
========================================================= */

.team-sport {

    display: inline-block;

    padding: 5px 9px;

    border-radius: 5px;

    background: rgba(255,91,37,0.09);

    color: #ff5b25;

    font-size: 8px;

    font-weight: 800;

    letter-spacing: 1px;

    margin-bottom: 10px;
}

.team-card h3 {

    font-size: 17px;

    font-weight: 800;

    margin-bottom: 8px;
}

.team-card p {

    color: #687580;

    font-size: 10px;

    line-height: 1.6;

    margin-bottom: 18px;
}


/* =========================================================
   TEAM INFO
========================================================= */

.team-info {

    display: grid;

    grid-template-columns: repeat(3,1fr);

    border-top: 1px solid #202a34;

    border-bottom: 1px solid #202a34;

    padding: 15px 0;

    margin-bottom: 18px;
}

.info-box {

    border-right: 1px solid #202a34;
}

.info-box:last-child {
    border-right: none;
}

.info-box strong {

    display: block;

    font-size: 15px;

    color: #ffffff;

    margin-bottom: 4px;
}

.info-box span {

    color: #697580;

    font-size: 8px;

    font-weight: 700;

    text-transform: uppercase;
}


/* =========================================================
   VIEW TEAM BUTTON
========================================================= */

.team-btn {

    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 8px;

    width: 100%;

    padding: 11px 15px;

    border: 1px solid #303b46;

    border-radius: 7px;

    background: #151d25;

    color: #aab4be;

    font-size: 9px;

    font-weight: 800;

    transition: 0.3s;
}

.team-btn:hover {

    background: #ff5b25;

    border-color: #ff5b25;

    color: #ffffff;
}


/* =========================================================
   FEATURE SECTION
========================================================= */

.team-feature {

    margin-top: 70px;

    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 25px;
}

.feature-card {

    padding: 35px;

    border: 1px solid #242e38;

    border-radius: 16px;

    background:
        radial-gradient(
            circle at top right,
            rgba(255,91,37,0.09),
            transparent 45%
        ),
        #0d131a;
}

.feature-icon {

    width: 52px;
    height: 52px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 12px;

    background: rgba(255,91,37,0.10);

    color: #ff5b25;

    font-size: 21px;

    margin-bottom: 20px;
}

.feature-card h3 {

    font-size: 19px;

    font-weight: 800;

    margin-bottom: 10px;
}

.feature-card p {

    color: #75818d;

    font-size: 11px;

    line-height: 1.8;
}


/* =========================================================
   CTA
========================================================= */

.teams-cta {

    margin-top: 70px;

    padding: 50px 30px;

    text-align: center;

    border: 1px solid #29343f;

    border-radius: 18px;

    background:
        radial-gradient(
            circle at center,
            rgba(255,91,37,0.10),
            transparent 55%
        );
}

.teams-cta h2 {

    font-size: 30px;

    font-weight: 900;

    margin-bottom: 12px;
}

.teams-cta h2 span {
    color: #ff5b25;
}

.teams-cta p {

    max-width: 600px;

    margin: auto;

    color: #77828e;

    font-size: 11px;

    line-height: 1.8;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width: 1000px) {

    .team-grid {
        grid-template-columns: repeat(2,1fr);
    }

}

@media(max-width: 700px) {

    .teams-hero {
        min-height: 330px;
    }

    .teams-hero h1 {
        font-size: 48px;
    }

    .teams-section {
        padding: 55px 0;
    }

    .team-grid {
        grid-template-columns: 1fr;
    }

    .team-feature {
        grid-template-columns: 1fr;
    }

}

@media(max-width: 500px) {

    .teams-container {
        width: 92%;
    }

    .section-heading h2 {
        font-size: 30px;
    }

    .team-card {
        padding: 24px 18px;
    }

}

</style>


<!-- =========================================================
     TEAMS PAGE
========================================================= -->

<div class="teams-page">


    <!-- =====================================================
         HERO
    ===================================================== -->

    <section class="teams-hero">

        <div class="teams-hero-content">

            <div class="hero-label">

                <i class="fa-solid fa-users"></i>

                LOCAL SPORTS COMMUNITY

            </div>


            <h1>

                MEET THE

                <span>TEAMS.</span>

            </h1>


            <p>

                Discover the teams competing across local
                football, cricket, basketball and volleyball
                tournaments. Explore their players,
                achievements and match performance.

            </p>

        </div>

    </section>



    <!-- =====================================================
         TEAM SECTION
    ===================================================== -->

    <section class="teams-section">

        <div class="teams-container">


            <!-- HEADING -->

            <div class="section-heading">

                <div class="section-label">

                    <i class="fa-solid fa-shield-halved"></i>

                    OUR TEAMS

                </div>


                <h2>

                    Local

                    <span>Champions.</span>

                </h2>


                <p>

                    Explore all registered teams participating
                    in SportZone tournaments.

                </p>

            </div>



            <!-- FILTER -->

            <div class="team-filters">

                <button class="team-filter active">

                    All Teams

                </button>

                <button class="team-filter" onclick="window.location.href='football.php';">

                    ⚽ Football

                </button>

                <button class="team-filter" onclick="window.location.href='cricket.php';">
    🏏 Cricket
</button>

                <button class="team-filter" onclick="window.location.href='basketball.php';">

                    🏀 Basketball

                </button>

                <button class="team-filter" onclick="window.location.href='volleyball.php';">

                    🏐 Volleyball

                </button>

            </div>



            <!-- =================================================
                 TEAM GRID
            ================================================= -->

            <div class="team-grid">


                <!-- TEAM 1 -->

                <div class="team-card">

                    <div class="team-logo-box">

                        <i class="fa-solid fa-shield-halved"></i>

                    </div>


                    <div class="team-sport">

                        FOOTBALL

                    </div>


                    <h3>

                        Eagles FC

                    </h3>


                    <p>

                        One of the strongest football teams
                        competing in the City Football League.

                    </p>


                    <div class="team-info">

                        <div class="info-box">

                            <strong>18</strong>

                            <span>Players</span>

                        </div>


                        <div class="info-box">

                            <strong>12</strong>

                            <span>Matches</span>

                        </div>


                        <div class="info-box">

                            <strong>9</strong>

                            <span>Wins</span>

                        </div>

                    </div>


                    <a href="#" class="team-btn">

                        <i class="fa-solid fa-arrow-right"></i>

                        View Team

                    </a>

                </div>



                <!-- TEAM 2 -->

                <div class="team-card">

                    <div class="team-logo-box">

                        <i class="fa-solid fa-shield"></i>

                    </div>


                    <div class="team-sport">

                        FOOTBALL

                    </div>


                    <h3>

                        Tigers United

                    </h3>


                    <p>

                        A competitive football team known
                        for its strong defensive performance.

                    </p>


                    <div class="team-info">

                        <div class="info-box">

                            <strong>20</strong>

                            <span>Players</span>

                        </div>


                        <div class="info-box">

                            <strong>12</strong>

                            <span>Matches</span>

                        </div>


                        <div class="info-box">

                            <strong>7</strong>

                            <span>Wins</span>

                        </div>

                    </div>


                    <a href="#" class="team-btn">

                        <i class="fa-solid fa-arrow-right"></i>

                        View Team

                    </a>

                </div>



                <!-- TEAM 3 -->

                <div class="team-card">

                    <div class="team-logo-box">

                        <i class="fa-solid fa-basketball"></i>

                    </div>


                    <div class="team-sport">

                        BASKETBALL

                    </div>


                    <h3>

                        City Warriors

                    </h3>


                    <p>

                        High-energy basketball team competing
                        in the Ahmedabad City League.

                    </p>


                    <div class="team-info">

                        <div class="info-box">

                            <strong>14</strong>

                            <span>Players</span>

                        </div>


                        <div class="info-box">

                            <strong>10</strong>

                            <span>Matches</span>

                        </div>


                        <div class="info-box">

                            <strong>8</strong>

                            <span>Wins</span>

                        </div>

                    </div>


                    <a href="#" class="team-btn">

                        <i class="fa-solid fa-arrow-right"></i>

                        View Team

                    </a>

                </div>



                <!-- TEAM 4 -->

                <div class="team-card">

                    <div class="team-logo-box">

                        <i class="fa-solid fa-baseball-bat-ball"></i>

                    </div>


                    <div class="team-sport">

                        CRICKET

                    </div>


                    <h3>

                        Ahmedabad Kings

                    </h3>


                    <p>

                        A powerful local cricket team competing
                        in the Gujarat T20 League.

                    </p>


                    <div class="team-info">

                        <div class="info-box">

                            <strong>15</strong>

                            <span>Players</span>

                        </div>


                        <div class="info-box">

                            <strong>11</strong>

                            <span>Matches</span>

                        </div>


                        <div class="info-box">

                            <strong>8</strong>

                            <span>Wins</span>

                        </div>

                    </div>


                    <a href="#" class="team-btn">

                        <i class="fa-solid fa-arrow-right"></i>

                        View Team

                    </a>

                </div>



                <!-- TEAM 5 -->

                <div class="team-card">

                    <div class="team-logo-box">

                        <i class="fa-solid fa-volleyball"></i>

                    </div>


                    <div class="team-sport">

                        VOLLEYBALL

                    </div>


                    <h3>

                        Gujarat Smashers

                    </h3>


                    <p>

                        A fast and energetic volleyball team
                        competing in the Gujarat Volleyball Cup.

                    </p>


                    <div class="team-info">

                        <div class="info-box">

                            <strong>12</strong>

                            <span>Players</span>

                        </div>


                        <div class="info-box">

                            <strong>9</strong>

                            <span>Matches</span>

                        </div>


                        <div class="info-box">

                            <strong>6</strong>

                            <span>Wins</span>

                        </div>

                    </div>


                    <a href="#" class="team-btn">

                        <i class="fa-solid fa-arrow-right"></i>

                        View Team

                    </a>

                </div>



                <!-- TEAM 6 -->

                <div class="team-card">

                    <div class="team-logo-box">

                        <i class="fa-solid fa-shield"></i>

                    </div>


                    <div class="team-sport">

                        BASKETBALL

                    </div>


                    <h3>

                        Ahmedabad Panthers

                    </h3>


                    <p>

                        A young and talented basketball squad
                        competing across local championships.

                    </p>


                    <div class="team-info">

                        <div class="info-box">

                            <strong>13</strong>

                            <span>Players</span>

                        </div>


                        <div class="info-box">

                            <strong>10</strong>

                            <span>Matches</span>

                        </div>


                        <div class="info-box">

                            <strong>6</strong>

                            <span>Wins</span>

                        </div>

                    </div>


                    <a href="#" class="team-btn">

                        <i class="fa-solid fa-arrow-right"></i>

                        View Team

                    </a>

                </div>


            </div>



            <!-- =================================================
                 FEATURE CARDS
            ================================================= -->

            <div class="team-feature">


                <div class="feature-card">

                    <div class="feature-icon">

                        <i class="fa-solid fa-trophy"></i>

                    </div>


                    <h3>

                        Compete & Win

                    </h3>


                    <p>

                        Teams can participate in local tournaments,
                        track their performance and compete for
                        championship trophies throughout the season.

                    </p>

                </div>



                <div class="feature-card">

                    <div class="feature-icon">

                        <i class="fa-solid fa-chart-line"></i>

                    </div>


                    <h3>

                        Track Performance

                    </h3>


                    <p>

                        Follow team wins, matches, standings and
                        live scores to understand how every team
                        is performing throughout the tournament.

                    </p>

                </div>


            </div>



            <!-- =================================================
                 CTA
            ================================================= -->

            <div class="teams-cta">

                <h2>

                    Ready To

                    <span>Compete?</span>

                </h2>


                <p>

                    Join the SportZone local sports community
                    and take your team to the next level.

                </p>

            </div>


        </div>

    </section>

</div>


<?php
require_once '../includes/footer.php';
?>