<?php
$page_title = "Live Scores | SportZone";
require_once '../includes/header.php';
?>

<style>
/* =========================================================
   SPORTZONE LIVE SCORE PAGE
========================================================= */

.live-score-page {
    background:
        radial-gradient(circle at 10% 10%, rgba(255,91,37,.08), transparent 30%),
        radial-gradient(circle at 90% 20%, rgba(255,91,37,.05), transparent 25%),
        #070b10;
    color: #fff;
    min-height: 100vh;
    padding-bottom: 80px;
}

/* HERO */
.score-hero {
    padding: 80px 20px 55px;
    text-align: center;
    border-bottom: 1px solid #202832;
}

.score-hero .live-label {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    background: rgba(255, 91, 37, .12);
    border: 1px solid rgba(255, 91, 37, .35);
    color: #ff7045;
    padding: 8px 16px;
    border-radius: 50px;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 1px;
    margin-bottom: 18px;
}

.live-dot {
    width: 8px;
    height: 8px;
    background: #ff3b30;
    border-radius: 50%;
    box-shadow: 0 0 12px #ff3b30;
    animation: pulse 1.4s infinite;
}

@keyframes pulse {
    0% { opacity: 1; transform: scale(1); }
    50% { opacity: .45; transform: scale(.75); }
    100% { opacity: 1; transform: scale(1); }
}

.score-hero h1 {
    font-size: clamp(38px, 6vw, 72px);
    font-weight: 900;
    margin: 0;
    line-height: 1;
}

.score-hero h1 span {
    color: #ff5b25;
}

.score-hero p {
    max-width: 700px;
    margin: 22px auto 0;
    color: #929ca8;
    font-size: 16px;
}

/* FILTER */
.sport-filter {
    max-width: 1250px;
    margin: 35px auto 15px;
    padding: 0 20px;
    display: flex;
    justify-content: center;
    gap: 10px;
    flex-wrap: wrap;
}

.filter-btn {
    background: #10161d;
    color: #aeb7c0;
    border: 1px solid #26313b;
    padding: 11px 20px;
    border-radius: 30px;
    cursor: pointer;
    font-weight: 700;
    transition: .3s;
}

.filter-btn:hover,
.filter-btn.active {
    background: #ff5b25;
    color: #fff;
    border-color: #ff5b25;
}

/* MAIN */
.score-container {
    max-width: 1250px;
    margin: auto;
    padding: 15px 20px 0;
}

.score-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 25px;
}

/* CARD */
.sport-card {
    background: linear-gradient(145deg, #10161d, #0b1016);
    border: 1px solid #26313b;
    border-radius: 22px;
    overflow: hidden;
    transition: .3s;
}

.sport-card:hover {
    border-color: rgba(255,91,37,.55);
    transform: translateY(-4px);
}

.sport-card.hidden {
    display: none;
}

.card-top {
    padding: 18px 20px;
    border-bottom: 1px solid #242d36;
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
}

.league-info {
    display: flex;
    gap: 12px;
    align-items: center;
}

.sport-icon {
    width: 42px;
    height: 42px;
    border-radius: 12px;
    background: rgba(255,91,37,.12);
    color: #ff6a3d;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
}

.league-name {
    font-weight: 800;
    font-size: 14px;
}

.venue {
    color: #77838f;
    font-size: 12px;
    margin-top: 4px;
}

.live-status {
    color: #ff4a40;
    background: rgba(255,59,48,.1);
    border: 1px solid rgba(255,59,48,.25);
    padding: 7px 11px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 800;
}

/* SCORE AREA */
.main-score {
    padding: 28px 20px;
}

.teams {
    display: grid;
    grid-template-columns: 1fr 120px 1fr;
    align-items: center;
    text-align: center;
    gap: 15px;
}

.team-name {
    font-size: 18px;
    font-weight: 800;
}

.team-city {
    color: #727e89;
    font-size: 12px;
    margin-top: 5px;
}

.team-score {
    font-size: 43px;
    font-weight: 900;
    line-height: 1;
    color: #fff;
}

.score-divider {
    font-size: 12px;
    color: #68747f;
    margin: 7px 0;
}

.match-time {
    display: inline-block;
    margin-top: 10px;
    color: #ff7045;
    font-weight: 800;
    font-size: 13px;
}

/* SECTION TITLE */
.detail-title {
    padding: 0 20px;
    margin-top: 5px;
    color: #ff7045;
    font-size: 12px;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: 1px;
}

/* TABLE */
.stats-table {
    width: calc(100% - 40px);
    margin: 12px 20px 20px;
    border-collapse: collapse;
    font-size: 12px;
}

.stats-table th {
    color: #687580;
    font-weight: 700;
    text-align: left;
    padding: 9px 7px;
    border-bottom: 1px solid #28323b;
}

.stats-table td {
    padding: 10px 7px;
    border-bottom: 1px solid #1c252e;
    color: #dbe1e5;
}

.stats-table tr:last-child td {
    border-bottom: none;
}

.player-name {
    font-weight: 700;
    color: #fff;
}

.player-role {
    display: block;
    color: #66727d;
    font-size: 10px;
    margin-top: 3px;
}

/* INFO BOX */
.info-box {
    margin: 0 20px 20px;
    background: #0a0f14;
    border: 1px solid #222c35;
    border-radius: 14px;
    padding: 15px;
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
}

.info-item {
    text-align: center;
}

.info-item small {
    display: block;
    color: #697580;
    font-size: 10px;
    margin-bottom: 5px;
}

.info-item strong {
    font-size: 14px;
}

/* CRICKET */
.cricket-score {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #0a0f14;
    border: 1px solid #242e38;
    padding: 16px;
    margin: 0 20px 18px;
    border-radius: 15px;
}

.cricket-score .big-score {
    font-size: 31px;
    font-weight: 900;
}

.cricket-score small {
    display: block;
    color: #7d8893;
    margin-top: 4px;
}

.required {
    text-align: right;
}

.required strong {
    color: #ff7045;
    font-size: 18px;
}

/* BALLS */
.balls {
    display: flex;
    gap: 7px;
    flex-wrap: wrap;
}

.ball {
    width: 29px;
    height: 29px;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #172029;
    border: 1px solid #303c47;
    font-size: 11px;
    font-weight: 800;
}

.ball.four {
    background: rgba(255,91,37,.16);
    border-color: #ff5b25;
    color: #ff7045;
}

.ball.six {
    background: rgba(53,208,127,.13);
    border-color: #35d07f;
    color: #35d07f;
}

.ball.wicket {
    background: rgba(255,59,48,.15);
    border-color: #ff3b30;
    color: #ff5b50;
}

/* FOOTBALL EVENTS */
.events {
    margin: 0 20px 20px;
}

.event {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 9px 0;
    border-bottom: 1px solid #1d262f;
    font-size: 12px;
}

.event:last-child {
    border-bottom: 0;
}

.event-time {
    color: #ff7045;
    width: 35px;
    font-weight: 800;
}

.event-icon {
    width: 25px;
    height: 25px;
    border-radius: 50%;
    background: #18212a;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #c8d0d6;
}

/* PROGRESS */
.progress-row {
    margin: 0 20px 15px;
}

.progress-head {
    display: flex;
    justify-content: space-between;
    color: #88949e;
    font-size: 11px;
    margin-bottom: 6px;
}

.progress-bar {
    height: 6px;
    background: #1a222a;
    border-radius: 10px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: #ff5b25;
    border-radius: 10px;
}

/* QUARTERS / SETS */
.periods {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    margin: 0 20px 20px;
    background: #0a0f14;
    border: 1px solid #222c35;
    border-radius: 13px;
    overflow: hidden;
}

.period {
    padding: 11px 5px;
    text-align: center;
    border-right: 1px solid #222c35;
}

.period:last-child {
    border-right: none;
}

.period small {
    display: block;
    color: #68747e;
    font-size: 10px;
    margin-bottom: 5px;
}

.period strong {
    font-size: 13px;
}

/* VOLLEYBALL */
.volleyball-score {
    display: flex;
    justify-content: center;
    gap: 15px;
    margin: 0 20px 20px;
}

.set-box {
    min-width: 65px;
    text-align: center;
    padding: 12px 7px;
    background: #0a0f14;
    border: 1px solid #28323b;
    border-radius: 12px;
}

.set-box.active {
    border-color: #ff5b25;
}

.set-box small {
    display: block;
    color: #6f7a85;
    font-size: 10px;
    margin-bottom: 5px;
}

.set-box strong {
    font-size: 18px;
}

/* MATCH FOOTER */
.card-footer {
    border-top: 1px solid #222c35;
    padding: 13px 20px;
    display: flex;
    justify-content: space-between;
    color: #697681;
    font-size: 11px;
}

.card-footer span:last-child {
    color: #ff7045;
}

/* UPCOMING */
.section-heading {
    margin: 60px 0 22px;
}

.section-heading h2 {
    font-size: 28px;
    margin: 0;
}

.section-heading p {
    color: #727e89;
    margin-top: 7px;
}

.upcoming-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 18px;
}

.upcoming-card {
    background: #0e141a;
    border: 1px solid #222c35;
    border-radius: 17px;
    padding: 20px;
}

.upcoming-card .date {
    color: #ff7045;
    font-size: 11px;
    font-weight: 800;
    margin-bottom: 15px;
}

.upcoming-teams {
    display: flex;
    align-items: center;
    justify-content: space-between;
    text-align: center;
}

.upcoming-team {
    width: 40%;
    font-weight: 800;
    font-size: 13px;
}

.vs {
    color: #65717c;
    font-size: 11px;
}

.upcoming-card .venue-small {
    color: #68747f;
    font-size: 11px;
    margin-top: 15px;
    text-align: center;
}

/* RECENT */
.recent-list {
    display: grid;
    gap: 10px;
}

.recent-match {
    background: #0e141a;
    border: 1px solid #222c35;
    border-radius: 14px;
    padding: 15px 18px;
    display: grid;
    grid-template-columns: 100px 1fr 100px;
    align-items: center;
    gap: 15px;
}

.recent-sport {
    color: #ff7045;
    font-size: 11px;
    font-weight: 800;
}

.recent-teams {
    font-size: 13px;
}

.recent-score {
    text-align: right;
    font-weight: 900;
}

/* RESPONSIVE */
@media(max-width: 1000px) {
    .score-grid {
        grid-template-columns: 1fr;
    }

    .upcoming-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media(max-width: 650px) {
    .score-hero {
        padding: 55px 15px 40px;
    }

    .score-container {
        padding: 10px 12px;
    }

    .teams {
        grid-template-columns: 1fr 80px 1fr;
    }

    .team-name {
        font-size: 14px;
    }

    .team-score {
        font-size: 32px;
    }

    .info-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .upcoming-grid {
        grid-template-columns: 1fr;
    }

    .recent-match {
        grid-template-columns: 75px 1fr 70px;
    }

    .periods {
        grid-template-columns: repeat(2, 1fr);
    }

    .period {
        border-bottom: 1px solid #222c35;
    }

    .volleyball-score {
        overflow-x: auto;
        justify-content: flex-start;
    }
}
</style>


<div class="live-score-page">

    <!-- HERO -->
    <section class="score-hero">

        <div class="live-label">
            <span class="live-dot"></span>
            LIVE SPORTS CENTER
        </div>

        <h1>FOLLOW THE <span>GAME</span> LIVE</h1>

        <p>
            Real-time style match center with detailed scores,
            player statistics, match events and team performance.
        </p>

    </section>


    <!-- FILTER -->
    <div class="sport-filter">

        <button class="filter-btn active" data-filter="all">
            <i class="fa-solid fa-layer-group"></i> All Sports
        </button>

        <button class="filter-btn" data-filter="cricket">
            <i class="fa-solid fa-baseball"></i> Cricket
        </button>

        <button class="filter-btn" data-filter="football">
            <i class="fa-solid fa-futbol"></i> Football
        </button>

        <button class="filter-btn" data-filter="basketball">
            <i class="fa-solid fa-basketball"></i> Basketball
        </button>

        <button class="filter-btn" data-filter="volleyball">
            <i class="fa-solid fa-volleyball"></i> Volleyball
        </button>

    </div>


    <div class="score-container">

        <div class="score-grid">


            <!-- =====================================================
                 CRICKET
            ====================================================== -->
            <article class="sport-card" data-sport="cricket">

                <div class="card-top">

                    <div class="league-info">

                        <div class="sport-icon">
                            <i class="fa-solid fa-baseball"></i>
                        </div>

                        <div>
                            <div class="league-name">
                                Gujarat Premier T20 League
                            </div>

                            <div class="venue">
                                Narendra Modi Cricket Stadium • Ahmedabad
                            </div>
                        </div>

                    </div>

                    <div class="live-status">
                        <span class="live-dot"></span>
                        LIVE
                    </div>

                </div>


                <div class="main-score">

                    <div class="teams">

                        <div>
                            <div class="team-name">
                                Ahmedabad Strikers
                            </div>
                            <div class="team-city">
                                Gujarat
                            </div>
                        </div>

                        <div>
                            <div class="team-score">178/4</div>
                            <div class="score-divider">
                                18.2 / 20 OV
                            </div>
                            <span class="match-time">
                                BATTING
                            </span>
                        </div>

                        <div>
                            <div class="team-name">
                                Surat Warriors
                            </div>
                            <div class="team-city">
                                Gujarat
                            </div>
                        </div>

                    </div>

                </div>


                <div class="cricket-score">

                    <div>
                        <div class="big-score">
                            178/4
                        </div>
                        <small>
                            Ahmedabad Strikers
                        </small>
                    </div>

                    <div class="required">

                        <small>
                            Target
                        </small>

                        <strong>
                            196
                        </strong>

                        <small>
                            Need 18 runs from 10 balls
                        </small>

                    </div>

                </div>


                <div class="detail-title">
                    Current Batters
                </div>

                <table class="stats-table">

                    <thead>
                        <tr>
                            <th>BATTER</th>
                            <th>R</th>
                            <th>B</th>
                            <th>4s</th>
                            <th>6s</th>
                            <th>SR</th>
                        </tr>
                    </thead>

                    <tbody>

                        <tr>
                            <td>
                                <span class="player-name">
                                    Arjun Mehta
                                </span>
                                <span class="player-role">
                                    Right Hand Batter
                                </span>
                            </td>

                            <td>72</td>
                            <td>48</td>
                            <td>7</td>
                            <td>3</td>
                            <td>150.00</td>
                        </tr>

                        <tr>
                            <td>
                                <span class="player-name">
                                    Devansh Patel
                                </span>
                                <span class="player-role">
                                    Left Hand Batter
                                </span>
                            </td>

                            <td>31</td>
                            <td>19</td>
                            <td>3</td>
                            <td>1</td>
                            <td>163.15</td>
                        </tr>

                    </tbody>

                </table>


                <div class="detail-title">
                    Current Bowler
                </div>

                <table class="stats-table">

                    <thead>
                        <tr>
                            <th>BOWLER</th>
                            <th>O</th>
                            <th>M</th>
                            <th>R</th>
                            <th>W</th>
                            <th>ECON</th>
                        </tr>
                    </thead>

                    <tbody>

                        <tr>

                            <td>
                                <span class="player-name">
                                    Rohan Desai
                                </span>

                                <span class="player-role">
                                    Right Arm Fast
                                </span>
                            </td>

                            <td>3.2</td>
                            <td>0</td>
                            <td>28</td>
                            <td>1</td>
                            <td>8.40</td>

                        </tr>

                    </tbody>

                </table>


                <div class="detail-title">
                    Recent Balls
                </div>

                <div class="info-box">

                    <div class="balls">

                        <span class="ball">1</span>
                        <span class="ball four">4</span>
                        <span class="ball">0</span>
                        <span class="ball six">6</span>
                        <span class="ball wicket">W</span>
                        <span class="ball">1</span>
                        <span class="ball four">4</span>
                        <span class="ball">2</span>

                    </div>

                </div>


                <div class="info-box">

                    <div class="info-grid">

                        <div class="info-item">
                            <small>CRR</small>
                            <strong>9.71</strong>
                        </div>

                        <div class="info-item">
                            <small>RRR</small>
                            <strong>10.80</strong>
                        </div>

                        <div class="info-item">
                            <small>PARTNERSHIP</small>
                            <strong>54</strong>
                        </div>

                        <div class="info-item">
                            <small>LAST WKT</small>
                            <strong>124/4</strong>
                        </div>

                    </div>

                </div>


                <div class="card-footer">
                    <span>Last updated 10 sec ago</span>
                    <span>Cricket • T20</span>
                </div>

            </article>



            <!-- =====================================================
                 FOOTBALL
            ====================================================== -->
            <article class="sport-card" data-sport="football">

                <div class="card-top">

                    <div class="league-info">

                        <div class="sport-icon">
                            <i class="fa-solid fa-futbol"></i>
                        </div>

                        <div>
                            <div class="league-name">
                                Gujarat State Football League
                            </div>

                            <div class="venue">
                                EKA Arena • Ahmedabad
                            </div>
                        </div>

                    </div>

                    <div class="live-status">
                        <span class="live-dot"></span>
                        67'
                    </div>

                </div>


                <div class="main-score">

                    <div class="teams">

                        <div>

                            <div class="team-name">
                                Ahmedabad Eagles
                            </div>

                            <div class="team-city">
                                Home
                            </div>

                        </div>

                        <div>

                            <div class="team-score">
                                2 - 1
                            </div>

                            <div class="score-divider">
                                SECOND HALF
                            </div>

                            <span class="match-time">
                                67:24
                            </span>

                        </div>

                        <div>

                            <div class="team-name">
                                Surat Tigers
                            </div>

                            <div class="team-city">
                                Away
                            </div>

                        </div>

                    </div>

                </div>


                <div class="detail-title">
                    Match Events
                </div>

                <div class="events">

                    <div class="event">

                        <span class="event-time">12'</span>

                        <span class="event-icon">
                            <i class="fa-solid fa-futbol"></i>
                        </span>

                        <span>
                            <strong>Vivek Sharma</strong>
                            scored for Ahmedabad Eagles
                        </span>

                    </div>


                    <div class="event">

                        <span class="event-time">31'</span>

                        <span class="event-icon">
                            <i class="fa-solid fa-futbol"></i>
                        </span>

                        <span>
                            <strong>Ritesh Parmar</strong>
                            scored for Surat Tigers
                        </span>

                    </div>


                    <div class="event">

                        <span class="event-time">54'</span>

                        <span class="event-icon">
                            <i class="fa-solid fa-futbol"></i>
                        </span>

                        <span>
                            <strong>Karan Joshi</strong>
                            scored for Ahmedabad Eagles
                        </span>

                    </div>


                    <div class="event">

                        <span class="event-time">61'</span>

                        <span class="event-icon">
                            <i class="fa-solid fa-square"></i>
                        </span>

                        <span>
                            <strong>Manav Shah</strong>
                            received Yellow Card
                        </span>

                    </div>

                </div>


                <div class="detail-title">
                    Match Statistics
                </div>


                <div class="progress-row">

                    <div class="progress-head">
                        <span>Possession</span>
                        <span>58% - 42%</span>
                    </div>

                    <div class="progress-bar">
                        <div class="progress-fill" style="width:58%;"></div>
                    </div>

                </div>


                <div class="info-box">

                    <div class="info-grid">

                        <div class="info-item">
                            <small>SHOTS</small>
                            <strong>13 - 8</strong>
                        </div>

                        <div class="info-item">
                            <small>ON TARGET</small>
                            <strong>7 - 4</strong>
                        </div>

                        <div class="info-item">
                            <small>CORNERS</small>
                            <strong>6 - 3</strong>
                        </div>

                        <div class="info-item">
                            <small>FOULS</small>
                            <strong>8 - 11</strong>
                        </div>

                    </div>

                </div>


                <div class="detail-title">
                    Key Players
                </div>

                <table class="stats-table">

                    <thead>
                        <tr>
                            <th>PLAYER</th>
                            <th>POS</th>
                            <th>SHOTS</th>
                            <th>PASS</th>
                        </tr>
                    </thead>

                    <tbody>

                        <tr>
                            <td class="player-name">Vivek Sharma</td>
                            <td>FW</td>
                            <td>4</td>
                            <td>87%</td>
                        </tr>

                        <tr>
                            <td class="player-name">Karan Joshi</td>
                            <td>FW</td>
                            <td>3</td>
                            <td>82%</td>
                        </tr>

                        <tr>
                            <td class="player-name">Harshil Mehta</td>
                            <td>MID</td>
                            <td>2</td>
                            <td>91%</td>
                        </tr>

                        <tr>
                            <td class="player-name">Ritesh Parmar</td>
                            <td>FW</td>
                            <td>3</td>
                            <td>79%</td>
                        </tr>

                    </tbody>

                </table>


                <div class="card-footer">
                    <span>Match time 67:24</span>
                    <span>Football • LIVE</span>
                </div>

            </article>



            <!-- =====================================================
                 BASKETBALL
            ====================================================== -->
            <article class="sport-card" data-sport="basketball">

                <div class="card-top">

                    <div class="league-info">

                        <div class="sport-icon">
                            <i class="fa-solid fa-basketball"></i>
                        </div>

                        <div>
                            <div class="league-name">
                                Gujarat Basketball Championship
                            </div>

                            <div class="venue">
                                Sardar Patel Indoor Stadium
                            </div>
                        </div>

                    </div>

                    <div class="live-status">
                        <span class="live-dot"></span>
                        Q3 • 04:32
                    </div>

                </div>


                <div class="main-score">

                    <div class="teams">

                        <div>

                            <div class="team-name">
                                Gujarat Warriors
                            </div>

                            <div class="team-city">
                                Home
                            </div>

                        </div>

                        <div>

                            <div class="team-score">
                                68
                            </div>

                            <div class="score-divider">
                                VS
                            </div>

                            <span class="match-time">
                                57
                            </span>

                        </div>

                        <div>

                            <div class="team-name">
                                Vadodara Kings
                            </div>

                            <div class="team-city">
                                Away
                            </div>

                        </div>

                    </div>

                </div>


                <div class="detail-title">
                    Quarter Scores
                </div>

                <div class="periods">

                    <div class="period">
                        <small>Q1</small>
                        <strong>18 - 14</strong>
                    </div>

                    <div class="period">
                        <small>Q2</small>
                        <strong>17 - 16</strong>
                    </div>

                    <div class="period">
                        <small>Q3</small>
                        <strong>33 - 27</strong>
                    </div>

                    <div class="period">
                        <small>Q4</small>
                        <strong>-</strong>
                    </div>

                </div>


                <div class="detail-title">
                    Player Statistics
                </div>

                <table class="stats-table">

                    <thead>
                        <tr>
                            <th>PLAYER</th>
                            <th>PTS</th>
                            <th>REB</th>
                            <th>AST</th>
                            <th>3PT</th>
                        </tr>
                    </thead>

                    <tbody>

                        <tr>

                            <td class="player-name">
                                Yash Malhotra
                            </td>

                            <td>21</td>
                            <td>7</td>
                            <td>5</td>
                            <td>3/6</td>

                        </tr>

                        <tr>

                            <td class="player-name">
                                Dhruv Trivedi
                            </td>

                            <td>16</td>
                            <td>4</td>
                            <td>8</td>
                            <td>2/5</td>

                        </tr>

                        <tr>

                            <td class="player-name">
                                Arnav Shah
                            </td>

                            <td>13</td>
                            <td>9</td>
                            <td>2</td>
                            <td>1/3</td>

                        </tr>

                        <tr>

                            <td class="player-name">
                                Mihir Desai
                            </td>

                            <td>17</td>
                            <td>6</td>
                            <td>4</td>
                            <td>3/7</td>

                        </tr>

                    </tbody>

                </table>


                <div class="detail-title">
                    Team Statistics
                </div>

                <div class="info-box">

                    <div class="info-grid">

                        <div class="info-item">
                            <small>FG%</small>
                            <strong>51%</strong>
                        </div>

                        <div class="info-item">
                            <small>3PT%</small>
                            <strong>42%</strong>
                        </div>

                        <div class="info-item">
                            <small>REBOUNDS</small>
                            <strong>31</strong>
                        </div>

                        <div class="info-item">
                            <small>TURNOVERS</small>
                            <strong>8</strong>
                        </div>

                    </div>

                </div>


                <div class="detail-title">
                    Recent Events
                </div>

                <div class="events">

                    <div class="event">
                        <span class="event-time">04:45</span>
                        <span class="event-icon">
                            <i class="fa-solid fa-basketball"></i>
                        </span>
                        <span>
                            <strong>Yash Malhotra</strong> made 3PT
                        </span>
                    </div>

                    <div class="event">
                        <span class="event-time">04:32</span>
                        <span class="event-icon">
                            <i class="fa-solid fa-basketball"></i>
                        </span>
                        <span>
                            <strong>Dhruv Trivedi</strong> assist
                        </span>
                    </div>

                    <div class="event">
                        <span class="event-time">04:11</span>
                        <span class="event-icon">
                            <i class="fa-solid fa-circle-exclamation"></i>
                        </span>
                        <span>
                            Foul by <strong>Ravi Chauhan</strong>
                        </span>
                    </div>

                </div>


                <div class="card-footer">
                    <span>Quarter 3 • 04:32 remaining</span>
                    <span>Basketball • LIVE</span>
                </div>

            </article>



            <!-- =====================================================
                 VOLLEYBALL
            ====================================================== -->
            <article class="sport-card" data-sport="volleyball">

                <div class="card-top">

                    <div class="league-info">

                        <div class="sport-icon">
                            <i class="fa-solid fa-volleyball"></i>
                        </div>

                        <div>
                            <div class="league-name">
                                Gujarat Volleyball Super League
                            </div>

                            <div class="venue">
                                EKA Indoor Arena • Ahmedabad
                            </div>
                        </div>

                    </div>

                    <div class="live-status">
                        <span class="live-dot"></span>
                        SET 4
                    </div>

                </div>


                <div class="main-score">

                    <div class="teams">

                        <div>

                            <div class="team-name">
                                Ahmedabad Spikers
                            </div>

                            <div class="team-city">
                                Home
                            </div>

                        </div>

                        <div>

                            <div class="team-score">
                                2 - 1
                            </div>

                            <div class="score-divider">
                                SETS
                            </div>

                            <span class="match-time">
                                18 - 16
                            </span>

                        </div>

                        <div>

                            <div class="team-name">
                                Rajkot Smashers
                            </div>

                            <div class="team-city">
                                Away
                            </div>

                        </div>

                    </div>

                </div>


                <div class="detail-title">
                    Set Scores
                </div>

                <div class="volleyball-score">

                    <div class="set-box">
                        <small>SET 1</small>
                        <strong>25 - 21</strong>
                    </div>

                    <div class="set-box">
                        <small>SET 2</small>
                        <strong>22 - 25</strong>
                    </div>

                    <div class="set-box">
                        <small>SET 3</small>
                        <strong>25 - 19</strong>
                    </div>

                    <div class="set-box active">
                        <small>SET 4</small>
                        <strong>18 - 16</strong>
                    </div>

                </div>


                <div class="detail-title">
                    Player Statistics
                </div>

                <table class="stats-table">

                    <thead>
                        <tr>
                            <th>PLAYER</th>
                            <th>KILLS</th>
                            <th>BLOCKS</th>
                            <th>ACES</th>
                            <th>DIGS</th>
                        </tr>
                    </thead>

                    <tbody>

                        <tr>

                            <td class="player-name">
                                Aditya Rathod
                            </td>

                            <td>18</td>
                            <td>4</td>
                            <td>3</td>
                            <td>11</td>

                        </tr>

                        <tr>

                            <td class="player-name">
                                Parth Solanki
                            </td>

                            <td>15</td>
                            <td>5</td>
                            <td>2</td>
                            <td>9</td>

                        </tr>

                        <tr>

                            <td class="player-name">
                                Krish Mehta
                            </td>

                            <td>12</td>
                            <td>3</td>
                            <td>4</td>
                            <td>15</td>

                        </tr>

                        <tr>

                            <td class="player-name">
                                Naman Vora
                            </td>

                            <td>9</td>
                            <td>6</td>
                            <td>1</td>
                            <td>8</td>

                        </tr>

                    </tbody>

                </table>


                <div class="detail-title">
                    Team Performance
                </div>

                <div class="info-box">

                    <div class="info-grid">

                        <div class="info-item">
                            <small>ATTACK %</small>
                            <strong>48%</strong>
                        </div>

                        <div class="info-item">
                            <small>BLOCKS</small>
                            <strong>14</strong>
                        </div>

                        <div class="info-item">
                            <small>ACES</small>
                            <strong>10</strong>
                        </div>

                        <div class="info-item">
                            <small>ERRORS</small>
                            <strong>7</strong>
                        </div>

                    </div>

                </div>


                <div class="detail-title">
                    Recent Points
                </div>

                <div class="events">

                    <div class="event">

                        <span class="event-time">18-16</span>

                        <span class="event-icon">
                            <i class="fa-solid fa-volleyball"></i>
                        </span>

                        <span>
                            <strong>Aditya Rathod</strong>
                            powerful spike
                        </span>

                    </div>


                    <div class="event">

                        <span class="event-time">17-16</span>

                        <span class="event-icon">
                            <i class="fa-solid fa-hand"></i>
                        </span>

                        <span>
                            Block by <strong>Naman Vora</strong>
                        </span>

                    </div>


                    <div class="event">

                        <span class="event-time">16-16</span>

                        <span class="event-icon">
                            <i class="fa-solid fa-volleyball"></i>
                        </span>

                        <span>
                            <strong>Rajkot Smashers</strong> attack point
                        </span>

                    </div>

                </div>


                <div class="card-footer">
                    <span>Set 4 • 18 - 16</span>
                    <span>Volleyball • LIVE</span>
                </div>

            </article>

        </div>



        <!-- =====================================================
             UPCOMING MATCHES
        ====================================================== -->

        <div class="section-heading">

            <h2>
                Upcoming Matches
            </h2>

            <p>
                Don't miss the next big game.
            </p>

        </div>


        <div class="upcoming-grid">


            <div class="upcoming-card">

                <div class="date">
                    TODAY • 06:30 PM
                </div>

                <div class="upcoming-teams">

                    <div class="upcoming-team">
                        Vadodara Strikers
                    </div>

                    <div class="vs">
                        VS
                    </div>

                    <div class="upcoming-team">
                        Rajkot Royals
                    </div>

                </div>

                <div class="venue-small">
                    Cricket • Gujarat T20 League
                </div>

            </div>


            <div class="upcoming-card">

                <div class="date">
                    TODAY • 08:00 PM
                </div>

                <div class="upcoming-teams">

                    <div class="upcoming-team">
                        Baroda FC
                    </div>

                    <div class="vs">
                        VS
                    </div>

                    <div class="upcoming-team">
                        Gandhinagar United
                    </div>

                </div>

                <div class="venue-small">
                    Football • Gujarat State League
                </div>

            </div>


            <div class="upcoming-card">

                <div class="date">
                    TOMORROW • 05:00 PM
                </div>

                <div class="upcoming-teams">

                    <div class="upcoming-team">
                        Surat Giants
                    </div>

                    <div class="vs">
                        VS
                    </div>

                    <div class="upcoming-team">
                        Ahmedabad Hawks
                    </div>

                </div>

                <div class="venue-small">
                    Basketball • Gujarat Championship
                </div>

            </div>


        </div>



        <!-- =====================================================
             RECENT RESULTS
        ====================================================== -->

        <div class="section-heading">

            <h2>
                Recent Results
            </h2>

            <p>
                Latest completed matches.
            </p>

        </div>


        <div class="recent-list">


            <div class="recent-match">

                <div class="recent-sport">
                    CRICKET
                </div>

                <div class="recent-teams">
                    Ahmedabad Kings
                    <br>
                    <span style="color:#7c8791;">
                        Surat Challengers
                    </span>
                </div>

                <div class="recent-score">
                    184/6
                    <br>
                    <span style="color:#7c8791;">
                        176/9
                    </span>
                </div>

            </div>


            <div class="recent-match">

                <div class="recent-sport">
                    FOOTBALL
                </div>

                <div class="recent-teams">
                    Rajkot FC
                    <br>
                    <span style="color:#7c8791;">
                        Vadodara United
                    </span>
                </div>

                <div class="recent-score">
                    3
                    <br>
                    <span style="color:#7c8791;">
                        2
                    </span>
                </div>

            </div>


            <div class="recent-match">

                <div class="recent-sport">
                    VOLLEYBALL
                </div>

                <div class="recent-teams">
                    Gujarat Aces
                    <br>
                    <span style="color:#7c8791;">
                        Surat Spikers
                    </span>
                </div>

                <div class="recent-score">
                    3 Sets
                    <br>
                    <span style="color:#7c8791;">
                        1 Set
                    </span>
                </div>

            </div>


        </div>

    </div>

</div>


<script>
document.addEventListener("DOMContentLoaded", function () {

    const buttons = document.querySelectorAll(".filter-btn");
    const cards = document.querySelectorAll(".sport-card");

    buttons.forEach(button => {

        button.addEventListener("click", function () {

            buttons.forEach(btn => {
                btn.classList.remove("active");
            });

            this.classList.add("active");

            const filter = this.dataset.filter;

            cards.forEach(card => {

                if (filter === "all" || card.dataset.sport === filter) {
                    card.classList.remove("hidden");
                } else {
                    card.classList.add("hidden");
                }

            });

        });

    });

});
</script>


<?php require_once '../includes/footer.php'; ?>