
<?php
/*
|--------------------------------------------------------------------------
| SPORTZONE - BASKETBALL PAGE
|--------------------------------------------------------------------------
| File:
| C:\wamp64\www\sports_league\pages\basketball.php
|
| Standalone demo page - No database required.
|--------------------------------------------------------------------------
*/

$liveMatch = [
    'team1' => 'SportZone Warriors',
    'short1' => 'SZ',
    'team2' => 'City Lions',
    'short2' => 'CL',

    'score1' => 78,
    'score2' => 72,

    'quarter' => 'Q3',
    'clock' => '04:36',

    'venue' => 'SportZone Indoor Arena',

    'possession1' => 52,
    'possession2' => 48,

    'fg1' => 48,
    'fg2' => 44,

    'three1' => 38,
    'three2' => 31,

    'rebounds1' => 32,
    'rebounds2' => 28,

    'assists1' => 18,
    'assists2' => 15,

    'fouls1' => 8,
    'fouls2' => 10,

    'topPlayer1' => 'Rahul Sharma',
    'topPlayer1Pts' => 24,

    'topPlayer2' => 'Aman Patel',
    'topPlayer2Pts' => 21
];


$upcomingMatches = [

    [
        'date' => '14 Sep 2026',
        'time' => '06:30 PM',
        'team1' => 'Ahmedabad Titans',
        'team2' => 'SportZone Warriors',
        'venue' => 'City Indoor Arena'
    ],

    [
        'date' => '16 Sep 2026',
        'time' => '07:00 PM',
        'team1' => 'City Lions',
        'team2' => 'River Hawks',
        'venue' => 'Riverdale Arena'
    ],

    [
        'date' => '18 Sep 2026',
        'time' => '06:00 PM',
        'team1' => 'SportZone Warriors',
        'team2' => 'Ahmedabad Titans',
        'venue' => 'SportZone Indoor Arena'
    ]

];


$results = [

    [
        'date' => '10 Sep 2026',
        'team1' => 'SportZone Warriors',
        'team2' => 'River Hawks',
        'score1' => 91,
        'score2' => 84,
        'result' => 'SportZone Warriors won'
    ],

    [
        'date' => '07 Sep 2026',
        'team1' => 'Ahmedabad Titans',
        'team2' => 'City Lions',
        'score1' => 88,
        'score2' => 88,
        'result' => 'Draw'
    ],

    [
        'date' => '04 Sep 2026',
        'team1' => 'River Hawks',
        'team2' => 'Ahmedabad Titans',
        'score1' => 76,
        'score2' => 83,
        'result' => 'Ahmedabad Titans won'
    ]

];


$standings = [

    [
        'pos' => 1,
        'team' => 'SportZone Warriors',
        'p' => 8,
        'w' => 7,
        'l' => 1,
        'pf' => 684,
        'pa' => 602,
        'diff' => '+82',
        'pts' => 15
    ],

    [
        'pos' => 2,
        'team' => 'Ahmedabad Titans',
        'p' => 8,
        'w' => 6,
        'l' => 2,
        'pf' => 651,
        'pa' => 610,
        'diff' => '+41',
        'pts' => 14
    ],

    [
        'pos' => 3,
        'team' => 'City Lions',
        'p' => 8,
        'w' => 4,
        'l' => 4,
        'pf' => 625,
        'pa' => 628,
        'diff' => '-3',
        'pts' => 12
    ],

    [
        'pos' => 4,
        'team' => 'River Hawks',
        'p' => 8,
        'w' => 2,
        'l' => 6,
        'pf' => 590,
        'pa' => 652,
        'diff' => '-62',
        'pts' => 10
    ]

];


$topScorers = [

    [
        'player' => 'Rahul Sharma',
        'team' => 'SportZone Warriors',
        'points' => 186,
        'games' => 8
    ],

    [
        'player' => 'Aman Patel',
        'team' => 'City Lions',
        'points' => 174,
        'games' => 8
    ],

    [
        'player' => 'Vikram Singh',
        'team' => 'Ahmedabad Titans',
        'points' => 169,
        'games' => 8
    ],

    [
        'player' => 'Arjun Mehta',
        'team' => 'SportZone Warriors',
        'points' => 158,
        'games' => 7
    ],

    [
        'player' => 'Karan Shah',
        'team' => 'River Hawks',
        'points' => 142,
        'games' => 8
    ]

];


$topAssists = [

    [
        'player' => 'Arjun Mehta',
        'team' => 'SportZone Warriors',
        'assists' => 58
    ],

    [
        'player' => 'Rahul Sharma',
        'team' => 'SportZone Warriors',
        'assists' => 51
    ],

    [
        'player' => 'Aman Patel',
        'team' => 'City Lions',
        'assists' => 47
    ],

    [
        'player' => 'Vikram Singh',
        'team' => 'Ahmedabad Titans',
        'assists' => 44
    ],

    [
        'player' => 'Karan Shah',
        'team' => 'River Hawks',
        'assists' => 39
    ]

];


$topRebounders = [

    [
        'player' => 'Vikram Singh',
        'team' => 'Ahmedabad Titans',
        'rebounds' => 76
    ],

    [
        'player' => 'Rahul Sharma',
        'team' => 'SportZone Warriors',
        'rebounds' => 71
    ],

    [
        'player' => 'Karan Shah',
        'team' => 'River Hawks',
        'rebounds' => 69
    ],

    [
        'player' => 'Aman Patel',
        'team' => 'City Lions',
        'rebounds' => 64
    ]

];


$teams = [

    [
        'name' => 'SportZone Warriors',
        'city' => 'Ahmedabad',
        'coach' => 'R. Desai',
        'players' => 15
    ],

    [
        'name' => 'Ahmedabad Titans',
        'city' => 'Ahmedabad',
        'coach' => 'M. Patel',
        'players' => 14
    ],

    [
        'name' => 'City Lions',
        'city' => 'Gandhinagar',
        'coach' => 'A. Shah',
        'players' => 15
    ],

    [
        'name' => 'River Hawks',
        'city' => 'Vadodara',
        'coach' => 'S. Mehta',
        'players' => 14
    ]

];

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Basketball | SPORTZONE</title>


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


<link rel="preconnect"
href="https://fonts.googleapis.com">


<link rel="preconnect"
href="https://fonts.gstatic.com"
crossorigin>


<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap"
rel="stylesheet">


<style>

/* ================= RESET ================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}


body {

    background: #080c11;

    color: #ffffff;

    font-family: 'Montserrat', sans-serif;

    min-height: 100vh;
}


a {
    text-decoration: none;
    color: inherit;
}


.container {

    width: 92%;

    max-width: 1400px;

    margin: auto;
}


/* ================= HEADER ================= */

.top-header {

    background: #0d131a;

    border-bottom: 1px solid #202934;

    padding: 18px 0;

    position: sticky;

    top: 0;

    z-index: 1000;
}


.header-inner {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 20px;
}


.logo-area {

    display: flex;

    align-items: center;

    gap: 12px;
}


.logo-icon {

    width: 45px;

    height: 45px;

    border-radius: 12px;

    background: #ff5b25;

    display: flex;

    justify-content: center;

    align-items: center;

    font-size: 21px;
}


.logo-text h2 {

    font-size: 20px;

    font-weight: 800;
}


.logo-text span {

    font-size: 10px;

    color: #ff5b25;

    letter-spacing: 2px;
}


.back-btn {

    border: 1px solid #303a46;

    padding: 10px 16px;

    border-radius: 8px;

    color: #cbd5df;

    font-size: 13px;

    transition: 0.3s;
}


.back-btn:hover {

    background: #ff5b25;

    color: white;

    border-color: #ff5b25;
}


/* ================= PAGE TITLE ================= */

.page-title {

    padding: 35px 0 20px;
}


.page-title h1 {

    font-size: 32px;

    font-weight: 800;
}


.page-title p {

    color: #8995a3;

    margin-top: 8px;

    font-size: 13px;
}


/* ================= SECTION TITLE ================= */

.section-title {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin: 25px 0 15px;
}


.section-title h2 {

    font-size: 19px;
}


.section-title h2 i {

    color: #ff5b25;

    margin-right: 7px;
}


.live-badge {

    background: #ff5b25;

    padding: 7px 12px;

    border-radius: 20px;

    font-size: 10px;

    font-weight: 800;

    letter-spacing: 1px;
}


/* ================= LIVE CARD ================= */

.live-card {

    background: #111820;

    border: 1px solid #27313c;

    border-radius: 16px;

    overflow: hidden;

    box-shadow: 0 15px 40px rgba(0,0,0,0.25);
}


.match-top {

    padding: 14px 20px;

    border-bottom: 1px solid #27313c;

    display: flex;

    justify-content: space-between;

    color: #929daa;

    font-size: 11px;
}


.match-status {

    color: #ff5b25;

    font-weight: 800;
}


/* ================= SCORE ================= */

.match-main {

    display: grid;

    grid-template-columns: 1fr 250px 1fr;

    align-items: center;

    padding: 35px 30px;

    text-align: center;
}


.team-logo {

    width: 75px;

    height: 75px;

    margin: 0 auto 12px;

    border-radius: 50%;

    background: #1b242e;

    border: 2px solid #374452;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 21px;

    font-weight: 800;

    color: #ff5b25;
}


.team h3 {

    font-size: 18px;
}


.score-box h1 {

    font-size: 48px;

    letter-spacing: 3px;
}


.quarter {

    display: inline-block;

    margin-top: 10px;

    background: #ff5b25;

    padding: 7px 15px;

    border-radius: 20px;

    font-size: 11px;

    font-weight: 800;
}


.clock {

    margin-top: 10px;

    font-size: 18px;

    font-weight: 700;

    color: #ffffff;
}


.score-box p {

    color: #8995a3;

    font-size: 10px;

    margin-top: 8px;
}


/* ================= PLAYER HIGHLIGHT ================= */

.player-highlight {

    border-top: 1px solid #27313c;

    border-bottom: 1px solid #27313c;

    padding: 15px 20px;

    display: flex;

    justify-content: center;

    gap: 60px;

    font-size: 11px;
}


.player-highlight span {

    color: #8995a3;
}


.player-highlight strong {

    color: white;
}


/* ================= STATS ================= */

.match-stats {

    padding: 20px 30px 30px;
}


.stat-row {

    display: grid;

    grid-template-columns: 70px 1fr 70px;

    gap: 15px;

    align-items: center;

    margin: 15px 0;

    font-size: 11px;
}


.stat-name {

    text-align: center;

    color: #8d98a5;

    margin-bottom: 6px;
}


.progress {

    height: 6px;

    background: #27313c;

    border-radius: 10px;

    overflow: hidden;
}


.progress-inner {

    height: 100%;

    background: #ff5b25;

    border-radius: 10px;
}


.value {

    font-weight: 700;
}


/* ================= GRID ================= */

.two-grid {

    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 20px;
}


.three-grid {

    display: grid;

    grid-template-columns: repeat(3, 1fr);

    gap: 20px;
}


/* ================= BOX ================= */

.box {

    background: #111820;

    border: 1px solid #27313c;

    border-radius: 14px;

    overflow: hidden;
}


.box-header {

    padding: 16px 18px;

    border-bottom: 1px solid #27313c;

    display: flex;

    justify-content: space-between;

    align-items: center;
}


.box-header h3 {

    font-size: 14px;
}


.box-header i {

    color: #ff5b25;
}


.box-body {

    padding: 18px;
}


/* ================= FIXTURE ================= */

.fixture {

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 15px 0;

    border-bottom: 1px solid #222b34;
}


.fixture:last-child {

    border-bottom: none;
}


.fixture-date {

    width: 105px;
}


.fixture-date strong {

    display: block;

    font-size: 11px;
}


.fixture-date span {

    font-size: 10px;

    color: #7e8995;
}


.fixture-teams {

    text-align: center;

    flex: 1;
}


.fixture-teams strong {

    font-size: 12px;
}


.fixture-teams span {

    display: block;

    color: #7e8995;

    font-size: 10px;

    margin-top: 4px;
}


.vs {

    color: #ff5b25 !important;

    font-weight: 800;
}


/* ================= RESULTS ================= */

.result {

    display: flex;

    justify-content: space-between;

    align-items: center;

    padding: 15px 0;

    border-bottom: 1px solid #222b34;
}


.result:last-child {

    border-bottom: none;
}


.result-date {

    font-size: 10px;

    color: #7e8995;

    margin-top: 5px;
}


.result-score {

    font-size: 18px;

    font-weight: 800;
}


.result-status {

    color: #70d69a;

    font-size: 9px;

    font-weight: 700;

    text-align: right;
}


/* ================= TABLE ================= */

.table-wrapper {

    overflow-x: auto;
}


table {

    width: 100%;

    border-collapse: collapse;
}


th {

    background: #171f28;

    color: #8995a3;

    font-size: 10px;

    text-transform: uppercase;
}


th,
td {

    padding: 13px 10px;

    text-align: center;

    border-bottom: 1px solid #222b34;
}


td {

    font-size: 11px;

    color: #d6dde5;
}


.team-name {

    text-align: left !important;

    font-weight: 600;
}


.position {

    color: #ff5b25;

    font-weight: 800;
}


.points {

    font-weight: 800;
}


/* ================= PLAYER ================= */

.player {

    display: flex;

    align-items: center;

    gap: 13px;

    padding: 13px 0;

    border-bottom: 1px solid #222b34;
}


.player:last-child {

    border-bottom: none;
}


.player-icon {

    width: 40px;

    height: 40px;

    background: #1c2630;

    border-radius: 50%;

    display: flex;

    align-items: center;

    justify-content: center;

    color: #ff5b25;
}


.player-info {

    flex: 1;
}


.player-info strong {

    display: block;

    font-size: 11px;
}


.player-info span {

    display: block;

    color: #788591;

    font-size: 9px;

    margin-top: 4px;
}


.player-number {

    font-size: 18px;

    font-weight: 800;

    text-align: center;
}


/* ================= TEAM CARD ================= */

.team-card {

    padding: 20px;

    text-align: center;
}


.team-card-icon {

    width: 65px;

    height: 65px;

    background: #1b242e;

    border: 1px solid #374452;

    margin: auto;

    border-radius: 50%;

    display: flex;

    justify-content: center;

    align-items: center;

    color: #ff5b25;

    font-size: 20px;
}


.team-card h3 {

    font-size: 13px;

    margin-top: 12px;
}


.team-card p {

    font-size: 10px;

    color: #7e8995;

    margin-top: 5px;
}


.team-details {

    margin-top: 15px;

    padding-top: 12px;

    border-top: 1px solid #27313c;

    display: flex;

    justify-content: space-between;

    font-size: 9px;

    color: #8d98a5;
}


/* ================= QUICK STATS ================= */

.quick-stat {

    background: #111820;

    border: 1px solid #27313c;

    border-radius: 12px;

    padding: 20px;

    text-align: center;
}


.quick-stat i {

    color: #ff5b25;

    font-size: 20px;
}


.quick-stat h3 {

    margin-top: 10px;

    font-size: 24px;
}


.quick-stat p {

    color: #7e8995;

    font-size: 10px;

    margin-top: 5px;
}


/* ================= FOOTER ================= */

.footer {

    margin-top: 50px;

    padding: 25px 0;

    text-align: center;

    border-top: 1px solid #202934;

    color: #66727e;

    font-size: 10px;
}


/* ================= RESPONSIVE ================= */

@media(max-width: 900px) {

    .match-main {

        grid-template-columns: 1fr;

        gap: 25px;
    }


    .score-box {

        order: -1;
    }


    .two-grid,
    .three-grid {

        grid-template-columns: 1fr;
    }

}


@media(max-width: 600px) {

    .container {

        width: 94%;
    }


    .page-title h1 {

        font-size: 25px;
    }


    .score-box h1 {

        font-size: 38px;
    }


    .player-highlight {

        gap: 15px;

        flex-wrap: wrap;
    }


    .stat-row {

        grid-template-columns: 50px 1fr 50px;

        gap: 8px;
    }


    .fixture-date {

        width: 80px;
    }

}

</style>

</head>


<body>


<!-- ================= HEADER ================= -->

<header class="top-header">

    <div class="container header-inner">


        <div class="logo-area">

            <div class="logo-icon">

                <i class="fa-solid fa-basketball"></i>

            </div>


            <div class="logo-text">

                <h2>SPORTZONE</h2>

                <span>LOCAL SPORTS</span>

            </div>

        </div>


        <a href="../index.php"
           class="back-btn">

            <i class="fa-solid fa-arrow-left"></i>

            Back to Home

        </a>


    </div>

</header>



<main class="container">


<!-- ================= PAGE TITLE ================= -->

<section class="page-title">

    <h1>

        <i class="fa-solid fa-basketball"
           style="color:#ff5b25;"></i>

        Basketball

    </h1>


    <p>

        Live scores, fixtures, results, standings and player statistics

    </p>

</section>



<!-- ================= LIVE MATCH ================= -->

<div class="section-title">

    <h2>

        <i class="fa-solid fa-circle-play"></i>

        Live Match

    </h2>


    <span class="live-badge">

        ● LIVE

    </span>

</div>



<div class="live-card">


    <div class="match-top">

        <span>

            <i class="fa-solid fa-location-dot"></i>

            <?= htmlspecialchars($liveMatch['venue']) ?>

        </span>


        <span class="match-status">

            LIVE • <?= htmlspecialchars($liveMatch['quarter']) ?>

        </span>

    </div>



    <div class="match-main">


        <!-- TEAM 1 -->

        <div class="team">

            <div class="team-logo">

                <?= htmlspecialchars($liveMatch['short1']) ?>

            </div>


            <h3>

                <?= htmlspecialchars($liveMatch['team1']) ?>

            </h3>

        </div>



        <!-- SCORE -->

        <div class="score-box">

            <h1>

                <?= $liveMatch['score1'] ?>

                -

                <?= $liveMatch['score2'] ?>

            </h1>


            <span class="quarter">

                <?= htmlspecialchars($liveMatch['quarter']) ?>

            </span>


            <div class="clock">

                <?= htmlspecialchars($liveMatch['clock']) ?>

            </div>


            <p>

                Game Clock

            </p>

        </div>



        <!-- TEAM 2 -->

        <div class="team">

            <div class="team-logo">

                <?= htmlspecialchars($liveMatch['short2']) ?>

            </div>


            <h3>

                <?= htmlspecialchars($liveMatch['team2']) ?>

            </h3>

        </div>

    </div>



    <!-- TOP PLAYERS -->

    <div class="player-highlight">

        <span>

            ⭐

            <strong>
                <?= htmlspecialchars($liveMatch['topPlayer1']) ?>
            </strong>

            -

            <?= $liveMatch['topPlayer1Pts'] ?> PTS

        </span>


        <span>

            ⭐

            <strong>
                <?= htmlspecialchars($liveMatch['topPlayer2']) ?>
            </strong>

            -

            <?= $liveMatch['topPlayer2Pts'] ?> PTS

        </span>

    </div>



    <!-- MATCH STATS -->

    <div class="match-stats">


        <!-- POSSESSION -->

        <div class="stat-row">

            <div class="value">

                <?= $liveMatch['possession1'] ?>%

            </div>


            <div>

                <div class="stat-name">

                    Possession

                </div>


                <div class="progress">

                    <div class="progress-inner"
                         style="width:<?= $liveMatch['possession1'] ?>%;">

                    </div>

                </div>

            </div>


            <div class="value">

                <?= $liveMatch['possession2'] ?>%

            </div>

        </div>



        <!-- FIELD GOALS -->

        <div class="stat-row">

            <div class="value">

                <?= $liveMatch['fg1'] ?>%

            </div>


            <div>

                <div class="stat-name">

                    Field Goal %

                </div>


                <div class="progress">

                    <div class="progress-inner"
                         style="width:<?= $liveMatch['fg1'] ?>%;">

                    </div>

                </div>

            </div>


            <div class="value">

                <?= $liveMatch['fg2'] ?>%

            </div>

        </div>



        <!-- THREE POINTER -->

        <div class="stat-row">

            <div class="value">

                <?= $liveMatch['three1'] ?>%

            </div>


            <div>

                <div class="stat-name">

                    3 Point %

                </div>


                <div class="progress">

                    <div class="progress-inner"
                         style="width:<?= $liveMatch['three1'] ?>%;">

                    </div>

                </div>

            </div>


            <div class="value">

                <?= $liveMatch['three2'] ?>%

            </div>

        </div>



        <!-- REBOUNDS -->

        <div class="stat-row">

            <div class="value">

                <?= $liveMatch['rebounds1'] ?>

            </div>


            <div>

                <div class="stat-name">

                    Rebounds

                </div>


                <div class="progress">

                    <div class="progress-inner"
                         style="width:<?= min($liveMatch['rebounds1'],100) ?>%;">

                    </div>

                </div>

            </div>


            <div class="value">

                <?= $liveMatch['rebounds2'] ?>

            </div>

        </div>



        <!-- ASSISTS -->

        <div class="stat-row">

            <div class="value">

                <?= $liveMatch['assists1'] ?>

            </div>


            <div>

                <div class="stat-name">

                    Assists

                </div>


                <div class="progress">

                    <div class="progress-inner"
                         style="width:<?= min($liveMatch['assists1'] * 3,100) ?>%;">

                    </div>

                </div>

            </div>


            <div class="value">

                <?= $liveMatch['assists2'] ?>

            </div>

        </div>



        <!-- FOULS -->

        <div class="stat-row">

            <div class="value">

                <?= $liveMatch['fouls1'] ?>

            </div>


            <div class="stat-name">

                Team Fouls

            </div>


            <div class="value">

                <?= $liveMatch['fouls2'] ?>

            </div>

        </div>


    </div>

</div>



<!-- ================= QUICK STATS ================= -->

<div class="section-title">

    <h2>

        <i class="fa-solid fa-chart-simple"></i>

        Game Overview

    </h2>

</div>



<div class="three-grid">


    <div class="quick-stat">

        <i class="fa-solid fa-basketball"></i>


        <h3>

            <?= $liveMatch['score1'] + $liveMatch['score2'] ?>

        </h3>


        <p>

            Total Points

        </p>

    </div>



    <div class="quick-stat">

        <i class="fa-solid fa-clock"></i>


        <h3>

            <?= htmlspecialchars($liveMatch['quarter']) ?>

        </h3>


        <p>

            Current Quarter

        </p>

    </div>



    <div class="quick-stat">

        <i class="fa-solid fa-stopwatch"></i>


        <h3>

            <?= htmlspecialchars($liveMatch['clock']) ?>

        </h3>


        <p>

            Game Clock

        </p>

    </div>


</div>



<!-- ================= MATCHES ================= -->

<div class="section-title">

    <h2>

        <i class="fa-solid fa-calendar-days"></i>

        Matches

    </h2>

</div>



<div class="two-grid">


    <!-- UPCOMING -->

    <div class="box">


        <div class="box-header">

            <h3>

                Upcoming Fixtures

            </h3>


            <i class="fa-solid fa-calendar-plus"></i>

        </div>


        <div class="box-body">


            <?php foreach ($upcomingMatches as $match): ?>


                <div class="fixture">


                    <div class="fixture-date">

                        <strong>

                            <?= htmlspecialchars($match['date']) ?>

                        </strong>


                        <span>

                            <?= htmlspecialchars($match['time']) ?>

                        </span>

                    </div>



                    <div class="fixture-teams">

                        <strong>

                            <?= htmlspecialchars($match['team1']) ?>

                        </strong>


                        <span class="vs">

                            VS

                        </span>


                        <strong>

                            <?= htmlspecialchars($match['team2']) ?>

                        </strong>


                        <span>

                            <?= htmlspecialchars($match['venue']) ?>

                        </span>

                    </div>


                </div>


            <?php endforeach; ?>


        </div>

    </div>



    <!-- RESULTS -->

    <div class="box">


        <div class="box-header">

            <h3>

                Recent Results

            </h3>


            <i class="fa-solid fa-trophy"></i>

        </div>


        <div class="box-body">


            <?php foreach ($results as $result): ?>


                <div class="result">


                    <div>

                        <strong style="font-size:11px;">

                            <?= htmlspecialchars($result['team1']) ?>

                        </strong>


                        <br>


                        <strong style="font-size:11px;">

                            <?= htmlspecialchars($result['team2']) ?>

                        </strong>


                        <div class="result-date">

                            <?= htmlspecialchars($result['date']) ?>

                        </div>

                    </div>


                    <div class="result-score">

                        <?= $result['score1'] ?>

                        -

                        <?= $result['score2'] ?>

                    </div>


                    <div class="result-status">

                        <?= htmlspecialchars($result['result']) ?>

                    </div>


                </div>


            <?php endforeach; ?>


        </div>

    </div>


</div>



<!-- ================= STANDINGS ================= -->

<div class="section-title">

    <h2>

        <i class="fa-solid fa-ranking-star"></i>

        League Standings

    </h2>

</div>



<div class="box">


    <div class="table-wrapper">

        <table>


            <thead>

                <tr>

                    <th>Pos</th>

                    <th>Team</th>

                    <th>P</th>

                    <th>W</th>

                    <th>L</th>

                    <th>PF</th>

                    <th>PA</th>

                    <th>DIFF</th>

                    <th>PTS</th>

                </tr>

            </thead>


            <tbody>


                <?php foreach ($standings as $row): ?>


                    <tr>

                        <td class="position">

                            <?= $row['pos'] ?>

                        </td>


                        <td class="team-name">

                            <?= htmlspecialchars($row['team']) ?>

                        </td>


                        <td>

                            <?= $row['p'] ?>

                        </td>


                        <td>

                            <?= $row['w'] ?>

                        </td>


                        <td>

                            <?= $row['l'] ?>

                        </td>


                        <td>

                            <?= $row['pf'] ?>

                        </td>


                        <td>

                            <?= $row['pa'] ?>

                        </td>


                        <td>

                            <?= $row['diff'] ?>

                        </td>


                        <td class="points">

                            <?= $row['pts'] ?>

                        </td>

                    </tr>


                <?php endforeach; ?>


            </tbody>


        </table>

    </div>

</div>



<!-- ================= PLAYER STATS ================= -->

<div class="section-title">

    <h2>

        <i class="fa-solid fa-user-group"></i>

        Player Statistics

    </h2>

</div>



<div class="three-grid">


    <!-- TOP SCORERS -->

    <div class="box">


        <div class="box-header">

            <h3>

                Top Scorers

            </h3>


            <i class="fa-solid fa-basketball"></i>

        </div>


        <div class="box-body">


            <?php foreach ($topScorers as $player): ?>


                <div class="player">


                    <div class="player-icon">

                        <i class="fa-solid fa-user"></i>

                    </div>


                    <div class="player-info">

                        <strong>

                            <?= htmlspecialchars($player['player']) ?>

                        </strong>


                        <span>

                            <?= htmlspecialchars($player['team']) ?>

                            • <?= $player['games'] ?> Games

                        </span>

                    </div>


                    <div class="player-number">

                        <?= $player['points'] ?>


                        <span style="
                        display:block;
                        font-size:8px;
                        color:#7e8995;
                        ">

                            PTS

                        </span>

                    </div>


                </div>


            <?php endforeach; ?>


        </div>

    </div>



    <!-- ASSISTS -->

    <div class="box">


        <div class="box-header">

            <h3>

                Top Assists

            </h3>


            <i class="fa-solid fa-share-nodes"></i>

        </div>


        <div class="box-body">


            <?php foreach ($topAssists as $player): ?>


                <div class="player">


                    <div class="player-icon">

                        <i class="fa-solid fa-user"></i>

                    </div>


                    <div class="player-info">

                        <strong>

                            <?= htmlspecialchars($player['player']) ?>

                        </strong>


                        <span>

                            <?= htmlspecialchars($player['team']) ?>

                        </span>

                    </div>


                    <div class="player-number">

                        <?= $player['assists'] ?>


                        <span style="
                        display:block;
                        font-size:8px;
                        color:#7e8995;
                        ">

                            AST

                        </span>

                    </div>


                </div>


            <?php endforeach; ?>


        </div>

    </div>



    <!-- REBOUNDS -->

    <div class="box">


        <div class="box-header">

            <h3>

                Top Rebounders

            </h3>


            <i class="fa-solid fa-arrows-down-to-line"></i>

        </div>


        <div class="box-body">


            <?php foreach ($topRebounders as $player): ?>


                <div class="player">


                    <div class="player-icon">

                        <i class="fa-solid fa-user"></i>

                    </div>


                    <div class="player-info">

                        <strong>

                            <?= htmlspecialchars($player['player']) ?>

                        </strong>


                        <span>

                            <?= htmlspecialchars($player['team']) ?>

                        </span>

                    </div>


                    <div class="player-number">

                        <?= $player['rebounds'] ?>


                        <span style="
                        display:block;
                        font-size:8px;
                        color:#7e8995;
                        ">

                            REB

                        </span>

                    </div>


                </div>


            <?php endforeach; ?>


        </div>

    </div>


</div>



<!-- ================= TEAMS ================= -->

<div class="section-title">

    <h2>

        <i class="fa-solid fa-shield-halved"></i>

        Basketball Teams

    </h2>

</div>



<div class="three-grid">


    <?php foreach ($teams as $team): ?>


        <div class="box">


            <div class="team-card">


                <div class="team-card-icon">

                    <i class="fa-solid fa-basketball"></i>

                </div>


                <h3>

                    <?= htmlspecialchars($team['name']) ?>

                </h3>


                <p>

                    <i class="fa-solid fa-location-dot"></i>

                    <?= htmlspecialchars($team['city']) ?>

                </p>


                <div class="team-details">

                    <span>

                        Coach:

                        <?= htmlspecialchars($team['coach']) ?>

                    </span>


                    <span>

                        <?= $team['players'] ?> Players

                    </span>

                </div>


            </div>

        </div>


    <?php endforeach; ?>


</div>


</main>



<!-- ================= FOOTER ================= -->

<footer class="footer">

    <div class="container">

        © <?= date('Y') ?> SPORTZONE

        • LOCAL SPORTS

        • Basketball

    </div>

</footer>


</body>

</html>

