
<?php
/*
|--------------------------------------------------------------------------
| SPORTZONE - FOOTBALL PAGE
|--------------------------------------------------------------------------
| File:
| C:\wamp64\www\sports_league\pages\football.php
|
| Standalone demo page.
| No database required.
|--------------------------------------------------------------------------
*/

$liveMatches = [
    [
        'team1' => 'SportZone FC',
        'team1_short' => 'SZ',
        'team2' => 'City United',
        'team2_short' => 'CU',
        'score1' => 2,
        'score2' => 1,
        'minute' => 67,
        'venue' => 'SportZone Stadium',
        'status' => 'LIVE',
        'possession1' => 56,
        'possession2' => 44,
        'shots1' => 9,
        'shots2' => 6,
        'shots_on_target1' => 5,
        'shots_on_target2' => 3,
        'corners1' => 4,
        'corners2' => 2,
        'yellow1' => 1,
        'yellow2' => 2,
        'red1' => 0,
        'red2' => 0,
        'scorer1' => 'Rahul Sharma',
        'scorer2' => 'Aman Patel'
    ]
];

$upcomingMatches = [
    [
        'date' => '14 Sep 2026',
        'time' => '06:30 PM',
        'team1' => 'Ahmedabad Stars',
        'team2' => 'SportZone FC',
        'venue' => 'City Sports Ground'
    ],
    [
        'date' => '16 Sep 2026',
        'time' => '07:00 PM',
        'team1' => 'City United',
        'team2' => 'Riverdale FC',
        'venue' => 'Riverdale Stadium'
    ],
    [
        'date' => '18 Sep 2026',
        'time' => '06:00 PM',
        'team1' => 'SportZone FC',
        'team2' => 'Ahmedabad Stars',
        'venue' => 'SportZone Stadium'
    ]
];

$results = [
    [
        'date' => '10 Sep 2026',
        'team1' => 'SportZone FC',
        'team2' => 'Riverdale FC',
        'score1' => 3,
        'score2' => 1,
        'result' => 'SportZone FC won'
    ],
    [
        'date' => '07 Sep 2026',
        'team1' => 'Ahmedabad Stars',
        'team2' => 'City United',
        'score1' => 2,
        'score2' => 2,
        'result' => 'Draw'
    ],
    [
        'date' => '04 Sep 2026',
        'team1' => 'Riverdale FC',
        'team2' => 'Ahmedabad Stars',
        'score1' => 0,
        'score2' => 2,
        'result' => 'Ahmedabad Stars won'
    ]
];

$leagueTable = [
    ['pos' => 1, 'team' => 'SportZone FC', 'p' => 8, 'w' => 6, 'd' => 1, 'l' => 1, 'gf' => 18, 'ga' => 7, 'gd' => 11, 'pts' => 19],
    ['pos' => 2, 'team' => 'Ahmedabad Stars', 'p' => 8, 'w' => 5, 'd' => 2, 'l' => 1, 'gf' => 15, 'ga' => 8, 'gd' => 7, 'pts' => 17],
    ['pos' => 3, 'team' => 'City United', 'p' => 8, 'w' => 4, 'd' => 2, 'l' => 2, 'gf' => 13, 'ga' => 9, 'gd' => 4, 'pts' => 14],
    ['pos' => 4, 'team' => 'Riverdale FC', 'p' => 8, 'w' => 2, 'd' => 1, 'l' => 5, 'gf' => 8, 'ga' => 15, 'gd' => -7, 'pts' => 7]
];

$topScorers = [
    ['player' => 'Rahul Sharma', 'team' => 'SportZone FC', 'goals' => 8, 'matches' => 8],
    ['player' => 'Aman Patel', 'team' => 'City United', 'goals' => 6, 'matches' => 8],
    ['player' => 'Vikram Singh', 'team' => 'Ahmedabad Stars', 'goals' => 6, 'matches' => 8],
    ['player' => 'Arjun Mehta', 'team' => 'SportZone FC', 'goals' => 5, 'matches' => 7],
    ['player' => 'Karan Shah', 'team' => 'Riverdale FC', 'goals' => 4, 'matches' => 8]
];

$topAssists = [
    ['player' => 'Arjun Mehta', 'team' => 'SportZone FC', 'assists' => 6],
    ['player' => 'Rahul Sharma', 'team' => 'SportZone FC', 'assists' => 4],
    ['player' => 'Aman Patel', 'team' => 'City United', 'assists' => 4],
    ['player' => 'Vikram Singh', 'team' => 'Ahmedabad Stars', 'assists' => 3],
    ['player' => 'Karan Shah', 'team' => 'Riverdale FC', 'assists' => 3]
];

$teams = [
    [
        'name' => 'SportZone FC',
        'city' => 'Ahmedabad',
        'coach' => 'R. Desai',
        'players' => 24
    ],
    [
        'name' => 'Ahmedabad Stars',
        'city' => 'Ahmedabad',
        'coach' => 'M. Patel',
        'players' => 23
    ],
    [
        'name' => 'City United',
        'city' => 'Gandhinagar',
        'coach' => 'A. Shah',
        'players' => 25
    ],
    [
        'name' => 'Riverdale FC',
        'city' => 'Vadodara',
        'coach' => 'S. Mehta',
        'players' => 22
    ]
];

$live = $liveMatches[0];
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Football | SPORTZONE</title>

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="preconnect"
          href="https://fonts.googleapis.com">

    <link rel="preconnect"
          href="https://fonts.gstatic.com"
          crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap"
          rel="stylesheet">


<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    background: #080c11;
    color: #ffffff;
    font-family: 'Montserrat', sans-serif;
    min-height: 100vh;
}

a {
    text-decoration: none;
    color: inherit;
}

.container {
    width: 92%;
    max-width: 1400px;
    margin: auto;
}


/* ================= HEADER ================= */

.top-header {
    background: #0d131a;
    border-bottom: 1px solid #202934;
    padding: 18px 0;
    position: sticky;
    top: 0;
    z-index: 1000;
}

.header-inner {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
}

.logo-area {
    display: flex;
    align-items: center;
    gap: 12px;
}

.logo-icon {
    width: 45px;
    height: 45px;
    border-radius: 12px;
    background: #ff5b25;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 21px;
}

.logo-text h2 {
    font-size: 20px;
    font-weight: 800;
}

.logo-text span {
    font-size: 10px;
    color: #ff5b25;
    letter-spacing: 2px;
}

.back-btn {
    border: 1px solid #303a46;
    padding: 10px 16px;
    border-radius: 8px;
    color: #cbd5df;
    font-size: 13px;
    transition: 0.3s;
}

.back-btn:hover {
    background: #ff5b25;
    color: white;
    border-color: #ff5b25;
}


/* ================= PAGE TITLE ================= */

.page-title {
    padding: 35px 0 20px;
}

.page-title h1 {
    font-size: 32px;
    font-weight: 800;
}

.page-title p {
    color: #8995a3;
    margin-top: 8px;
    font-size: 13px;
}


/* ================= LIVE SECTION ================= */

.section-title {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 25px 0 15px;
}

.section-title h2 {
    font-size: 19px;
}

.section-title h2 i {
    color: #ff5b25;
    margin-right: 7px;
}

.live-badge {
    background: #ff5b25;
    padding: 7px 12px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 1px;
}


/* ================= LIVE CARD ================= */

.live-card {
    background: #111820;
    border: 1px solid #27313c;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 15px 40px rgba(0,0,0,0.25);
}

.match-top {
    padding: 14px 20px;
    border-bottom: 1px solid #27313c;
    display: flex;
    justify-content: space-between;
    color: #929daa;
    font-size: 11px;
}

.match-status {
    color: #ff5b25;
    font-weight: 800;
}

.match-main {
    display: grid;
    grid-template-columns: 1fr 220px 1fr;
    align-items: center;
    padding: 30px;
    text-align: center;
}

.team h3 {
    font-size: 20px;
}

.team-logo {
    width: 70px;
    height: 70px;
    margin: 0 auto 12px;
    border-radius: 50%;
    background: #1b242e;
    border: 2px solid #374452;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 21px;
    font-weight: 800;
    color: #ff5b25;
}

.score-box h1 {
    font-size: 48px;
    letter-spacing: 3px;
}

.score-box .minute {
    display: inline-block;
    margin-top: 8px;
    background: #ff5b25;
    padding: 7px 14px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 800;
}

.score-box p {
    color: #8995a3;
    font-size: 11px;
    margin-top: 12px;
}


/* ================= GOAL INFO ================= */

.goal-info {
    border-top: 1px solid #27313c;
    border-bottom: 1px solid #27313c;
    padding: 14px 20px;
    display: flex;
    justify-content: center;
    gap: 40px;
    font-size: 12px;
}

.goal-info span {
    color: #aab4bf;
}

.goal-info strong {
    color: white;
}


/* ================= STATS ================= */

.match-stats {
    padding: 20px 30px 30px;
}

.stat-row {
    display: grid;
    grid-template-columns: 80px 1fr 80px;
    gap: 15px;
    align-items: center;
    margin: 14px 0;
    font-size: 11px;
}

.stat-row .value {
    font-weight: 700;
}

.stat-name {
    text-align: center;
    color: #8d98a5;
}

.progress {
    height: 6px;
    background: #27313c;
    border-radius: 10px;
    overflow: hidden;
}

.progress-inner {
    height: 100%;
    background: #ff5b25;
    border-radius: 10px;
}


/* ================= GRID ================= */

.two-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.three-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
}


/* ================= BOX ================= */

.box {
    background: #111820;
    border: 1px solid #27313c;
    border-radius: 14px;
    overflow: hidden;
}

.box-header {
    padding: 16px 18px;
    border-bottom: 1px solid #27313c;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.box-header h3 {
    font-size: 14px;
}

.box-header i {
    color: #ff5b25;
}

.box-body {
    padding: 18px;
}


/* ================= FIXTURES ================= */

.fixture {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 15px 0;
    border-bottom: 1px solid #222b34;
}

.fixture:last-child {
    border-bottom: none;
}

.fixture-date {
    width: 100px;
}

.fixture-date strong {
    display: block;
    font-size: 11px;
}

.fixture-date span {
    font-size: 10px;
    color: #7e8995;
}

.fixture-teams {
    text-align: center;
    flex: 1;
}

.fixture-teams strong {
    font-size: 12px;
}

.fixture-teams span {
    display: block;
    color: #7e8995;
    font-size: 10px;
    margin-top: 4px;
}

.vs {
    color: #ff5b25 !important;
    font-weight: 800;
}


/* ================= RESULTS ================= */

.result {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 0;
    border-bottom: 1px solid #222b34;
}

.result:last-child {
    border-bottom: none;
}

.result-date {
    font-size: 10px;
    color: #7e8995;
}

.result-score {
    font-size: 18px;
    font-weight: 800;
}

.result-status {
    color: #70d69a;
    font-size: 10px;
    font-weight: 700;
}


/* ================= TABLE ================= */

.table-wrapper {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #171f28;
    color: #8995a3;
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

th,
td {
    padding: 13px 10px;
    text-align: center;
    border-bottom: 1px solid #222b34;
}

td {
    font-size: 11px;
    color: #d6dde5;
}

td:first-child,
th:first-child {
    text-align: center;
}

.team-name {
    text-align: left !important;
    font-weight: 600;
}

.position {
    color: #ff5b25;
    font-weight: 800;
}

.points {
    font-weight: 800;
    color: #ffffff;
}


/* ================= PLAYERS ================= */

.player {
    display: flex;
    align-items: center;
    gap: 13px;
    padding: 13px 0;
    border-bottom: 1px solid #222b34;
}

.player:last-child {
    border-bottom: none;
}

.player-icon {
    width: 40px;
    height: 40px;
    background: #1c2630;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #ff5b25;
}

.player-info {
    flex: 1;
}

.player-info strong {
    display: block;
    font-size: 11px;
}

.player-info span {
    display: block;
    color: #788591;
    font-size: 9px;
    margin-top: 4px;
}

.player-number {
    font-size: 18px;
    font-weight: 800;
}


/* ================= TEAMS ================= */

.team-card {
    padding: 20px;
    text-align: center;
}

.team-card-icon {
    width: 65px;
    height: 65px;
    background: #1b242e;
    border: 1px solid #374452;
    margin: auto;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #ff5b25;
    font-size: 20px;
}

.team-card h3 {
    font-size: 13px;
    margin-top: 12px;
}

.team-card p {
    font-size: 10px;
    color: #7e8995;
    margin-top: 5px;
}

.team-details {
    margin-top: 15px;
    padding-top: 12px;
    border-top: 1px solid #27313c;
    display: flex;
    justify-content: space-between;
    font-size: 9px;
    color: #8d98a5;
}


/* ================= QUICK STATS ================= */

.quick-stat {
    background: #111820;
    border: 1px solid #27313c;
    border-radius: 12px;
    padding: 20px;
    text-align: center;
}

.quick-stat i {
    color: #ff5b25;
    font-size: 20px;
}

.quick-stat h3 {
    margin-top: 10px;
    font-size: 24px;
}

.quick-stat p {
    color: #7e8995;
    font-size: 10px;
    margin-top: 5px;
}


/* ================= FOOTER ================= */

.footer {
    margin-top: 50px;
    padding: 25px 0;
    text-align: center;
    border-top: 1px solid #202934;
    color: #66727e;
    font-size: 10px;
}


/* ================= RESPONSIVE ================= */

@media(max-width: 900px) {

    .match-main {
        grid-template-columns: 1fr;
        gap: 25px;
    }

    .score-box {
        order: -1;
    }

    .two-grid,
    .three-grid {
        grid-template-columns: 1fr;
    }
}

@media(max-width: 600px) {

    .container {
        width: 94%;
    }

    .page-title h1 {
        font-size: 25px;
    }

    .match-main {
        padding: 22px 15px;
    }

    .score-box h1 {
        font-size: 38px;
    }

    .goal-info {
        gap: 15px;
        flex-wrap: wrap;
    }

    .stat-row {
        grid-template-columns: 50px 1fr 50px;
        gap: 8px;
    }

    .fixture-date {
        width: 80px;
    }

}

</style>

</head>


<body>


<!-- ================= HEADER ================= -->

<header class="top-header">

    <div class="container header-inner">

        <div class="logo-area">

            <div class="logo-icon">
                <i class="fa-solid fa-futbol"></i>
            </div>

            <div class="logo-text">
                <h2>SPORTZONE</h2>
                <span>LOCAL SPORTS</span>
            </div>

        </div>


        <a href="../index.php" class="back-btn">
            <i class="fa-solid fa-arrow-left"></i>
            Back to Home
        </a>

    </div>

</header>



<main class="container">


<!-- ================= PAGE TITLE ================= -->

<section class="page-title">

    <h1>
        <i class="fa-solid fa-futbol"
           style="color:#ff5b25;"></i>

        Football
    </h1>

    <p>
        Live scores, fixtures, results, standings and player statistics
    </p>

</section>



<!-- ================= LIVE MATCH ================= -->

<div class="section-title">

    <h2>
        <i class="fa-solid fa-circle-play"></i>
        Live Match
    </h2>

    <span class="live-badge">
        ● LIVE
    </span>

</div>



<div class="live-card">


    <div class="match-top">

        <span>
            <i class="fa-solid fa-location-dot"></i>
            <?= htmlspecialchars($live['venue']) ?>
        </span>

        <span class="match-status">
            LIVE • <?= $live['minute'] ?>'
        </span>

    </div>



    <div class="match-main">


        <!-- TEAM 1 -->

        <div class="team">

            <div class="team-logo">
                <?= htmlspecialchars($live['team1_short']) ?>
            </div>

            <h3>
                <?= htmlspecialchars($live['team1']) ?>
            </h3>

        </div>



        <!-- SCORE -->

        <div class="score-box">

            <h1>
                <?= $live['score1'] ?>
                -
                <?= $live['score2'] ?>
            </h1>

            <span class="minute">
                <?= $live['minute'] ?>' LIVE
            </span>

            <p>
                Second Half
            </p>

        </div>



        <!-- TEAM 2 -->

        <div class="team">

            <div class="team-logo">
                <?= htmlspecialchars($live['team2_short']) ?>
            </div>

            <h3>
                <?= htmlspecialchars($live['team2']) ?>
            </h3>

        </div>

    </div>



    <!-- GOALS -->

    <div class="goal-info">

        <span>
            ⚽
            <strong>
                <?= htmlspecialchars($live['scorer1']) ?>
            </strong>
            <?= $live['score1'] > 0 ? ' • Goal' : '' ?>
        </span>

        <span>
            ⚽
            <strong>
                <?= htmlspecialchars($live['scorer2']) ?>
            </strong>
        </span>

    </div>



    <!-- MATCH STATS -->

    <div class="match-stats">


        <div class="stat-row">

            <div class="value">
                <?= $live['possession1'] ?>%
            </div>

            <div>

                <div class="stat-name">
                    Possession
                </div>

                <div class="progress">

                    <div class="progress-inner"
                         style="width:<?= $live['possession1'] ?>%;">
                    </div>

                </div>

            </div>

            <div class="value">
                <?= $live['possession2'] ?>%
            </div>

        </div>



        <div class="stat-row">

            <div class="value">
                <?= $live['shots1'] ?>
            </div>

            <div>

                <div class="stat-name">
                    Shots
                </div>

                <div class="progress">

                    <div class="progress-inner"
                         style="width:<?= min($live['shots1'] * 7, 100) ?>%;">
                    </div>

                </div>

            </div>

            <div class="value">
                <?= $live['shots2'] ?>
            </div>

        </div>



        <div class="stat-row">

            <div class="value">
                <?= $live['shots_on_target1'] ?>
            </div>

            <div>

                <div class="stat-name">
                    Shots on Target
                </div>

                <div class="progress">

                    <div class="progress-inner"
                         style="width:<?= min($live['shots_on_target1'] * 15, 100) ?>%;">
                    </div>

                </div>

            </div>

            <div class="value">
                <?= $live['shots_on_target2'] ?>
            </div>

        </div>



        <div class="stat-row">

            <div class="value">
                <?= $live['corners1'] ?>
            </div>

            <div>

                <div class="stat-name">
                    Corners
                </div>

                <div class="progress">

                    <div class="progress-inner"
                         style="width:<?= min($live['corners1'] * 15, 100) ?>%;">
                    </div>

                </div>

            </div>

            <div class="value">
                <?= $live['corners2'] ?>
            </div>

        </div>



        <div class="stat-row">

            <div class="value">
                🟨 <?= $live['yellow1'] ?>
                &nbsp; 🟥 <?= $live['red1'] ?>
            </div>

            <div class="stat-name">
                Cards
            </div>

            <div class="value">
                🟨 <?= $live['yellow2'] ?>
                &nbsp; 🟥 <?= $live['red2'] ?>
            </div>

        </div>


    </div>

</div>



<!-- ================= QUICK STATS ================= -->

<div class="section-title">

    <h2>
        <i class="fa-solid fa-chart-simple"></i>
        Match Overview
    </h2>

</div>


<div class="three-grid">

    <div class="quick-stat">

        <i class="fa-solid fa-futbol"></i>

        <h3>
            <?= $live['score1'] + $live['score2'] ?>
        </h3>

        <p>
            Total Goals
        </p>

    </div>


    <div class="quick-stat">

        <i class="fa-solid fa-clock"></i>

        <h3>
            <?= $live['minute'] ?>'
        </h3>

        <p>
            Match Minute
        </p>

    </div>


    <div class="quick-stat">

        <i class="fa-solid fa-location-dot"></i>

        <h3>
            LIVE
        </h3>

        <p>
            SportZone Stadium
        </p>

    </div>

</div>



<!-- ================= FIXTURES + RESULTS ================= -->

<div class="section-title">

    <h2>
        <i class="fa-solid fa-calendar-days"></i>
        Matches
    </h2>

</div>


<div class="two-grid">


    <!-- UPCOMING -->

    <div class="box">

        <div class="box-header">

            <h3>
                Upcoming Fixtures
            </h3>

            <i class="fa-solid fa-calendar-plus"></i>

        </div>


        <div class="box-body">

            <?php foreach ($upcomingMatches as $match): ?>

                <div class="fixture">

                    <div class="fixture-date">

                        <strong>
                            <?= htmlspecialchars($match['date']) ?>
                        </strong>

                        <span>
                            <?= htmlspecialchars($match['time']) ?>
                        </span>

                    </div>


                    <div class="fixture-teams">

                        <strong>
                            <?= htmlspecialchars($match['team1']) ?>
                        </strong>

                        <span class="vs">
                            VS
                        </span>

                        <strong>
                            <?= htmlspecialchars($match['team2']) ?>
                        </strong>

                        <span>
                            <?= htmlspecialchars($match['venue']) ?>
                        </span>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    </div>



    <!-- RESULTS -->

    <div class="box">

        <div class="box-header">

            <h3>
                Recent Results
            </h3>

            <i class="fa-solid fa-flag-checkered"></i>

        </div>


        <div class="box-body">

            <?php foreach ($results as $result): ?>

                <div class="result">

                    <div>

                        <strong style="font-size:11px;">
                            <?= htmlspecialchars($result['team1']) ?>
                        </strong>

                        <br>

                        <strong style="font-size:11px;">
                            <?= htmlspecialchars($result['team2']) ?>
                        </strong>

                        <div class="result-date">
                            <?= htmlspecialchars($result['date']) ?>
                        </div>

                    </div>


                    <div class="result-score">

                        <?= $result['score1'] ?>
                        -
                        <?= $result['score2'] ?>

                    </div>


                    <div class="result-status">

                        <?= htmlspecialchars($result['result']) ?>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    </div>


</div>



<!-- ================= LEAGUE TABLE ================= -->

<div class="section-title">

    <h2>
        <i class="fa-solid fa-ranking-star"></i>
        League Standings
    </h2>

</div>


<div class="box">

    <div class="table-wrapper">

        <table>

            <thead>

                <tr>

                    <th>Pos</th>
                    <th>Team</th>
                    <th>P</th>
                    <th>W</th>
                    <th>D</th>
                    <th>L</th>
                    <th>GF</th>
                    <th>GA</th>
                    <th>GD</th>
                    <th>PTS</th>

                </tr>

            </thead>


            <tbody>

                <?php foreach ($leagueTable as $row): ?>

                    <tr>

                        <td class="position">
                            <?= $row['pos'] ?>
                        </td>

                        <td class="team-name">
                            <?= htmlspecialchars($row['team']) ?>
                        </td>

                        <td>
                            <?= $row['p'] ?>
                        </td>

                        <td>
                            <?= $row['w'] ?>
                        </td>

                        <td>
                            <?= $row['d'] ?>
                        </td>

                        <td>
                            <?= $row['l'] ?>
                        </td>

                        <td>
                            <?= $row['gf'] ?>
                        </td>

                        <td>
                            <?= $row['ga'] ?>
                        </td>

                        <td>
                            <?= $row['gd'] ?>
                        </td>

                        <td class="points">
                            <?= $row['pts'] ?>
                        </td>

                    </tr>

                <?php endforeach; ?>

            </tbody>

        </table>

    </div>

</div>



<!-- ================= PLAYER STATS ================= -->

<div class="section-title">

    <h2>
        <i class="fa-solid fa-user-group"></i>
        Player Statistics
    </h2>

</div>


<div class="two-grid">


    <!-- TOP SCORERS -->

    <div class="box">

        <div class="box-header">

            <h3>
                Top Scorers
            </h3>

            <i class="fa-solid fa-futbol"></i>

        </div>


        <div class="box-body">

            <?php foreach ($topScorers as $player): ?>

                <div class="player">

                    <div class="player-icon">

                        <i class="fa-solid fa-user"></i>

                    </div>


                    <div class="player-info">

                        <strong>
                            <?= htmlspecialchars($player['player']) ?>
                        </strong>

                        <span>
                            <?= htmlspecialchars($player['team']) ?>
                            • <?= $player['matches'] ?> Matches
                        </span>

                    </div>


                    <div class="player-number">

                        <?= $player['goals'] ?>

                        <span style="
                            display:block;
                            font-size:8px;
                            color:#7e8995;
                            text-align:center;
                        ">
                            GOALS
                        </span>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    </div>



    <!-- ASSISTS -->

    <div class="box">

        <div class="box-header">

            <h3>
                Top Assists
            </h3>

            <i class="fa-solid fa-hands-helping"></i>

        </div>


        <div class="box-body">

            <?php foreach ($topAssists as $player): ?>

                <div class="player">

                    <div class="player-icon">

                        <i class="fa-solid fa-user"></i>

                    </div>


                    <div class="player-info">

                        <strong>
                            <?= htmlspecialchars($player['player']) ?>
                        </strong>

                        <span>
                            <?= htmlspecialchars($player['team']) ?>
                        </span>

                    </div>


                    <div class="player-number">

                        <?= $player['assists'] ?>

                        <span style="
                            display:block;
                            font-size:8px;
                            color:#7e8995;
                            text-align:center;
                        ">
                            ASSISTS
                        </span>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    </div>


</div>



<!-- ================= TEAMS ================= -->

<div class="section-title">

    <h2>
        <i class="fa-solid fa-shield-halved"></i>
        Football Teams
    </h2>

</div>


<div class="three-grid">

    <?php foreach ($teams as $team): ?>

        <div class="box">

            <div class="team-card">

                <div class="team-card-icon">

                    <i class="fa-solid fa-shield"></i>

                </div>


                <h3>
                    <?= htmlspecialchars($team['name']) ?>
                </h3>


                <p>
                    <i class="fa-solid fa-location-dot"></i>
                    <?= htmlspecialchars($team['city']) ?>
                </p>


                <div class="team-details">

                    <span>
                        Coach:
                        <?= htmlspecialchars($team['coach']) ?>
                    </span>

                    <span>
                        <?= $team['players'] ?> Players
                    </span>

                </div>

            </div>

        </div>

    <?php endforeach; ?>

</div>


</main>



<!-- ================= FOOTER ================= -->

<footer class="footer">

    <div class="container">

        © <?= date('Y') ?> SPORTZONE
        • LOCAL SPORTS
        • Football

    </div>

</footer>


</body>
</html>

