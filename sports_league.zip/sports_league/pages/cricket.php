<?php
/*
========================================================
 SPORTZONE - CRICKET PAGE
 File: pages/cricket.php

 This page is self-contained.
 It does NOT depend on cricket_functions.php,
 so path/function errors will not occur here.
========================================================
*/

$liveMatches = [
    [
        'team1' => 'SportZone XI',
        'team2' => 'City Warriors',
        'score1' => '178/4',
        'score2' => '175/7',
        'overs1' => '18.2',
        'overs2' => '20.0',
        'venue' => 'SportZone Stadium',
        'status' => 'LIVE',
        'target' => '176',
        'rr' => '9.71',
        'rrr' => '0.00',
        'striker' => 'Rahul Sharma',
        'striker_runs' => '72',
        'striker_balls' => '41',
        'non_striker' => 'Aman Patel',
        'non_striker_runs' => '35',
        'non_striker_balls' => '22',
        'bowler' => 'V. Kumar',
        'bowler_overs' => '3.2',
        'bowler_runs' => '32',
        'bowler_wickets' => '2',
        'this_over' => ['1', '4', '0', 'W', '6', '2']
    ]
];

$upcomingMatches = [
    [
        'team1' => 'Ahmedabad Lions',
        'team2' => 'Gujarat Warriors',
        'date' => '15 Sep 2026',
        'time' => '7:30 PM',
        'venue' => 'Local Cricket Ground'
    ],
    [
        'team1' => 'City Kings',
        'team2' => 'SportZone XI',
        'date' => '17 Sep 2026',
        'time' => '4:00 PM',
        'venue' => 'SportZone Stadium'
    ],
    [
        'team1' => 'Gujarat Warriors',
        'team2' => 'City Warriors',
        'date' => '19 Sep 2026',
        'time' => '7:30 PM',
        'venue' => 'Community Stadium'
    ]
];

$results = [
    [
        'team1' => 'City Warriors',
        'team2' => 'Ahmedabad Lions',
        'score1' => '165/7',
        'score2' => '160/9',
        'result' => 'City Warriors won by 5 runs'
    ],
    [
        'team1' => 'SportZone XI',
        'team2' => 'Gujarat Warriors',
        'score1' => '189/6',
        'score2' => '181/8',
        'result' => 'SportZone XI won by 8 runs'
    ]
];

$pointsTable = [
    ['team' => 'SportZone XI', 'p' => 5, 'w' => 4, 'l' => 1, 't' => 0, 'pts' => 8, 'nrr' => '+1.25'],
    ['team' => 'City Warriors', 'p' => 5, 'w' => 3, 'l' => 2, 't' => 0, 'pts' => 6, 'nrr' => '+0.65'],
    ['team' => 'Gujarat Warriors', 'p' => 5, 'w' => 2, 'l' => 3, 't' => 0, 'pts' => 4, 'nrr' => '-0.18'],
    ['team' => 'Ahmedabad Lions', 'p' => 5, 'w' => 1, 'l' => 4, 't' => 0, 'pts' => 2, 'nrr' => '-0.72']
];

$topBatsmen = [
    ['name' => 'Rahul Sharma', 'team' => 'SportZone XI', 'runs' => 425, 'avg' => '47.22', 'sr' => '138.5'],
    ['name' => 'Aman Patel', 'team' => 'City Warriors', 'runs' => 391, 'avg' => '43.44', 'sr' => '132.7'],
    ['name' => 'Vivek Shah', 'team' => 'Gujarat Warriors', 'runs' => 368, 'avg' => '40.88', 'sr' => '129.4']
];

$topBowlers = [
    ['name' => 'V. Kumar', 'team' => 'SportZone XI', 'wickets' => 18, 'eco' => '6.42'],
    ['name' => 'R. Patel', 'team' => 'City Warriors', 'wickets' => 15, 'eco' => '7.01'],
    ['name' => 'M. Shah', 'team' => 'Ahmedabad Lions', 'wickets' => 13, 'eco' => '6.88']
];

/*
|--------------------------------------------------------------------------
| DYNAMIC CRICKET TEAMS
|--------------------------------------------------------------------------
| Teams added from admin/dashboard.php are stored in the `teams` table.
| Here we fetch only records whose sport is Cricket.
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/../includes/functions.php';

$teams = [];
$teamDbError = '';

try {
    $sql = "SELECT id, team_name, city, captain
            FROM teams
            WHERE sport = 'Cricket'
            ORDER BY id DESC";

    $teamResult = $conn->query($sql);

    if ($teamResult) {
        while ($row = $teamResult->fetch_assoc()) {
            $teams[] = [
                'name'    => $row['team_name'],
                'city'    => $row['city'],
                'captain' => $row['captain']
            ];
        }

        $teamResult->free();
    } else {
        $teamDbError = $conn->error;
    }

} catch (Throwable $e) {
    $teamDbError = $e->getMessage();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Cricket | SPORTZONE</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    background: #080c11;
    color: #ffffff;
    font-family: Arial, Helvetica, sans-serif;
}

a {
    text-decoration: none;
    color: inherit;
}

.container {
    width: 92%;
    max-width: 1250px;
    margin: auto;
}

/* NAVBAR */

.navbar {
    min-height: 70px;
    background: #0d131a;
    border-bottom: 1px solid #26313d;

    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 0 5%;

    position: sticky;
    top: 0;
    z-index: 999;
}

.logo {
    font-size: 25px;
    font-weight: 900;
}

.logo span {
    color: #ff5b25;
}

.nav-links {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.nav-links a {
    color: #9ba6b3;
    padding: 10px 13px;
    border-radius: 7px;
    font-size: 13px;
    font-weight: bold;
}

.nav-links a:hover,
.nav-links a.active {
    color: #ff5b25;
    background: rgba(255,91,37,.12);
}

/* HERO */

.hero {
    margin-top: 30px;
    padding: 55px 45px;

    border: 1px solid #293440;
    border-radius: 24px;

    background:
        radial-gradient(
            circle at 85% 20%,
            rgba(255,91,37,.20),
            transparent 35%
        ),
        #101820;

    display: flex;
    align-items: center;
    justify-content: space-between;
}

.hero small {
    color: #ff5b25;
    font-weight: bold;
    letter-spacing: 2px;
}

.hero h1 {
    font-size: clamp(42px, 7vw, 75px);
    margin-top: 15px;
}

.hero h1 span {
    color: #ff5b25;
}

.hero p {
    margin-top: 18px;
    max-width: 650px;
    color: #9ba6b3;
    line-height: 1.8;
}

.cricket-icon {
    width: 170px;
    height: 170px;
    border-radius: 50%;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 85px;

    background: rgba(255,91,37,.10);
    border: 1px solid rgba(255,91,37,.35);
}

/* QUICK NAV */

.quick-nav {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 12px;

    margin: 25px 0;
}

.quick-nav a {
    background: #111820;
    border: 1px solid #293440;
    border-radius: 12px;

    padding: 18px 10px;
    text-align: center;

    color: #a5afba;
    font-size: 12px;
    font-weight: bold;
}

.quick-nav a:hover {
    border-color: #ff5b25;
    color: #ff5b25;
}

/* SECTION */

.section {
    margin-top: 60px;
}

.section-title {
    margin-bottom: 22px;
}

.section-title small {
    color: #ff5b25;
    font-size: 11px;
    font-weight: bold;
    letter-spacing: 2px;
}

.section-title h2 {
    margin-top: 8px;
    font-size: 30px;
}

.section-title p {
    color: #7f8a97;
    margin-top: 7px;
    font-size: 13px;
}

/* LIVE MATCH */

.live-card {
    background: #111820;
    border: 1px solid #293440;
    border-radius: 20px;
    padding: 28px;
    overflow: hidden;
}

.live-top {
    display: flex;
    justify-content: space-between;
    align-items: center;

    border-bottom: 1px solid #293440;
    padding-bottom: 18px;
    margin-bottom: 25px;
}

.live-badge {
    color: #ff5148;
    font-weight: 900;
    font-size: 13px;
}

.live-venue {
    color: #7f8a97;
    font-size: 12px;
}

.score-area {
    display: grid;
    grid-template-columns: 1fr 90px 1fr;
    align-items: center;
    text-align: center;
}

.team-name {
    color: #aeb8c3;
    font-size: 16px;
    font-weight: bold;
}

.big-score {
    font-size: 42px;
    font-weight: 900;
    margin-top: 12px;
}

.overs {
    color: #7f8a97;
    margin-top: 5px;
    font-size: 13px;
}

.vs {
    width: 48px;
    height: 48px;
    margin: auto;

    border-radius: 50%;
    background: #222d38;

    display: flex;
    justify-content: center;
    align-items: center;

    color: #9ba6b3;
    font-size: 11px;
    font-weight: bold;
}

.live-info {
    margin-top: 28px;

    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
}

.info-box {
    background: #0c1218;
    border: 1px solid #26313d;
    border-radius: 10px;
    padding: 15px;
    text-align: center;
}

.info-box span {
    display: block;
    color: #778391;
    font-size: 10px;
    margin-bottom: 7px;
}

.info-box strong {
    font-size: 15px;
}

.this-over {
    margin-top: 20px;
    padding: 17px;

    background: #0c1218;
    border-radius: 10px;
}

.this-over-title {
    color: #8d98a4;
    font-size: 11px;
    margin-bottom: 12px;
}

.balls {
    display: flex;
    gap: 9px;
}

.ball {
    width: 34px;
    height: 34px;
    border-radius: 50%;

    background: #202b36;

    display: flex;
    align-items: center;
    justify-content: center;

    font-size: 11px;
    font-weight: bold;
}

.ball.wicket {
    background: #8e2929;
}

.ball.six {
    background: #ff5b25;
}

/* BATSMAN / BOWLER */

.player-boxes {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 18px;

    margin-top: 18px;
}

.player-box {
    background: #0c1218;
    border: 1px solid #293440;
    border-radius: 12px;
    padding: 20px;
}

.player-box h3 {
    font-size: 14px;
    margin-bottom: 15px;
}

.player-row {
    display: flex;
    justify-content: space-between;

    padding: 10px 0;
    border-bottom: 1px solid #202a34;

    font-size: 12px;
}

.player-row:last-child {
    border-bottom: 0;
}

.player-row span {
    color: #8995a2;
}

/* GRID */

.grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 18px;
}

/* UPCOMING */

.match-card {
    background: #111820;
    border: 1px solid #293440;
    border-radius: 15px;
    padding: 22px;
}

.match-date {
    color: #ff5b25;
    font-size: 11px;
    font-weight: bold;
}

.match-card h3 {
    margin-top: 18px;
    font-size: 16px;
}

.vs-line {
    margin: 15px 0;
    color: #778391;
    font-size: 11px;
}

.match-card p {
    color: #7f8a97;
    font-size: 11px;
    line-height: 1.8;
}

/* RESULTS */

.result-score {
    display: flex;
    justify-content: space-between;

    margin-top: 20px;

    font-weight: bold;
}

.result {
    margin-top: 15px;
    color: #ff5b25;
    font-size: 12px;
    font-weight: bold;
}

/* TABLE */

.table-wrapper {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: #111820;
    border: 1px solid #293440;
    border-radius: 15px;
    overflow: hidden;
}

th {
    background: #18212a;
    color: #8e99a5;
    font-size: 11px;
    padding: 15px;
    text-align: center;
}

td {
    padding: 15px;
    text-align: center;
    border-top: 1px solid #26313d;
    font-size: 12px;
}

td:first-child,
th:first-child {
    text-align: left;
}

.team-position {
    color: #ff5b25;
    font-weight: bold;
}

/* PLAYER STATS */

.stat-card {
    background: #111820;
    border: 1px solid #293440;
    border-radius: 15px;
    padding: 22px;
}

.stat-card h3 {
    font-size: 13px;
    color: #ff5b25;
    margin-bottom: 18px;
}

.stat-player {
    padding: 13px 0;
    border-bottom: 1px solid #26313d;
}

.stat-player:last-child {
    border-bottom: 0;
}

.stat-player strong {
    display: block;
    font-size: 13px;
}

.stat-player span {
    display: block;
    margin-top: 5px;
    color: #7f8a97;
    font-size: 11px;
}

.stat-number {
    float: right;
    color: #ffffff;
    font-weight: bold;
}

/* TEAMS */

.team-card {
    background: #111820;
    border: 1px solid #293440;
    border-radius: 15px;
    padding: 22px;
    text-align: center;
}

.team-logo {
    width: 62px;
    height: 62px;
    border-radius: 50%;

    background: rgba(255,91,37,.10);

    margin: auto;

    display: flex;
    justify-content: center;
    align-items: center;

    font-size: 27px;
}

.team-card h3 {
    margin-top: 14px;
    font-size: 15px;
}

.team-card p {
    color: #7f8a97;
    margin-top: 6px;
    font-size: 11px;
}

.captain {
    margin-top: 13px;
    padding-top: 12px;
    border-top: 1px solid #26313d;

    color: #8b96a2;
    font-size: 11px;
}

/* FOOTER */

footer {
    margin-top: 70px;
    padding: 35px 0;

    border-top: 1px solid #26313d;

    text-align: center;

    color: #687583;
    font-size: 12px;
}

/* RESPONSIVE */

@media(max-width: 900px) {

    .quick-nav {
        grid-template-columns: repeat(3, 1fr);
    }

    .grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .live-info {
        grid-template-columns: repeat(2, 1fr);
    }

    .hero {
        padding: 40px 30px;
    }

    .cricket-icon {
        width: 130px;
        height: 130px;
        font-size: 65px;
    }
}

@media(max-width: 600px) {

    .navbar {
        flex-direction: column;
        align-items: flex-start;
        padding: 15px 5%;
        gap: 12px;
    }

    .nav-links {
        overflow-x: auto;
        width: 100%;
    }

    .container {
        width: 94%;
    }

    .hero {
        flex-direction: column;
        align-items: flex-start;
        gap: 30px;
    }

    .cricket-icon {
        align-self: center;
    }

    .quick-nav,
    .grid,
    .player-boxes {
        grid-template-columns: 1fr;
    }

    .score-area {
        grid-template-columns: 1fr;
        gap: 20px;
    }

    .vs {
        margin: 5px auto;
    }

    .live-info {
        grid-template-columns: 1fr 1fr;
    }

    .big-score {
        font-size: 32px;
    }
}

</style>

</head>

<body>


<!-- =====================================================
 NAVBAR
===================================================== -->

<header class="navbar">

    <a href="../index.php" class="logo">
        SPORT<span>ZONE</span>
    </a>

    <nav class="nav-links">

        <a href="../index.php">Home</a>

        <a href="cricket.php" class="active">
            🏏 Cricket
        </a>

        <a href="live-scores.php">
            🔴 Live Scores
        </a>

        <a href="schedule.php">
            📅 Schedule
        </a>

        <a href="standing.php">
            🏆 Standings
        </a>

        <a href="teams.php">
            👥 Teams
        </a>

    </nav>

</header>


<div class="container">


<!-- =====================================================
 HERO
===================================================== -->

<section class="hero">

    <div>

        <small>
            SPORTZONE CRICKET HUB
        </small>

        <h1>
            CRICKET <span>LIVE</span>
        </h1>

        <p>
            Get live cricket scores, match updates, upcoming
            fixtures, recent results, points table, player
            statistics and team information — all in one place.
        </p>

    </div>

    <div class="cricket-icon">
        🏏
    </div>

</section>


<!-- =====================================================
 QUICK MENU
===================================================== -->

<div class="quick-nav">

    <a href="#live">
        🔴<br><br>LIVE SCORE
    </a>

    <a href="#upcoming">
        📅<br><br>FIXTURES
    </a>

    <a href="#results">
        ✅<br><br>RESULTS
    </a>

    <a href="#points">
        🏆<br><br>POINTS TABLE
    </a>

    <a href="#stats">
        📊<br><br>STATS
    </a>

</div>


<!-- =====================================================
 LIVE SCORE
===================================================== -->

<section class="section" id="live">

    <div class="section-title">

        <small>🔴 LIVE NOW</small>

        <h2>Live Cricket Score</h2>

        <p>
            Follow the current match and live scoring information.
        </p>

    </div>


    <?php foreach ($liveMatches as $match): ?>

    <div class="live-card">

        <div class="live-top">

            <span class="live-badge">
                🔴 <?= htmlspecialchars($match['status']) ?>
            </span>

            <span class="live-venue">
                🏟️ <?= htmlspecialchars($match['venue']) ?>
            </span>

        </div>


        <div class="score-area">

            <div>

                <div class="team-name">
                    <?= htmlspecialchars($match['team1']) ?>
                </div>

                <div class="big-score">
                    <?= htmlspecialchars($match['score1']) ?>
                </div>

                <div class="overs">
                    <?= htmlspecialchars($match['overs1']) ?> Overs
                </div>

            </div>


            <div class="vs">
                VS
            </div>


            <div>

                <div class="team-name">
                    <?= htmlspecialchars($match['team2']) ?>
                </div>

                <div class="big-score">
                    <?= htmlspecialchars($match['score2']) ?>
                </div>

                <div class="overs">
                    <?= htmlspecialchars($match['overs2']) ?> Overs
                </div>

            </div>

        </div>


        <div class="live-info">

            <div class="info-box">
                <span>TARGET</span>
                <strong><?= htmlspecialchars($match['target']) ?></strong>
            </div>

            <div class="info-box">
                <span>RUN RATE</span>
                <strong><?= htmlspecialchars($match['rr']) ?></strong>
            </div>

            <div class="info-box">
                <span>REQUIRED RR</span>
                <strong><?= htmlspecialchars($match['rrr']) ?></strong>
            </div>

            <div class="info-box">
                <span>VENUE</span>
                <strong>SPORTZONE</strong>
            </div>

        </div>


        <!-- THIS OVER -->

        <div class="this-over">

            <div class="this-over-title">
                THIS OVER
            </div>

            <div class="balls">

                <?php foreach ($match['this_over'] as $ball): ?>

                    <?php
                    $class = 'ball';

                    if ($ball === 'W') {
                        $class .= ' wicket';
                    }

                    if ($ball === '6') {
                        $class .= ' six';
                    }
                    ?>

                    <div class="<?= $class ?>">
                        <?= htmlspecialchars($ball) ?>
                    </div>

                <?php endforeach; ?>

            </div>

        </div>


        <!-- BATSMAN / BOWLER -->

        <div class="player-boxes">

            <div class="player-box">

                <h3>🏏 CURRENT BATSMEN</h3>

                <div class="player-row">
                    <strong>
                        <?= htmlspecialchars($match['striker']) ?> *
                    </strong>

                    <span>
                        <?= htmlspecialchars($match['striker_runs']) ?>
                        (<?= htmlspecialchars($match['striker_balls']) ?>)
                    </span>
                </div>

                <div class="player-row">
                    <strong>
                        <?= htmlspecialchars($match['non_striker']) ?>
                    </strong>

                    <span>
                        <?= htmlspecialchars($match['non_striker_runs']) ?>
                        (<?= htmlspecialchars($match['non_striker_balls']) ?>)
                    </span>
                </div>

            </div>


            <div class="player-box">

                <h3>🎯 CURRENT BOWLER</h3>

                <div class="player-row">

                    <strong>
                        <?= htmlspecialchars($match['bowler']) ?>
                    </strong>

                    <span>
                        <?= htmlspecialchars($match['bowler_overs']) ?> Ov
                    </span>

                </div>

                <div class="player-row">

                    <span>
                        Runs
                    </span>

                    <strong>
                        <?= htmlspecialchars($match['bowler_runs']) ?>
                    </strong>

                </div>

                <div class="player-row">

                    <span>
                        Wickets
                    </span>

                    <strong>
                        <?= htmlspecialchars($match['bowler_wickets']) ?>
                    </strong>

                </div>

            </div>

        </div>

    </div>

    <?php endforeach; ?>

</section>


<!-- =====================================================
 UPCOMING
===================================================== -->

<section class="section" id="upcoming">

    <div class="section-title">

        <small>📅 FIXTURES</small>

        <h2>Upcoming Matches</h2>

        <p>
            Check the next scheduled cricket matches.
        </p>

    </div>


    <div class="grid">

        <?php foreach ($upcomingMatches as $match): ?>

        <div class="match-card">

            <div class="match-date">
                <?= htmlspecialchars($match['date']) ?>
                •
                <?= htmlspecialchars($match['time']) ?>
            </div>

            <h3>
                <?= htmlspecialchars($match['team1']) ?>
            </h3>

            <div class="vs-line">
                VS
            </div>

            <h3>
                <?= htmlspecialchars($match['team2']) ?>
            </h3>

            <p>
                🏟️ <?= htmlspecialchars($match['venue']) ?>
            </p>

        </div>

        <?php endforeach; ?>

    </div>

</section>


<!-- =====================================================
 RESULTS
===================================================== -->

<section class="section" id="results">

    <div class="section-title">

        <small>✅ RECENT RESULTS</small>

        <h2>Latest Results</h2>

    </div>


    <div class="grid">

        <?php foreach ($results as $result): ?>

        <div class="match-card">

            <h3>
                <?= htmlspecialchars($result['team1']) ?>
            </h3>

            <div class="result-score">

                <span>
                    <?= htmlspecialchars($result['score1']) ?>
                </span>

                <span>
                    VS
                </span>

                <span>
                    <?= htmlspecialchars($result['score2']) ?>
                </span>

            </div>

            <h3 style="margin-top:15px;">
                <?= htmlspecialchars($result['team2']) ?>
            </h3>

            <div class="result">
                ✓ <?= htmlspecialchars($result['result']) ?>
            </div>

        </div>

        <?php endforeach; ?>

    </div>

</section>


<!-- =====================================================
 POINTS TABLE
===================================================== -->

<section class="section" id="points">

    <div class="section-title">

        <small>🏆 TOURNAMENT</small>

        <h2>Points Table</h2>

    </div>


    <div class="table-wrapper">

        <table>

            <thead>

                <tr>
                    <th>TEAM</th>
                    <th>P</th>
                    <th>W</th>
                    <th>L</th>
                    <th>T</th>
                    <th>PTS</th>
                    <th>NRR</th>
                </tr>

            </thead>

            <tbody>

                <?php foreach ($pointsTable as $index => $team): ?>

                <tr>

                    <td>

                        <span class="team-position">
                            <?= $index + 1 ?>.
                        </span>

                        <?= htmlspecialchars($team['team']) ?>

                    </td>

                    <td><?= $team['p'] ?></td>

                    <td><?= $team['w'] ?></td>

                    <td><?= $team['l'] ?></td>

                    <td><?= $team['t'] ?></td>

                    <td>
                        <strong>
                            <?= $team['pts'] ?>
                        </strong>
                    </td>

                    <td>
                        <?= htmlspecialchars($team['nrr']) ?>
                    </td>

                </tr>

                <?php endforeach; ?>

            </tbody>

        </table>

    </div>

</section>


<!-- =====================================================
 PLAYER STATISTICS
===================================================== -->

<section class="section" id="stats">

    <div class="section-title">

        <small>📊 PLAYER PERFORMANCE</small>

        <h2>Top Cricket Statistics</h2>

    </div>


    <div class="grid">


        <!-- TOP BATSMEN -->

        <div class="stat-card">

            <h3>
                🏏 TOP BATSMEN
            </h3>

            <?php foreach ($topBatsmen as $player): ?>

            <div class="stat-player">

                <strong>
                    <?= htmlspecialchars($player['name']) ?>

                    <span class="stat-number">
                        <?= $player['runs'] ?>
                    </span>
                </strong>

                <span>
                    <?= htmlspecialchars($player['team']) ?>
                    • Avg <?= htmlspecialchars($player['avg']) ?>
                    • SR <?= htmlspecialchars($player['sr']) ?>
                </span>

            </div>

            <?php endforeach; ?>

        </div>


        <!-- TOP BOWLERS -->

        <div class="stat-card">

            <h3>
                🎯 TOP BOWLERS
            </h3>

            <?php foreach ($topBowlers as $player): ?>

            <div class="stat-player">

                <strong>
                    <?= htmlspecialchars($player['name']) ?>

                    <span class="stat-number">
                        <?= $player['wickets'] ?> W
                    </span>
                </strong>

                <span>
                    <?= htmlspecialchars($player['team']) ?>
                    • Economy <?= htmlspecialchars($player['eco']) ?>
                </span>

            </div>

            <?php endforeach; ?>

        </div>


        <!-- CRICKET FEATURES -->

        <div class="stat-card">

            <h3>
                ⭐ CRICKET FEATURES
            </h3>

            <div class="stat-player">
                <strong>Live Score</strong>
                <span>Real-time match score updates</span>
            </div>

            <div class="stat-player">
                <strong>Full Scorecard</strong>
                <span>Batting and bowling details</span>
            </div>

            <div class="stat-player">
                <strong>Ball-by-Ball</strong>
                <span>Every delivery and over</span>
            </div>

            <div class="stat-player">
                <strong>Player Stats</strong>
                <span>Runs, wickets, average and strike rate</span>
            </div>

        </div>

    </div>

</section>


<!-- =====================================================
 TEAMS
===================================================== -->

<section class="section">

    <div class="section-title">

        <small>👥 CRICKET TEAMS</small>

        <h2>Teams</h2>

    </div>


    <?php if ($teamDbError !== ''): ?>

        <div class="team-card">
            <h3 style="color:#ff5b25;">Database Error</h3>
            <p>
                <?= htmlspecialchars($teamDbError) ?>
            </p>
        </div>

    <?php elseif (count($teams) > 0): ?>

        <div class="grid">

            <?php foreach ($teams as $team): ?>

            <div class="team-card">

                <div class="team-logo">
                    🏏
                </div>

                <h3>
                    <?= htmlspecialchars($team['name']) ?>
                </h3>

                <p>
                    📍 <?= htmlspecialchars($team['city']) ?>
                </p>

                <div class="captain">
                    Captain:
                    <strong>
                        <?= htmlspecialchars($team['captain']) ?>
                    </strong>
                </div>

            </div>

            <?php endforeach; ?>

        </div>

    <?php else: ?>

        <div class="team-card" style="grid-column:1/-1; text-align:center;">
            <div class="team-logo">
                🏏
            </div>

            <h3>No Cricket Team Added Yet</h3>

            <p>
                Add a Cricket team from the Admin Dashboard and it will
                automatically appear here.
            </p>
        </div>

    <?php endif; ?>

</section>


</div>


<!-- =====================================================
 FOOTER
===================================================== -->

<footer>

    <div class="container">

        🏏 SPORTZONE CRICKET

        <br><br>

        Live Scores • Fixtures • Results • Teams • Players • Statistics

        <br><br>

        © <?= date('Y') ?> SPORTZONE — LOCAL SPORTS

    </div>

</footer>


</body>

</html>

