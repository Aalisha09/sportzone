```php
<?php

/*
=========================================================
SPORTZONE - CRICKET FUNCTIONS
=========================================================
*/

require_once __DIR__ . '/../includes/functions.php';


/*
=========================================================
CRICKET QUERY
=========================================================
*/

function cricketQuery($sql)
{
    global $conn;

    $result = $conn->query($sql);

    if (!$result) {
        return false;
    }

    return $result;
}


/*
=========================================================
CHECK CRICKET TABLE
=========================================================
*/

function cricketTableExists($table)
{
    global $conn;

    $allowed = [
        'cricket_matches',
        'cricket_teams',
        'cricket_scores'
    ];

    if (!in_array($table, $allowed, true)) {
        return false;
    }

    $result = $conn->query("SHOW TABLES LIKE '$table'");

    return $result && $result->num_rows > 0;
}


/*
=========================================================
GET LIVE MATCHES
=========================================================
*/

function getCricketLiveMatches()
{
    if (
        !cricketTableExists('cricket_matches') ||
        !cricketTableExists('cricket_teams') ||
        !cricketTableExists('cricket_scores')
    ) {
        return null;
    }

    $sql = "
        SELECT
            m.id,
            m.venue,
            m.match_date,
            m.match_time,
            m.innings,

            t1.team_name AS team1_name,
            t2.team_name AS team2_name,

            COALESCE(s.team1_runs, 0) AS team1_runs,
            COALESCE(s.team1_wickets, 0) AS team1_wickets,
            COALESCE(s.team1_overs, '0.0') AS team1_overs,

            COALESCE(s.team2_runs, 0) AS team2_runs,
            COALESCE(s.team2_wickets, 0) AS team2_wickets,
            COALESCE(s.team2_overs, '0.0') AS team2_overs

        FROM cricket_matches m

        INNER JOIN cricket_teams t1
            ON t1.id = m.team1_id

        INNER JOIN cricket_teams t2
            ON t2.id = m.team2_id

        LEFT JOIN cricket_scores s
            ON s.match_id = m.id

        WHERE m.status = 'live'

        ORDER BY m.match_date DESC, m.match_time DESC

        LIMIT 6
    ";

    return cricketQuery($sql);
}


/*
=========================================================
GET UPCOMING MATCHES
=========================================================
*/

function getCricketUpcomingMatches()
{
    if (
        !cricketTableExists('cricket_matches') ||
        !cricketTableExists('cricket_teams')
    ) {
        return null;
    }

    $sql = "
        SELECT
            m.id,
            m.venue,
            m.match_date,
            m.match_time,

            t1.team_name AS team1_name,
            t2.team_name AS team2_name

        FROM cricket_matches m

        INNER JOIN cricket_teams t1
            ON t1.id = m.team1_id

        INNER JOIN cricket_teams t2
            ON t2.id = m.team2_id

        WHERE m.status = 'upcoming'

        ORDER BY m.match_date ASC, m.match_time ASC

        LIMIT 6
    ";

    return cricketQuery($sql);
}


/*
=========================================================
GET COMPLETED MATCHES
=========================================================
*/

function getCricketResults()
{
    if (
        !cricketTableExists('cricket_matches') ||
        !cricketTableExists('cricket_teams')
    ) {
        return null;
    }

    $sql = "
        SELECT
            m.id,
            m.venue,
            m.match_date,
            m.match_time,
            m.result_text,

            t1.team_name AS team1_name,
            t2.team_name AS team2_name

        FROM cricket_matches m

        INNER JOIN cricket_teams t1
            ON t1.id = m.team1_id

        INNER JOIN cricket_teams t2
            ON t2.id = m.team2_id

        WHERE m.status = 'completed'

        ORDER BY m.match_date DESC, m.match_time DESC

        LIMIT 6
    ";

    return cricketQuery($sql);
}


/*
=========================================================
GET CRICKET TEAMS
=========================================================
*/

function getCricketTeams()
{
    if (!cricketTableExists('cricket_teams')) {
        return null;
    }

    $sql = "
        SELECT
            t.id,
            t.team_name,
            t.city,
            t.coach,
            t.captain,
            t.founded_year

        FROM cricket_teams t

        ORDER BY t.team_name ASC
    ";

    return cricketQuery($sql);
}

