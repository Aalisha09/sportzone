<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>About Us | SportZone</title>

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>

        /* =====================================================
           SPORTZONE ABOUT PAGE
           SAME DESIGN AS INDEX.PHP
        ===================================================== */

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            background: #080c11;
            color: #ffffff;
            overflow-x: hidden;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        img {
            max-width: 100%;
            display: block;
        }

        .container {
            width: 90%;
            max-width: 1250px;
            margin: auto;
        }


        /* =====================================================
           HEADER
        ===================================================== */

        .main-header {
            width: 100%;
            height: 86px;
            background: #0b1016;
            border-bottom: 1px solid #202731;
            position: relative;
            z-index: 1000;
        }

        .nav-container {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 30px;
        }


        /* LOGO */

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            min-width: 230px;
        }

        .logo-image {
            width: 58px;
            height: 58px;
            object-fit: contain;
            border-radius: 12px;
        }

        .logo-text {
            display: flex;
            flex-direction: column;
            line-height: 1;
        }

        .logo-text span {
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 3px;
            color: #ffffff;
        }

        .logo-text strong {
            font-size: 22px;
            font-weight: 900;
            color: #ff5b25;
            letter-spacing: 1px;
        }


        /* NAVBAR */

        .navbar {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .navbar a {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-width: 90px;
            padding: 13px 15px;
            border-radius: 9px;
            color: #aeb6c2;
            font-size: 14px;
            font-weight: 600;
            transition: 0.3s ease;
        }

        .navbar a i {
            font-size: 14px;
        }

        .navbar a:hover,
        .navbar a.active {
            color: #ff5b25;
            background: rgba(255, 91, 37, 0.12);
        }

        .header-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #ff5b25;
            color: #ffffff;
            padding: 15px 24px;
            border-radius: 10px;
            font-weight: 700;
            font-size: 14px;
            transition: 0.3s;
        }

        .header-btn:hover {
            background: #ff713f;
            transform: translateY(-2px);
        }

        .menu-toggle {
            display: none;
            background: none;
            border: none;
            color: #ffffff;
            font-size: 25px;
            cursor: pointer;
        }


        /* =====================================================
           LIVE TICKER
        ===================================================== */

        .live-ticker {
            height: 40px;
            background: #121820;
            border-bottom: 1px solid #242c36;
            display: flex;
            align-items: center;
            overflow: hidden;
            position: relative;
            z-index: 100;
        }

        .ticker-label {
            height: 100%;
            min-width: 140px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            background: #ff5b25;
            color: #ffffff;
            font-size: 12px;
            font-weight: 800;
        }

        .ticker-content {
            display: flex;
            align-items: center;
            gap: 80px;
            padding-left: 40px;
            white-space: nowrap;
            color: #b8c0ca;
            font-size: 12px;
        }

        .ticker-content span {
            display: inline-block;
        }

        .live-dot {
            width: 8px;
            height: 8px;
            background: #ff3b30;
            border-radius: 50%;
            display: inline-block;
            box-shadow: 0 0 0 5px rgba(255, 59, 48, 0.12);
            animation: pulse 1.5s infinite;
        }

        @keyframes pulse {

            0% {
                box-shadow: 0 0 0 0 rgba(255, 59, 48, 0.6);
            }

            70% {
                box-shadow: 0 0 0 8px rgba(255, 59, 48, 0);
            }

            100% {
                box-shadow: 0 0 0 0 rgba(255, 59, 48, 0);
            }

        }


        /* =====================================================
           ABOUT HERO
        ===================================================== */

        .about-hero {
            min-height: 430px;
            position: relative;
            overflow: hidden;

            background:
                linear-gradient(
                    90deg,
                    rgba(5, 9, 14, 0.98) 0%,
                    rgba(5, 9, 14, 0.88) 50%,
                    rgba(5, 9, 14, 0.55) 100%
                ),
                radial-gradient(
                    circle at 80% 40%,
                    rgba(255, 91, 37, 0.20),
                    transparent 35%
                );
        }

        .about-hero::before {
            content: "";
            position: absolute;
            width: 550px;
            height: 550px;
            right: -220px;
            top: -180px;
            border-radius: 50%;
            background: rgba(255, 91, 37, 0.08);
            filter: blur(5px);
        }

        .about-hero-content {
            min-height: 430px;
            display: flex;
            align-items: center;
            position: relative;
            z-index: 2;
        }

        .about-hero-text {
            max-width: 850px;
        }

        .about-small-title {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #ff713f;
            font-size: 13px;
            font-weight: 800;
            letter-spacing: 2px;
            margin-bottom: 20px;
        }

        .about-small-title i {
            font-size: 15px;
        }

        .about-hero-text h1 {
            font-size: clamp(45px, 6vw, 75px);
            line-height: 1;
            font-weight: 900;
            letter-spacing: -2px;
            margin-bottom: 25px;
        }

        .about-hero-text h1 span {
            color: #ff5b25;
        }

        .about-hero-text p {
            max-width: 720px;
            color: #aeb7c2;
            font-size: 16px;
            line-height: 1.8;
        }


        /* =====================================================
           ABOUT STORY
        ===================================================== */

        .about-section {
            padding: 90px 0;
            background: #080c11;
        }

        .about-grid {
            display: grid;
            grid-template-columns: 1.1fr 0.9fr;
            gap: 70px;
            align-items: center;
        }

        .section-label {
            display: flex;
            align-items: center;
            gap: 9px;
            color: #ff5b25;
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 2px;
            margin-bottom: 12px;
        }

        .about-content h2 {
            font-size: 42px;
            font-weight: 900;
            letter-spacing: -1px;
            margin-bottom: 22px;
        }

        .about-content h2 span {
            color: #ff5b25;
        }

        .about-content p {
            color: #8f9aa7;
            font-size: 14px;
            line-height: 1.9;
            margin-bottom: 18px;
        }


        /* IMAGE BOX */

        .about-image-box {
            position: relative;
        }

        .about-image {
            width: 100%;
            height: 390px;
            object-fit: cover;
            border-radius: 18px;
            border: 1px solid #303b48;
            box-shadow: 0 30px 70px rgba(0, 0, 0, 0.4);
        }

        .image-overlay {
            position: absolute;
            left: 25px;
            bottom: 25px;
            background: rgba(11, 16, 22, 0.94);
            border: 1px solid #303b48;
            border-radius: 12px;
            padding: 18px 22px;
            backdrop-filter: blur(10px);
        }

        .image-overlay strong {
            display: block;
            font-size: 24px;
            color: #ff5b25;
        }

        .image-overlay span {
            color: #aeb6c2;
            font-size: 11px;
        }


        /* =====================================================
           FEATURES
        ===================================================== */

        .features-section {
            padding: 90px 0;
            background: #0d131a;
        }

        .center-heading {
            text-align: center;
            margin-bottom: 45px;
        }

        .center-heading .section-label {
            justify-content: center;
        }

        .center-heading h2 {
            font-size: 38px;
            font-weight: 900;
        }

        .center-heading h2 span {
            color: #ff5b25;
        }

        .center-heading p {
            color: #7f8b98;
            font-size: 13px;
            margin-top: 10px;
        }

        .feature-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .feature-card {
            background: #111820;
            border: 1px solid #27313c;
            border-radius: 15px;
            padding: 30px;
            transition: 0.3s;
            position: relative;
            overflow: hidden;
        }

        .feature-card::before {
            content: "";
            position: absolute;
            width: 120px;
            height: 120px;
            right: -45px;
            top: -45px;
            border-radius: 50%;
            background: rgba(255, 91, 37, 0.08);
        }

        .feature-card:hover {
            transform: translateY(-7px);
            border-color: #ff5b25;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.25);
        }

        .feature-icon {
            width: 55px;
            height: 55px;
            border-radius: 13px;
            background: rgba(255, 91, 37, 0.12);
            color: #ff5b25;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
            margin-bottom: 25px;
        }

        .feature-card h3 {
            font-size: 18px;
            margin-bottom: 10px;
        }

        .feature-card p {
            color: #7e8a96;
            font-size: 12px;
            line-height: 1.8;
        }


        /* =====================================================
           STATISTICS
        ===================================================== */

        .stats-section {
            background: #10161e;
            border-top: 1px solid #202a34;
            border-bottom: 1px solid #202a34;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
        }

        .stat-box {
            min-height: 130px;
            display: flex;
            align-items: center;
            gap: 18px;
            padding: 25px;
            border-right: 1px solid #29323c;
        }

        .stat-box:last-child {
            border-right: none;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            flex-shrink: 0;
            border-radius: 12px;
            background: rgba(255, 91, 37, 0.12);
            color: #ff5b25;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .stat-box h2 {
            font-size: 28px;
            font-weight: 900;
        }

        .stat-box p {
            color: #8994a1;
            font-size: 12px;
            margin-top: 3px;
        }


        /* =====================================================
           CTA
        ===================================================== */

        .about-cta {
            padding: 90px 0;
            background:
                radial-gradient(
                    circle at 70% 50%,
                    rgba(255, 91, 37, 0.20),
                    transparent 40%
                ),
                #111820;
            border-top: 1px solid #28323c;
        }

        .cta-content {
            max-width: 750px;
        }

        .cta-content > span {
            color: #ff5b25;
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 2px;
        }

        .cta-content h2 {
            font-size: 45px;
            font-weight: 900;
            margin: 15px 0;
        }

        .cta-content h2 strong {
            color: #ff5b25;
        }

        .cta-content p {
            color: #8b96a2;
            line-height: 1.8;
            margin-bottom: 28px;
        }

        .cta-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background: #ff5b25;
            color: #ffffff;
            padding: 14px 22px;
            border-radius: 9px;
            font-size: 13px;
            font-weight: 800;
            transition: 0.3s;
        }

        .cta-btn:hover {
            background: #ff713f;
            transform: translateY(-3px);
        }


        /* =====================================================
           FOOTER
        ===================================================== */

        .footer {
            background: #080c11;
            padding-top: 70px;
        }

        .footer-grid {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1.5fr;
            gap: 50px;
            padding-bottom: 50px;
        }

        .footer-logo {
            margin-bottom: 20px;
        }

        .footer-about p {
            color: #75818d;
            font-size: 12px;
            line-height: 1.8;
            max-width: 350px;
        }

        .social-icons {
            display: flex;
            gap: 9px;
            margin-top: 20px;
        }

        .social-icons a {
            width: 36px;
            height: 36px;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #151c24;
            border: 1px solid #27313c;
            border-radius: 8px;
            color: #9aa5b0;
            transition: 0.3s;
        }

        .social-icons a:hover {
            background: #ff5b25;
            border-color: #ff5b25;
            color: #ffffff;
        }

        .footer-column {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .footer-column h3 {
            color: #ffffff;
            font-size: 14px;
            margin-bottom: 8px;
        }

        .footer-column a,
        .footer-column p {
            color: #77828e;
            font-size: 11px;
            transition: 0.3s;
        }

        .footer-column a:hover {
            color: #ff5b25;
        }

        .footer-column p {
            display: flex;
            gap: 9px;
            line-height: 1.5;
        }

        .footer-column p i {
            color: #ff5b25;
            width: 15px;
        }

        .footer-bottom {
            min-height: 70px;
            border-top: 1px solid #202932;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #65717d;
            font-size: 10px;
        }

        .footer-bottom strong {
            color: #ff5b25;
        }


        /* =====================================================
           RESPONSIVE
        ===================================================== */

        @media (max-width: 1000px) {

            .navbar a {
                min-width: auto;
                padding: 12px 9px;
            }

            .about-grid {
                grid-template-columns: 1fr;
                gap: 40px;
            }

            .feature-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .footer-grid {
                grid-template-columns: repeat(2, 1fr);
            }

        }


        @media (max-width: 850px) {

            .main-header {
                height: 75px;
            }

            .menu-toggle {
                display: block;
            }

            .navbar {
                display: none;
                position: absolute;
                top: 75px;
                left: 0;
                width: 100%;
                background: #0b1016;
                border-bottom: 1px solid #27313c;
                padding: 15px;
                flex-direction: column;
            }

            .navbar.show {
                display: flex;
            }

            .navbar a {
                width: 100%;
                justify-content: flex-start;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .stat-box:nth-child(2) {
                border-right: none;
            }

        }


        @media (max-width: 600px) {

            .container {
                width: 92%;
            }

            .logo {
                min-width: auto;
            }

            .logo-image {
                width: 45px;
                height: 45px;
            }

            .logo-text strong {
                font-size: 17px;
            }

            .logo-text span {
                font-size: 9px;
            }

            .ticker-label {
                min-width: 105px;
                font-size: 9px;
            }

            .ticker-content {
                gap: 40px;
                padding-left: 20px;
            }

            .about-hero-text h1 {
                font-size: 45px;
            }

            .about-hero-text p {
                font-size: 13px;
            }

            .about-content h2 {
                font-size: 32px;
            }

            .feature-grid {
                grid-template-columns: 1fr;
            }

            .stats-grid {
                grid-template-columns: 1fr 1fr;
            }

            .stat-box {
                padding: 18px 12px;
                gap: 10px;
            }

            .stat-icon {
                width: 40px;
                height: 40px;
                font-size: 15px;
            }

            .stat-box h2 {
                font-size: 21px;
            }

            .footer-grid {
                grid-template-columns: 1fr;
            }

            .footer-bottom {
                flex-direction: column;
                gap: 15px;
                justify-content: center;
                text-align: center;
                padding: 20px 0;
            }

        }

    </style>
</head>

<body>


<!-- =====================================================
     HEADER
===================================================== -->

<header class="main-header">

    <div class="container nav-container">

        <a href="../index.php" class="logo">

            <!-- Agar logo.png available hai to ye use karega -->
            <img src="../assets/images/logo.png"
                 class="logo-image"
                 alt="SportZone Logo">

            <div class="logo-text">
                <span>LOCAL</span>
                <strong>SPORTZONE</strong>
            </div>

        </a>


        <nav class="navbar">

            <a href="../index.php">
                <i class="fa-solid fa-house"></i>
                Home
            </a>

            <a href="about.php" class="active">
                <i class="fa-solid fa-circle-info"></i>
                About
            </a>

           
             <a href="live-scores.php">
                <i class="fa-solid fa-ranking fa-bolt"></i>
                Live Score
            </a>

            <a href="schedule.php">
                <i class="fa-solid fa-calendar-days"></i>
                Schedule
            </a>

            
            <a href="standings.php">
                <i class="fa-solid fa-ranking-star"></i>
                Standings
            </a>

           

            <a href="teams.php">
                <i class="fa-solid fa-users"></i>
                Teams
            </a>

        </nav>


        <a href="admin_login.php" class="header-btn">
            <i class="fa-solid fa-user-shield"></i>
            Admin Login
        </a>


        <button class="menu-toggle" onclick="toggleMenu()">
            <i class="fa-solid fa-bars"></i>
        </button>

    </div>

</header>


<!-- =====================================================
     LIVE TICKER
===================================================== -->

<div class="live-ticker">

    <div class="ticker-label">

        <span class="live-dot"></span>

        LIVE NOW

    </div>


    <div class="ticker-content">

        <span>
            ⚽ Eagles FC 2 - 1 Tigers United
        </span>

        <span>
            🏀 Warriors 78 - 72 Panthers
        </span>

        <span>
            🏏 Ahmedabad Kings 145/6
        </span>

        <span>
            ⚽ City FC 3 - 2 United FC
        </span>

    </div>

</div>


<!-- =====================================================
     ABOUT HERO
===================================================== -->

<section class="about-hero">

    <div class="container about-hero-content">

        <div class="about-hero-text">

            <div class="about-small-title">

                <i class="fa-solid fa-trophy"></i>

                ABOUT SPORTZONE

            </div>


            <h1>
                WHERE LOCAL
                <span>SPORTS</span>
                COME ALIVE.
            </h1>


            <p>
                SportZone is a modern local sports league platform
                created to connect players, teams, organizers and
                passionate fans in one place.
            </p>

        </div>

    </div>

</section>


<!-- =====================================================
     OUR STORY
===================================================== -->

<section class="about-section">

    <div class="container">

        <div class="about-grid">


            <div class="about-content">

                <div class="section-label">

                    <i class="fa-solid fa-bolt"></i>

                    OUR STORY

                </div>


                <h2>
                    More Than Just A
                    <span>Scoreboard.</span>
                </h2>


                <p>
                    Local Sports League is a digital platform
                    created for sports communities. Our goal is
                    to make it easier for players, teams and fans
                    to follow everything happening in their local
                    tournaments.
                </p>


                <p>
                    From live scores and match schedules to team
                    standings and tournament results, SportZone
                    keeps all important information available in
                    one simple and modern platform.
                </p>


                <p>
                    Whether you are a player, team manager,
                    tournament organizer or sports fan, SportZone
                    gives you everything you need to stay connected
                    with local sports.
                </p>

            </div>


            <div class="about-image-box">

                <img
                    src="https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=1000&q=80"
                    alt="Local Sports"
                    class="about-image"
                >


                <div class="image-overlay">

                    <strong>1000+</strong>

                    <span>Matches & Counting</span>

                </div>

            </div>

        </div>

    </div>

</section>


<!-- =====================================================
     FEATURES
===================================================== -->

<section class="features-section">

    <div class="container">

        <div class="center-heading">

            <div class="section-label">
                <i class="fa-solid fa-star"></i>
                WHY SPORTZONE?
            </div>

            <h2>
                Everything About
                <span>Local Sports.</span>
            </h2>

            <p>
                One platform for players, teams and fans.
            </p>

        </div>


        <div class="feature-grid">


            <div class="feature-card">

                <div class="feature-icon">
                    <i class="fa-solid fa-bolt"></i>
                </div>

                <h3>Live Updates</h3>

                <p>
                    Follow matches and scores in real time
                    and never miss an important moment.
                </p>

            </div>


            <div class="feature-card">

                <div class="feature-icon">
                    <i class="fa-solid fa-calendar-days"></i>
                </div>

                <h3>Easy Scheduling</h3>

                <p>
                    Find upcoming matches and tournament
                    schedules quickly and easily.
                </p>

            </div>


            <div class="feature-card">

                <div class="feature-icon">
                    <i class="fa-solid fa-ranking-star"></i>
                </div>

                <h3>Team Standings</h3>

                <p>
                    Check team rankings, points, wins,
                    losses and tournament performance.
                </p>

            </div>


            <div class="feature-card">

                <div class="feature-icon">
                    <i class="fa-solid fa-users"></i>
                </div>

                <h3>Manage Teams</h3>

                <p>
                    Keep team information organized and
                    easily accessible for everyone.
                </p>

            </div>


            <div class="feature-card">

                <div class="feature-icon">
                    <i class="fa-solid fa-chart-line"></i>
                </div>

                <h3>Match Statistics</h3>

                <p>
                    View useful statistics and tournament
                    performance information.
                </p>

            </div>


            <div class="feature-card">

                <div class="feature-icon">
                    <i class="fa-solid fa-globe"></i>
                </div>

                <h3>Local Community</h3>

                <p>
                    Connect players, teams, organizers and
                    fans through one platform.
                </p>

            </div>


        </div>

    </div>

</section>


<!-- =====================================================
     STATISTICS
===================================================== -->

<section class="stats-section">

    <div class="container">

        <div class="stats-grid">


            <div class="stat-box">

                <div class="stat-icon">
                    <i class="fa-solid fa-users"></i>
                </div>

                <div>
                    <h2>50+</h2>
                    <p>Teams</p>
                </div>

            </div>


            <div class="stat-box">

                <div class="stat-icon">
                    <i class="fa-solid fa-trophy"></i>
                </div>

                <div>
                    <h2>20+</h2>
                    <p>Tournaments</p>
                </div>

            </div>


            <div class="stat-box">

                <div class="stat-icon">
                    <i class="fa-solid fa-user-group"></i>
                </div>

                <div>
                    <h2>500+</h2>
                    <p>Players</p>
                </div>

            </div>


            <div class="stat-box">

                <div class="stat-icon">
                    <i class="fa-solid fa-futbol"></i>
                </div>

                <div>
                    <h2>1000+</h2>
                    <p>Matches</p>
                </div>

            </div>


        </div>

    </div>

</section>


<!-- =====================================================
     CTA
===================================================== -->

<section class="about-cta">

    <div class="container">

        <div class="cta-content">

            <span>JOIN THE COMMUNITY</span>

            <h2>
                Ready To Make Your
                <strong>Match Count?</strong>
            </h2>

            <p>
                Follow your favorite teams, check live scores,
                explore tournament schedules and stay connected
                with the local sports community.
            </p>

            <a href="schedule.php" class="cta-btn">

                View Schedule

                <i class="fa-solid fa-arrow-right"></i>

            </a>

        </div>

    </div>

</section>


<!-- =====================================================
     FOOTER
===================================================== -->

<footer class="footer">

    <div class="container">

        <div class="footer-grid">


            <div class="footer-about">

                <div class="logo footer-logo">

                    <img
                        src="../assets/images/logo.png"
                        class="logo-image"
                        alt="SportZone Logo"
                    >

                    <div class="logo-text">

                        <span>LOCAL</span>

                        <strong>SPORTZONE</strong>

                    </div>

                </div>


                <p>
                    SportZone is a local sports league platform
                    connecting players, teams and fans through
                    live scores, schedules and tournaments.
                </p>


                <div class="social-icons">

                    <a href="#">
                        <i class="fa-brands fa-facebook-f"></i>
                    </a>

                    <a href="#">
                        <i class="fa-brands fa-instagram"></i>
                    </a>

                    <a href="#">
                        <i class="fa-brands fa-twitter"></i>
                    </a>

                    <a href="#">
                        <i class="fa-brands fa-youtube"></i>
                    </a>

                </div>

            </div>


            <div class="footer-column">

                <h3>QUICK LINKS</h3>

                <a href="../index.php">Home</a>

                <a href="about.php">About</a>

                <a href="live-scores.php">Live Scores</a>

                <a href="schedule.php">Schedule</a>

            </div>


            <div class="footer-column">

                <h3>SPORTS</h3>

                <a href="#">Football</a>

                <a href="#">Cricket</a>

                <a href="#">Basketball</a>

                <a href="#">Volleyball</a>

            </div>


            <div class="footer-column">

                <h3>CONTACT</h3>

                <p>
                    <i class="fa-solid fa-location-dot"></i>
                    Ahmedabad, Gujarat
                </p>

                <p>
                    <i class="fa-solid fa-envelope"></i>
                    info@sportzone.com
                </p>

                <p>
                    <i class="fa-solid fa-phone"></i>
                    +91 98765 43210
                </p>

            </div>


        </div>


        <div class="footer-bottom">

            <span>
                © 2026 <strong>SportZone</strong>.
                All Rights Reserved.
            </span>

            <div>

                <a href="#">Privacy Policy</a>

                <a href="#">Terms & Conditions</a>

            </div>

        </div>

    </div>

</footer>


<script>

    function toggleMenu() {

        const navbar = document.querySelector('.navbar');

        navbar.classList.toggle('show');

    }

</script>


</body>
</html>