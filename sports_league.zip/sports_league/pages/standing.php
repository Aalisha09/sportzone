<?php
$page_title = "Standings | SportZone";
require_once '../includes/header.php';
?>

<style>

/* =====================================================
   STANDINGS PAGE
===================================================== */

.standings-page {
    background: #05090e;
    color: #ffffff;
    min-height: 100vh;
}


/* =====================================================
   HERO
===================================================== */

.standings-hero {
    padding: 75px 0 65px;

    background:
        radial-gradient(
            circle at 82% 35%,
            rgba(255, 91, 37, 0.18),
            transparent 38%
        ),
        #080c11;

    border-bottom: 1px solid #202932;
}


.standings-container {
    width: min(1150px, 92%);
    margin: auto;
}


.standings-label {
    display: flex;
    align-items: center;
    gap: 9px;

    color: #ff5b25;

    font-size: 12px;
    font-weight: 800;

    letter-spacing: 2px;

    margin-bottom: 18px;
}


.standings-label i {
    font-size: 15px;
}


.standings-hero h1 {
    margin: 0 0 18px;

    font-size: clamp(45px, 6vw, 72px);

    line-height: 1;

    font-weight: 900;

    letter-spacing: -2px;
}


.standings-hero h1 span {
    color: #ff5b25;
}


.standings-hero p {
    max-width: 700px;

    color: #8995a1;

    font-size: 14px;

    line-height: 1.8;
}


/* =====================================================
   MAIN SECTION
===================================================== */

.standings-section {
    padding: 75px 0 100px;
}


/* =====================================================
   SECTION HEADER
===================================================== */

.section-heading {
    text-align: center;
    margin-bottom: 40px;
}


.section-heading .small-title {
    color: #ff5b25;

    font-size: 11px;
    font-weight: 800;

    letter-spacing: 2px;

    margin-bottom: 12px;
}


.section-heading h2 {
    margin: 0;

    font-size: 38px;
    font-weight: 900;
}


.section-heading h2 span {
    color: #ff5b25;
}


.section-heading p {
    color: #75818d;

    font-size: 12px;

    margin-top: 10px;
}


/* =====================================================
   FILTERS
===================================================== */

.standings-filters {
    display: flex;

    justify-content: center;

    gap: 10px;

    flex-wrap: wrap;

    margin-bottom: 40px;
}


.standings-filter {
    border: 1px solid #2a3540;

    background: #111820;

    color: #9ca7b2;

    padding: 11px 20px;

    border-radius: 8px;

    font-family: inherit;

    font-size: 10px;

    font-weight: 800;

    cursor: pointer;

    transition: 0.3s;
}


.standings-filter:hover,
.standings-filter.active {

    background: #ff5b25;

    border-color: #ff5b25;

    color: #ffffff;

    transform: translateY(-2px);
}


/* =====================================================
   LEAGUE BAR
===================================================== */

.league-bar {

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 18px 22px;

    background: #111820;

    border: 1px solid #29343f;

    border-left: 4px solid #ff5b25;

    border-radius: 12px 12px 0 0;
}


.league-info {
    display: flex;

    align-items: center;

    gap: 13px;
}


.league-icon {

    width: 42px;
    height: 42px;

    display: flex;

    align-items: center;
    justify-content: center;
  
    border-radius: 9px;

    background: rgba(255, 91, 37, 0.10);

    color: #ff5b25;

    font-size: 18px;
}


.league-info h3 {

    font-size: 13px;

    font-weight: 800;

    margin-bottom: 4px;
}


.league-info span {

    color: #687581;

    font-size: 9px;
}


.season {

    color: #ff5b25;

    font-size: 10px;

    font-weight: 800;

    padding: 7px 11px;

    border-radius: 5px;

    background: rgba(255, 91, 37, 0.08);
}


/* =====================================================
   TABLE
===================================================== */

.table-wrapper {

    overflow-x: auto;

    background: #0d131a;

    border: 1px solid #29343f;

    border-top: none;

    border-radius: 0 0 12px 12px;
}


.standings-table {

    width: 100%;

    min-width: 850px;

    border-collapse: collapse;
}


.standings-table thead {

    background: #151d25;
}


.standings-table th {

    padding: 16px 14px;

    color: #687581;

    font-size: 9px;

    font-weight: 800;

    letter-spacing: 1px;

    text-align: center;

    border-bottom: 1px solid #29343f;yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyiooooooooooooooooooooooooooooooooo
}


.standings-table th:first-child {

    text-align: center;
}


.standings-table td {

    padding: 17px 14px;

    text-align: center;

    color: #aeb7c2;

    font-size: 11px;

    font-weight: 600;

    border-bottom: 1px solid #202a34;
}


.standings-table tbody tr {

    transition: 0.3s;
}l/


.standings-table tbody tr:hover {

    background: rgba(255, 91, 37, 0.045);
}


.standings-table tbody tr:last-child td {

    border-bottom: none;
}


/* =====================================================
   POSITION
===================================================== */

.position {

    width: 50px;

    color: #687581 !important;

    font-weight: 900 !important;
}


.position.top-one {

    color: #ffbd32 !important;
}


.position.top-two {

    color: #bfc7ce !important;
}


.position.top-three {

    color: #cd8a57 !important;
}


/* =====================================================
   TEAM
===================================================== */

.team-cell {

    display: flex;

    align-items: center;

    gap: 12px;

    text-align: left;

    min-width: 200px;
}


.team-badge {

    width: 38px;
    height: 38px;

    flex-shrink: 0;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 9px;

    background: #151d26;

    border: 1px solid #303b47;

    color: #ff5b25;

    font-size: 15px;

    transition: 0.3s;
}


.standings-table tr:hover .team-badge {

    background: rgba(255, 91, 37, 0.10);

    border-color: #ff5b25;

    transform: scale(1.08);
}


.team-name {

    color: #ffffff;

    font-size: 11px;

    font-weight: 800;
}


.team-city {

    display: block;

    color: #65717d;

    font-size: 8px;

    margin-top: 4px;
}


/* =====================================================
   POINTS
===================================================== */

.points {

    color: #ff5b25 !important;

    font-size: 14px !important;

    font-weight: 900 !important;
}


/* =====================================================
   FORM
===================================================== */

.form {

    display: flex;

    justify-content: center;

    gap: 4px;
}


.form span {

    width: 20px;
    height: 20px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 4px;

    font-size: 8px;

    font-weight: 900;
}


.form .win {

    background: rgba(46, 204, 113, 0.12);

    color: #36d47b;
}


.form .draw {

    background: rgba(241, 196, 15, 0.12);

    color: #e8c526;
}


.form .loss {

    background: rgba(255, 59, 48, 0.10);

    color: #ff5046;
}


/* =====================================================
   TOP TEAM ROW
===================================================== */

.top-team {

    background:
        linear-gradient(
            90deg,
            rgba(255, 91, 37, 0.055),
            transparent
        );
}


/* =====================================================
   LEGEND
===================================================== */

.table-legend {

    display: flex;

    align-items: center;

    gap: 20px;

    flex-wrap: wrap;

    margin-top: 18px;

    color: #65717d;

    font-size: 9px;
}


.legend-item {

    display: flex;

    align-items: center;

    gap: 7px;
}


.legend-color {

    width: 9px;
    height: 9px;

    border-radius: 2px;
}


.legend-color.green {

    background: #36d47b;
}


.legend-color.yellow {

    background: #e8c526;
}


.legend-color.red {

    background: #ff5046;
}


/* =====================================================
   STATS CARDS
===================================================== */

.stats-grid {

    display: grid;

    grid-template-columns: repeat(4, 1fr);

    gap: 18px;

    margin-top: 55px;
}


.stat-card {

    background: #0d131a;

    border: 1px solid #242e38;

    border-radius: 12px;

    padding: 22px;

    text-align: center;

    transition: 0.3s;
}


.stat-card:hover {

    transform: translateY(-5px);

    border-color: #ff5b25;
}


.stat-icon {

    width: 42px;
    height: 42px;

    margin: 0 auto 12px;

    display: flex;

    align-items: center;
    justify-content: center;

    border-radius: 9px;

    background: rgba(255, 91, 37, 0.10);

    color: #ff5b25;

    font-size: 16px;
}


.stat-card h3 {

    font-size: 20px;

    font-weight: 900;

    margin-bottom: 5px;
}


.stat-card p {

    color: #65717d;

    font-size: 9px;

    font-weight: 700;

    text-transform: uppercase;

    letter-spacing: 1px;
}


/* =====================================================
   CTA
===================================================== */

.standings-cta {

    margin-top: 65px;

    padding: 45px 30px;

    text-align: center;

    border: 1px solid #29343f;

    border-radius: 15px;

    background:
        radial-gradient(
            circle at center,
            rgba(255, 91, 37, 0.09),
            transparent 60%
        );
}


.standings-cta h2 {

    font-size: 28px;

    font-weight: 900;

    margin-bottom: 10px;
}


.standings-cta h2 span {

    color: #ff5b25;
}


.standings-cta p {

    max-width: 600px;

    margin: auto;

    color: #75818d;

    font-size: 11px;

    line-height: 1.8;
}


/* =====================================================
   RESPONSIVE
===================================================== */

@media(max-width: 900px) {

    .stats-grid {

        grid-template-columns: repeat(2, 1fr);
    }

}


@media(max-width: 600px) {

    .standings-hero {

        padding: 55px 0;
    }


    .standings-hero h1 {

        font-size: 45px;
    }


    .standings-section {

        padding: 55px 0 70px;
    }


    .section-heading h2 {

        font-size: 30px;
    }


    .league-bar {

        align-items: flex-start;

        gap: 15px;

        flex-direction: column;
    }


    .stats-grid {

        grid-template-columns: 1fr 1fr;

        gap: 10px;
    }


    .stat-card {

        padding: 17px 10px;
    }


    .standings-cta {

        padding: 35px 20px;
    }

}


@media(max-width: 400px) {

    .stats-grid {

        grid-template-columns: 1fr;
    }

}

</style>


<!-- =====================================================
     PAGE
===================================================== -->

<div class="standings-page">


    <!-- =================================================
         HERO
    ================================================= -->

    <section class="standings-hero">

        <div class="standings-container">

            <div class="standings-label">

                <i class="fa-solid fa-ranking-star"></i>

                LEAGUE TABLE

            </div>


            <h1>

                TEAM <span>STANDINGS.</span>

            </h1>


            <p>

                Track team performance, points, wins and
                overall league rankings throughout the
                SportZone local sports season.

            </p>

        </div>

    </section>


    <!-- =================================================
         MAIN
    ================================================= -->

    <section class="standings-section">

        <div class="standings-container">


            <!-- SECTION HEADING -->

            <div class="section-heading">

                <div class="small-title">

                    <i class="fa-solid fa-trophy"></i>

                    CURRENT SEASON

                </div>


                <h2>

                    League <span>Standings.</span>

                </h2>


                <p>

                    Updated after every completed match.

                </p>

            </div>


            <!-- =================================================
                 FILTERS
            ================================================= -->

            <div class="standings-filters">

    <button class="standings-filter active"
            onclick="window.location.href='football.php';">
        <i class="fa-solid fa-futbol"></i>
        Football
    </button>

    <button class="standings-filter"
            onclick="window.location.href='cricket.php';">
        <i class="fa-solid fa-baseball-bat-ball"></i>
        Cricket
    </button>

    <button class="standings-filter"
            onclick="window.location.href='basketball.php';">
        <i class="fa-solid fa-basketball"></i>
        Basketball
    </button>

    <button class="standings-filter"
            onclick="window.location.href='volleyball.php';">
        <i class="fa-solid fa-volleyball"></i>
        Volleyball
    </button>

</div>


            <!-- =================================================
                 LEAGUE BAR
            ================================================= -->

            <div class="league-bar">

                <div class="league-info">

                    <div class="league-icon">

                        <i class="fa-solid fa-trophy"></i>

                    </div>


                    <div>

                        <h3>
                            City Football League
                        </h3>

                        <span>
                            Ahmedabad Local Championship
                        </span>

                    </div>

                </div>


                <div class="season">

                    SEASON 2026

                </div>

            </div>


            <!-- =================================================
                 TABLE
            ================================================= -->

            <div class="table-wrapper">

                <table class="standings-table">

                    <thead>

                        <tr>

                            <th>POS</th>

                            <th style="text-align:left;">
                                TEAM
                            </th>

                            <th>PLAYED</th>

                            <th>WON</th>

                            <th>DRAW</th>

                            <th>LOST</th>

                            <th>GF</th>

                            <th>GA</th>

                            <th>GD</th>

                            <th>PTS</th>

                            <th>FORM</th>

                        </tr>

                    </thead>


                    <tbody>


                        <!-- TEAM 1 -->

                        <tr class="top-team">

                            <td class="position top-one">

                                01

                            </td>


                            <td>

                                <div class="team-cell">

                                    <div class="team-badge">

                                        <i class="fa-solid fa-shield-halved"></i>

                                    </div>


                                    <div>

                                        <div class="team-name">

                                            Eagles FC

                                        </div>

                                        <span class="team-city">

                                            Ahmedabad

                                        </span>

                                    </div>

                                </div>

                            </td>


                            <td>8</td>

                            <td>6</td>

                            <td>1</td>

                            <td>1</td>

                            <td>19</td>

                            <td>7</td>

                            <td>+12</td>


                            <td class="points">

                                19

                            </td>


                            <td>

                                <div class="form">

                                    <span class="win">W</span>
                                    <span class="win">W</span>
                                    <span class="win">W</span>
                                    <span class="draw">D</span>
                                    <span class="win">W</span>

                                </div>

                            </td>

                        </tr>


                        <!-- TEAM 2 -->

                        <tr class="top-team">

                            <td class="position top-two">

                                02

                            </td>


                            <td>

                                <div class="team-cell">

                                    <div class="team-badge">

                                        <i class="fa-solid fa-shield"></i>

                                    </div>


                                    <div>

                                        <div class="team-name">

                                            Tigers United

                                        </div>

                                        <span class="team-city">

                                            Ahmedabad

                                        </span>

                                    </div>

                                </div>

                            </td>


                            <td>8</td>

                            <td>5</td>

                            <td>2</td>

                            <td>1</td>

                            <td>17</td>

                            <td>9</td>

                            <td>+8</td>


                            <td class="points">

                                17

                            </td>


                            <td>

                                <div class="form">

                                    <span class="win">W</span>
                                    <span class="draw">D</span>
                                    <span class="win">W</span>
                                    <span class="win">W</span>
                                    <span class="draw">D</span>

                                </div>

                            </td>

                        </tr>


                        <!-- TEAM 3 -->

                        <tr class="top-team">

                            <td class="position top-three">

                                03

                            </td>


                            <td>

                                <div class="team-cell">

                                    <div class="team-badge">

                                        <i class="fa-solid fa-shield"></i>

                                    </div>


                                    <div>

                                        <div class="team-name">

                                            City FC

                                        </div>

                                        <span class="team-city">

                                            Ahmedabad

                                        </span>

                                    </div>

                                </div>

                            </td>


                            <td>8</td>

                            <td>4</td>

                            <td>2</td>

                            <td>2</td>

                            <td>15</td>

                            <td>10</td>

                            <td>+5</td>


                            <td class="points">

                                14

                            </td>


                            <td>

                                <div class="form">

                                    <span class="win">W</span>
                                    <span class="loss">L</span>
                                    <span class="win">W</span>
                                    <span class="draw">D</span>
                                    <span class="win">W</span>

                                </div>

                            </td>

                        </tr>


                        <!-- TEAM 4 -->

                        <tr>

                            <td class="position">

                                04

                            </td>


                            <td>

                                <div class="team-cell">

                                    <div class="team-badge">

                                        <i class="fa-solid fa-shield-halved"></i>

                                    </div>


                                    <div>

                                        <div class="team-name">

                                            United FC

                                        </div>

                                        <span class="team-city">

                                            Ahmedabad

                                        </span>

                                    </div>

                                </div>

                            </td>


                            <td>8</td>

                            <td>4</td>

                            <td>1</td>

                            <td>3</td>

                            <td>13</td>

                            <td>11</td>

                            <td>+2</td>


                            <td class="points">

                                13

                            </td>


                            <td>

                                <div class="form">

                                    <span class="win">W</span>
                                    <span class="win">W</span>
                                    <span class="loss">L</span>
                                    <span class="loss">L</span>
                                    <span class="win">W</span>

                                </div>

                            </td>

                        </tr>


                        <!-- TEAM 5 -->

                        <tr>

                            <td class="position">

                                05

                            </td>


                            <td>

                                <div class="team-cell">

                                    <div class="team-badge">

                                        <i class="fa-solid fa-shield"></i>

                                    </div>


                                    <div>

                                        <div class="team-name">

                                            Warriors FC

                                        </div>

                                        <span class="team-city">

                                            Gandhinagar

                                        </span>

                                    </div>

                                </div>

                            </td>


                            <td>8</td>

                            <td>3</td>

                            <td>2</td>

                            <td>3</td>

                            <td>12</td>

                            <td>12</td>

                            <td>0</td>


                            <td class="points">

                                11

                            </td>


                            <td>

                                <div class="form">

                                    <span class="draw">D</span>
                                    <span class="win">W</span>
                                    <span class="loss">L</span>
                                    <span class="win">W</span>
                                    <span class="loss">L</span>

                                </div>

                            </td>

                        </tr>


                        <!-- TEAM 6 -->

                        <tr>

                            <td class="position">

                                06

                            </td>


                            <td>

                                <div class="team-cell">

                                    <div class="team-badge">

                                        <i class="fa-solid fa-shield-halved"></i>

                                    </div>


                                    <div>

                                        <div class="team-name">

                                            Panthers FC

                                        </div>

                                        <span class="team-city">

                                            Ahmedabad

                                        </span>

                                    </div>

                                </div>

                            </td>


                            <td>8</td>

                            <td>2</td>

                            <td>2</td>

                            <td>4</td>

                            <td>10</td>

                            <td>14</td>

                            <td>-4</td>


                            <td class="points">

                                8

                            </td>


                            <td>

                                <div class="form">

                                    <span class="loss">L</span>
                                    <span class="draw">D</span>
                                    <span class="win">W</span>
                                    <span class="loss">L</span>
                                    <span class="loss">L</span>

                                </div>

                            </td>

                        </tr>


                        <!-- TEAM 7 -->

                        <tr>

                            <td class="position">

                                07

                            </td>


                            <td>

                                <div class="team-cell">

                                    <div class="team-badge">

                                        <i class="fa-solid fa-shield"></i>

                                    </div>


                                    <div>

                                        <div class="team-name">

                                            Falcons FC

                                        </div>

                                        <span class="team-city">

                                            Mehsana

                                        </span>

                                    </div>

                                </div>

                            </td>


                            <td>8</td>

                            <td>1</td>

                            <td>2</td>

                            <td>5</td>

                            <td>8</td>

                            <td>16</td>

                            <td>-8</td>


                            <td class="points">

                                5

                            </td>


                            <td>

                                <div class="form">

                                    <span class="loss">L</span>
                                    <span class="loss">L</span>
                                    <span class="draw">D</span>
                                    <span class="loss">L</span>
                                    <span class="win">W</span>

                                </div>

                            </td>

                        </tr>


                        <!-- TEAM 8 -->

                        <tr>

                            <td class="position">

                                08

                            </td>


                            <td>

                                <div class="team-cell">

                                    <div class="team-badge">

                                        <i class="fa-solid fa-shield-halved"></i>

                                    </div>


                                    <div>

                                        <div class="team-name">

                                            Royal FC

                                        </div>

                                        <span class="team-city">

                                            Anand

                                        </span>

                                    </div>

                                </div>

                            </td>


                            <td>8</td>

                            <td>1</td>

                            <td>1</td>

                            <td>6</td>

                            <td>6</td>

                            <td>17</td>

                            <td>-11</td>


                            <td class="points">

                                4

                            </td>


                            <td>

                                <div class="form">

                                    <span class="loss">L</span>
                                    <span class="loss">L</span>
                                    <span class="loss">L</span>
                                    <span class="draw">D</span>
                                    <span class="loss">L</span>

                                </div>

                            </td>

                        </tr>


                    </tbody>

                </table>

            </div>


            <!-- =================================================
                 LEGEND
            ================================================= -->

            <div class="table-legend">

                <div class="legend-item">

                    <span class="legend-color green"></span>

                    Win

                </div>


                <div class="legend-item">

                    <span class="legend-color yellow"></span>

                    Draw

                </div>


                <div class="legend-item">

                    <span class="legend-color red"></span>

                    Loss

                </div>

            </div>


            <!-- =================================================
                 STATS
            ================================================= -->

            <div class="stats-grid">


                <div class="stat-card">

                    <div class="stat-icon">

                        <i class="fa-solid fa-users"></i>

                    </div>

                    <h3>8</h3>

                    <p>Teams</p>

                </div>


                <div class="stat-card">

                    <div class="stat-icon">

                        <i class="fa-solid fa-futbol"></i>

                    </div>

                    <h3>32</h3>

                    <p>Matches</p>

                </div>


                <div class="stat-card">

                    <div class="stat-icon">

                        <i class="fa-solid fa-bullseye"></i>

                    </div>

                    <h3>100</h3>

                    <p>Goals</p>

                </div>


                <div class="stat-card">

                    <div class="stat-icon">

                        <i class="fa-solid fa-trophy"></i>

                    </div>

                    <h3>Eagles FC</h3>

                    <p>Top Team</p>

                </div>


            </div>


            <!-- =================================================
                 CTA
            ================================================= -->

            <div class="standings-cta">

                <h2>

                    Follow The

                    <span>League.</span>

                </h2>


                <p>

                    Stay updated with team rankings, match
                    results and league performance throughout
                    the SportZone season.

                </p>

            </div>


        </div>

    </section>

</div>


<?php
require_once '../includes/footer.php';
?>