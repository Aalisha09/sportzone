<?php
/*
|--------------------------------------------------------------------------
| SPORTZONE - VOLLEYBALL PAGE
|--------------------------------------------------------------------------
| File:
| C:\wamp64\www\sports_league\pages\volleyball.php
|
| Standalone demo page - No database required.
|--------------------------------------------------------------------------
*/


/* ================= LIVE MATCH ================= */

$liveMatch = [

    'team1' => 'SportZone Spikers',
    'short1' => 'SZ',

    'team2' => 'City Smashers',
    'short2' => 'CS',

    'set1_team1' => 25,
    'set1_team2' => 21,

    'set2_team1' => 22,
    'set2_team2' => 25,

    'set3_team1' => 18,
    'set3_team2' => 17,

    'sets1' => 1,
    'sets2' => 1,

    'currentSet' => 'Set 3',

    'venue' => 'SportZone Indoor Arena',

    'serve' => 'SportZone Spikers',

    'timeouts1' => 1,
    'timeouts2' => 2,

    'kills1' => 31,
    'kills2' => 27,

    'blocks1' => 6,
    'blocks2' => 4,

    'aces1' => 5,
    'aces2' => 3,

    'errors1' => 7,
    'errors2' => 9,

    'topPlayer1' => 'Rahul Sharma',
    'topPlayer1Pts' => 15,

    'topPlayer2' => 'Aman Patel',
    'topPlayer2Pts' => 13

];


/* ================= UPCOMING MATCHES ================= */

$upcomingMatches = [

    [
        'date' => '14 Sep 2026',
        'time' => '06:30 PM',
        'team1' => 'Ahmedabad Spikers',
        'team2' => 'SportZone Spikers',
        'venue' => 'City Indoor Arena'
    ],

    [
        'date' => '16 Sep 2026',
        'time' => '07:00 PM',
        'team1' => 'City Smashers',
        'team2' => 'River Volleyball Club',
        'venue' => 'Riverdale Arena'
    ],

    [
        'date' => '18 Sep 2026',
        'time' => '06:00 PM',
        'team1' => 'SportZone Spikers',
        'team2' => 'Ahmedabad Spikers',
        'venue' => 'SportZone Indoor Arena'
    ]

];


/* ================= RESULTS ================= */

$results = [

    [
        'date' => '10 Sep 2026',
        'team1' => 'SportZone Spikers',
        'team2' => 'River Volleyball Club',
        'sets1' => 3,
        'sets2' => 1,
        'score' => '25-19, 23-25, 25-18, 25-21',
        'result' => 'SportZone Spikers won'
    ],

    [
        'date' => '07 Sep 2026',
        'team1' => 'Ahmedabad Spikers',
        'team2' => 'City Smashers',
        'sets1' => 3,
        'sets2' => 2,
        'score' => '25-21, 20-25, 25-22, 22-25, 15-12',
        'result' => 'Ahmedabad Spikers won'
    ],

    [
        'date' => '04 Sep 2026',
        'team1' => 'River Volleyball Club',
        'team2' => 'Ahmedabad Spikers',
        'sets1' => 1,
        'sets2' => 3,
        'score' => '21-25, 25-22, 19-25, 20-25',
        'result' => 'Ahmedabad Spikers won'
    ]

];


/* ================= STANDINGS ================= */

$standings = [

    [
        'pos' => 1,
        'team' => 'SportZone Spikers',
        'p' => 8,
        'w' => 7,
        'l' => 1,
        'setsWon' => 22,
        'setsLost' => 7,
        'pts' => 21
    ],

    [
        'pos' => 2,
        'team' => 'Ahmedabad Spikers',
        'p' => 8,
        'w' => 6,
        'l' => 2,
        'setsWon' => 20,
        'setsLost' => 9,
        'pts' => 18
    ],

    [
        'pos' => 3,
        'team' => 'City Smashers',
        'p' => 8,
        'w' => 4,
        'l' => 4,
        'setsWon' => 16,
        'setsLost' => 14,
        'pts' => 13
    ],

    [
        'pos' => 4,
        'team' => 'River Volleyball Club',
        'p' => 8,
        'w' => 2,
        'l' => 6,
        'setsWon' => 10,
        'setsLost' => 20,
        'pts' => 8
    ]

];


/* ================= TOP ATTACKERS ================= */

$topAttackers = [

    [
        'player' => 'Rahul Sharma',
        'team' => 'SportZone Spikers',
        'points' => 126,
        'kills' => 105
    ],

    [
        'player' => 'Aman Patel',
        'team' => 'City Smashers',
        'points' => 118,
        'kills' => 96
    ],

    [
        'player' => 'Vikram Singh',
        'team' => 'Ahmedabad Spikers',
        'points' => 114,
        'kills' => 91
    ],

    [
        'player' => 'Arjun Mehta',
        'team' => 'SportZone Spikers',
        'points' => 103,
        'kills' => 84
    ],

    [
        'player' => 'Karan Shah',
        'team' => 'River Volleyball Club',
        'points' => 91,
        'kills' => 76
    ]

];


/* ================= TOP SERVERS ================= */

$topServers = [

    [
        'player' => 'Rahul Sharma',
        'team' => 'SportZone Spikers',
        'aces' => 24
    ],

    [
        'player' => 'Vikram Singh',
        'team' => 'Ahmedabad Spikers',
        'aces' => 21
    ],

    [
        'player' => 'Aman Patel',
        'team' => 'City Smashers',
        'aces' => 18
    ],

    [
        'player' => 'Arjun Mehta',
        'team' => 'SportZone Spikers',
        'aces' => 16
    ]

];


/* ================= TOP BLOCKERS ================= */

$topBlockers = [

    [
        'player' => 'Vikram Singh',
        'team' => 'Ahmedabad Spikers',
        'blocks' => 31
    ],

    [
        'player' => 'Rahul Sharma',
        'team' => 'SportZone Spikers',
        'blocks' => 28
    ],

    [
        'player' => 'Aman Patel',
        'team' => 'City Smashers',
        'blocks' => 24
    ],

    [
        'player' => 'Karan Shah',
        'team' => 'River Volleyball Club',
        'blocks' => 22
    ]

];


/* ================= TEAMS ================= */

$teams = [

    [
        'name' => 'SportZone Spikers',
        'city' => 'Ahmedabad',
        'coach' => 'R. Desai',
        'players' => 14
    ],

    [
        'name' => 'Ahmedabad Spikers',
        'city' => 'Ahmedabad',
        'coach' => 'M. Patel',
        'players' => 13
    ],

    [
        'name' => 'City Smashers',
        'city' => 'Gandhinagar',
        'coach' => 'A. Shah',
        'players' => 14
    ],

    [
        'name' => 'River Volleyball Club',
        'city' => 'Vadodara',
        'coach' => 'S. Mehta',
        'players' => 13
    ]

];

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Volleyball | SPORTZONE</title>


<!-- FONT AWESOME -->

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


<!-- GOOGLE FONT -->

<link rel="preconnect"
href="https://fonts.googleapis.com">

<link rel="preconnect"
href="https://fonts.gstatic.com"
crossorigin>


<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap"
rel="stylesheet">


<style>

/* =========================================================
   RESET
========================================================= */

* {

    margin: 0;

    padding: 0;

    box-sizing: border-box;

}


body {

    background: #080c11;

    color: #ffffff;

    font-family: 'Montserrat', sans-serif;

    min-height: 100vh;

}


a {

    text-decoration: none;

    color: inherit;

}


.container {

    width: 92%;

    max-width: 1400px;

    margin: auto;

}


/* =========================================================
   HEADER
========================================================= */

.top-header {

    background: #0d131a;

    border-bottom: 1px solid #202934;

    padding: 18px 0;

    position: sticky;

    top: 0;

    z-index: 1000;

}


.header-inner {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 20px;

}


.logo-area {

    display: flex;

    align-items: center;

    gap: 12px;

}


.logo-icon {

    width: 45px;

    height: 45px;

    border-radius: 12px;

    background: #ff5b25;

    display: flex;

    justify-content: center;

    align-items: center;

    font-size: 21px;

}


.logo-text h2 {

    font-size: 20px;

    font-weight: 800;

}


.logo-text span {

    font-size: 10px;

    color: #ff5b25;

    letter-spacing: 2px;

}


.back-btn {

    border: 1px solid #303a46;

    padding: 10px 16px;

    border-radius: 8px;

    color: #cbd5df;

    font-size: 13px;

    transition: 0.3s;

}


.back-btn:hover {

    background: #ff5b25;

    color: white;

    border-color: #ff5b25;

}


/* =========================================================
   PAGE TITLE
========================================================= */

.page-title {

    padding: 35px 0 20px;

}


.page-title h1 {

    font-size: 32px;

    font-weight: 800;

}


.page-title p {

    color: #8995a3;

    margin-top: 8px;

    font-size: 13px;

}


/* =========================================================
   SECTION
========================================================= */

.section-title {

    display: flex;

    justify-content: space-between;

    align-items: center;

    margin: 25px 0 15px;

}


.section-title h2 {

    font-size: 19px;

}


.section-title h2 i {

    color: #ff5b25;

    margin-right: 7px;

}


.live-badge {

    background: #ff5b25;

    padding: 7px 12px;

    border-radius: 20px;

    font-size: 10px;

    font-weight: 800;

    letter-spacing: 1px;

}


/* =========================================================
   LIVE CARD
========================================================= */

.live-card {

    background: #111820;

    border: 1px solid #27313c;

    border-radius: 16px;

    overflow: hidden;

    box-shadow: 0 15px 40px rgba(0,0,0,0.25);

}


.match-top {

    padding: 14px 20px;

    border-bottom: 1px solid #27313c;

    display: flex;

    justify-content: space-between;

    color: #929daa;

    font-size: 11px;

}


.match-status {

    color: #ff5b25;

    font-weight: 800;

}


/* =========================================================
   SCORE AREA
========================================================= */

.match-main {

    display: grid;

    grid-template-columns: 1fr 280px 1fr;

    align-items: center;

    padding: 35px 30px;

    text-align: center;

}


.team-logo {

    width: 75px;

    height: 75px;

    margin: 0 auto 12px;

    border-radius: 50%;

    background: #1b242e;

    border: 2px solid #374452;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 20px;

    font-weight: 800;

    color: #ff5b25;

}


.team h3 {

    font-size: 18px;

}


.score-box h1 {

    font-size: 42px;

    letter-spacing: 2px;

}


.set-badge {

    display: inline-block;

    margin-top: 10px;

    background: #ff5b25;

    padding: 7px 15px;

    border-radius: 20px;

    font-size: 11px;

    font-weight: 800;

}


.score-box p {

    color: #8995a3;

    font-size: 10px;

    margin-top: 9px;

}


/* =========================================================
   SET SCORES
========================================================= */

.set-scores {

    border-top: 1px solid #27313c;

    border-bottom: 1px solid #27313c;

    padding: 18px 25px;

    overflow-x: auto;

}


.set-table {

    width: 100%;

    border-collapse: collapse;

}


.set-table th {

    color: #788591;

    font-size: 9px;

    padding: 7px;

}


.set-table td {

    text-align: center;

    padding: 8px;

    font-size: 12px;

    font-weight: 700;

}


.set-table td:first-child {

    text-align: left;

    color: #dce2e8;

}


.current-score {

    color: #ff5b25 !important;

}


/* =========================================================
   PLAYER HIGHLIGHT
========================================================= */

.player-highlight {

    border-bottom: 1px solid #27313c;

    padding: 15px 20px;

    display: flex;

    justify-content: center;

    gap: 60px;

    font-size: 11px;

}


.player-highlight span {

    color: #8995a3;

}


.player-highlight strong {

    color: white;

}


/* =========================================================
   STATS
========================================================= */

.match-stats {

    padding: 20px 30px 30px;

}


.stat-row {

    display: grid;

    grid-template-columns: 70px 1fr 70px;

    gap: 15px;

    align-items: center;

    margin: 15px 0;

    font-size: 11px;

}


.stat-name {

    text-align: center;

    color: #8d98a5;

    margin-bottom: 6px;

}


.progress {

    height: 6px;

    background: #27313c;

    border-radius: 10px;

    overflow: hidden;

}


.progress-inner {

    height: 100%;

    background: #ff5b25;

    border-radius: 10px;

}


.value {

    font-weight: 700;

}


/* =========================================================
   GRID
========================================================= */

.two-grid {

    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 20px;

}


.three-grid {

    display: grid;

    grid-template-columns: repeat(3, 1fr);

    gap: 20px;

}


/* =========================================================
   BOX
========================================================= */

.box {

    background: #111820;

    border: 1px solid #27313c;

    border-radius: 14px;

    overflow: hidden;

}


.box-header {

    padding: 16px 18px;

    border-bottom: 1px solid #27313c;

    display: flex;

    justify-content: space-between;

    align-items: center;

}


.box-header h3 {

    font-size: 14px;

}


.box-header i {

    color: #ff5b25;

}


.box-body {

    padding: 18px;

}


/* =========================================================
   FIXTURES
========================================================= */

.fixture {

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 15px 0;

    border-bottom: 1px solid #222b34;

}


.fixture:last-child {

    border-bottom: none;

}


.fixture-date {

    width: 105px;

}


.fixture-date strong {

    display: block;

    font-size: 11px;

}


.fixture-date span {

    font-size: 10px;

    color: #7e8995;

}


.fixture-teams {

    text-align: center;

    flex: 1;

}


.fixture-teams strong {

    font-size: 12px;

}


.fixture-teams span {

    display: block;

    color: #7e8995;

    font-size: 10px;

    margin-top: 4px;

}


.vs {

    color: #ff5b25 !important;

    font-weight: 800;

}


/* =========================================================
   RESULTS
========================================================= */

.result {

    padding: 15px 0;

    border-bottom: 1px solid #222b34;

}


.result:last-child {

    border-bottom: none;

}


.result-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

}


.result-score {

    font-size: 18px;

    font-weight: 800;

    color: #ffffff;

}


.result-date {

    color: #7e8995;

    font-size: 9px;

    margin-top: 5px;

}


.result-details {

    color: #8995a3;

    font-size: 9px;

    margin-top: 5px;

}


.result-status {

    color: #70d69a;

    font-size: 9px;

    font-weight: 700;

}


/* =========================================================
   TABLE
========================================================= */

.table-wrapper {

    overflow-x: auto;

}


table {

    width: 100%;

    border-collapse: collapse;

}


th {

    background: #171f28;

    color: #8995a3;

    font-size: 10px;

    text-transform: uppercase;

}


th,
td {

    padding: 13px 10px;

    text-align: center;

    border-bottom: 1px solid #222b34;

}


td {

    font-size: 11px;

    color: #d6dde5;

}


.team-name {

    text-align: left !important;

    font-weight: 600;

}


.position {

    color: #ff5b25;

    font-weight: 800;

}


.points {

    font-weight: 800;

}


/* =========================================================
   PLAYER
========================================================= */

.player {

    display: flex;

    align-items: center;

    gap: 13px;

    padding: 13px 0;

    border-bottom: 1px solid #222b34;

}


.player:last-child {

    border-bottom: none;

}


.player-icon {

    width: 40px;

    height: 40px;

    background: #1c2630;

    border-radius: 50%;

    display: flex;

    align-items: center;

    justify-content: center;

    color: #ff5b25;

}


.player-info {

    flex: 1;

}


.player-info strong {

    display: block;

    font-size: 11px;

}


.player-info span {

    display: block;

    color: #788591;

    font-size: 9px;

    margin-top: 4px;

}


.player-number {

    font-size: 18px;

    font-weight: 800;

    text-align: center;

}


.player-number small {

    display: block;

    font-size: 8px;

    color: #7e8995;

}


/* =========================================================
   TEAM CARD
========================================================= */

.team-card {

    padding: 20px;

    text-align: center;

}


.team-card-icon {

    width: 65px;

    height: 65px;

    background: #1b242e;

    border: 1px solid #374452;

    margin: auto;

    border-radius: 50%;

    display: flex;

    justify-content: center;

    align-items: center;

    color: #ff5b25;

    font-size: 22px;

}


.team-card h3 {

    font-size: 13px;

    margin-top: 12px;

}


.team-card p {

    font-size: 10px;

    color: #7e8995;

    margin-top: 5px;

}


.team-details {

    margin-top: 15px;

    padding-top: 12px;

    border-top: 1px solid #27313c;

    display: flex;

    justify-content: space-between;

    font-size: 9px;

    color: #8d98a5;

}


/* =========================================================
   QUICK STATS
========================================================= */

.quick-stat {

    background: #111820;

    border: 1px solid #27313c;

    border-radius: 12px;

    padding: 20px;

    text-align: center;

}


.quick-stat i {

    color: #ff5b25;

    font-size: 20px;

}


.quick-stat h3 {

    margin-top: 10px;

    font-size: 24px;

}


.quick-stat p {

    color: #7e8995;

    font-size: 10px;

    margin-top: 5px;

}


/* =========================================================
   FOOTER
========================================================= */

.footer {

    margin-top: 50px;

    padding: 25px 0;

    text-align: center;

    border-top: 1px solid #202934;

    color: #66727e;

    font-size: 10px;

}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width: 900px) {

    .match-main {

        grid-template-columns: 1fr;

        gap: 25px;

    }


    .score-box {

        order: -1;

    }


    .two-grid,
    .three-grid {

        grid-template-columns: 1fr;

    }

}


@media(max-width: 600px) {

    .container {

        width: 94%;

    }


    .page-title h1 {

        font-size: 25px;

    }


    .score-box h1 {

        font-size: 34px;

    }


    .player-highlight {

        gap: 15px;

        flex-wrap: wrap;

    }


    .stat-row {

        grid-template-columns: 50px 1fr 50px;

        gap: 8px;

    }


    .fixture-date {

        width: 80px;

    }

}

</style>

</head>


<body>


<!-- =========================================================
     HEADER
========================================================= -->

<header class="top-header">

    <div class="container header-inner">


        <div class="logo-area">

            <div class="logo-icon">

                <i class="fa-solid fa-volleyball"></i>

            </div>


            <div class="logo-text">

                <h2>SPORTZONE</h2>

                <span>LOCAL SPORTS</span>

            </div>

        </div>



        <a href="../index.php"
           class="back-btn">

            <i class="fa-solid fa-arrow-left"></i>

            Back to Home

        </a>


    </div>

</header>



<main class="container">


<!-- =========================================================
     PAGE TITLE
========================================================= -->

<section class="page-title">

    <h1>

        <i class="fa-solid fa-volleyball"
           style="color:#ff5b25;"></i>

        Volleyball

    </h1>


    <p>

        Live scores, set scores, fixtures, results,
        standings and player statistics

    </p>

</section>



<!-- =========================================================
     LIVE MATCH
========================================================= -->

<div class="section-title">

    <h2>

        <i class="fa-solid fa-circle-play"></i>

        Live Match

    </h2>


    <span class="live-badge">

        ● LIVE

    </span>

</div>



<div class="live-card">


    <!-- MATCH HEADER -->

    <div class="match-top">

        <span>

            <i class="fa-solid fa-location-dot"></i>

            <?= htmlspecialchars($liveMatch['venue']) ?>

        </span>


        <span class="match-status">

            LIVE • <?= htmlspecialchars($liveMatch['currentSet']) ?>

        </span>

    </div>



    <!-- TEAMS + SCORE -->

    <div class="match-main">


        <!-- TEAM 1 -->

        <div class="team">

            <div class="team-logo">

                <?= htmlspecialchars($liveMatch['short1']) ?>

            </div>


            <h3>

                <?= htmlspecialchars($liveMatch['team1']) ?>

            </h3>

        </div>



        <!-- CURRENT SCORE -->

        <div class="score-box">

            <h1>

                <?= $liveMatch['set3_team1'] ?>

                -

                <?= $liveMatch['set3_team2'] ?>

            </h1>


            <span class="set-badge">

                <?= htmlspecialchars($liveMatch['currentSet']) ?>

            </span>


            <p>

                Match Score:

                <?= $liveMatch['sets1'] ?>

                -

                <?= $liveMatch['sets2'] ?>

                Sets

            </p>

        </div>



        <!-- TEAM 2 -->

        <div class="team">

            <div class="team-logo">

                <?= htmlspecialchars($liveMatch['short2']) ?>

            </div>


            <h3>

                <?= htmlspecialchars($liveMatch['team2']) ?>

            </h3>

        </div>


    </div>



    <!-- SET SCORES -->

    <div class="set-scores">


        <table class="set-table">


            <thead>

                <tr>

                    <th>Team</th>

                    <th>Set 1</th>

                    <th>Set 2</th>

                    <th>Set 3</th>

                    <th>Set 4</th>

                    <th>Set 5</th>

                    <th>Sets</th>

                </tr>

            </thead>


            <tbody>


                <tr>

                    <td>

                        <?= htmlspecialchars($liveMatch['team1']) ?>

                    </td>


                    <td>

                        <?= $liveMatch['set1_team1'] ?>

                    </td>


                    <td>

                        <?= $liveMatch['set2_team1'] ?>

                    </td>


                    <td class="current-score">

                        <?= $liveMatch['set3_team1'] ?>

                    </td>


                    <td>

                        -

                    </td>


                    <td>

                        -

                    </td>


                    <td class="current-score">

                        <?= $liveMatch['sets1'] ?>

                    </td>

                </tr>



                <tr>

                    <td>

                        <?= htmlspecialchars($liveMatch['team2']) ?>

                    </td>


                    <td>

                        <?= $liveMatch['set1_team2'] ?>

                    </td>


                    <td>

                        <?= $liveMatch['set2_team2'] ?>

                    </td>


                    <td class="current-score">

                        <?= $liveMatch['set3_team2'] ?>

                    </td>


                    <td>

                        -

                    </td>


                    <td>

                        -

                    </td>


                    <td class="current-score">

                        <?= $liveMatch['sets2'] ?>

                    </td>

                </tr>


            </tbody>


        </table>

    </div>



    <!-- TOP PLAYERS -->

    <div class="player-highlight">


        <span>

            ⭐

            <strong>

                <?= htmlspecialchars($liveMatch['topPlayer1']) ?>

            </strong>

            -

            <?= $liveMatch['topPlayer1Pts'] ?> PTS

        </span>



        <span>

            ⭐

            <strong>

                <?= htmlspecialchars($liveMatch['topPlayer2']) ?>

            </strong>

            -

            <?= $liveMatch['topPlayer2Pts'] ?> PTS

        </span>


    </div>



    <!-- MATCH STATS -->

    <div class="match-stats">


        <!-- KILLS -->

        <div class="stat-row">

            <div class="value">

                <?= $liveMatch['kills1'] ?>

            </div>


            <div>

                <div class="stat-name">

                    Attack Kills

                </div>


                <div class="progress">

                    <div class="progress-inner"
                         style="width:<?= min($liveMatch['kills1'] * 2,100) ?>%;">

                    </div>

                </div>

            </div>


            <div class="value">

                <?= $liveMatch['kills2'] ?>

            </div>

        </div>



        <!-- BLOCKS -->

        <div class="stat-row">

            <div class="value">

                <?= $liveMatch['blocks1'] ?>

            </div>


            <div>

                <div class="stat-name">

                    Blocks

                </div>


                <div class="progress">

                    <div class="progress-inner"
                         style="width:<?= min($liveMatch['blocks1'] * 10,100) ?>%;">

                    </div>

                </div>

            </div>


            <div class="value">

                <?= $liveMatch['blocks2'] ?>

            </div>

        </div>



        <!-- ACES -->

        <div class="stat-row">

            <div class="value">

                <?= $liveMatch['aces1'] ?>

            </div>


            <div>

                <div class="stat-name">

                    Service Aces

                </div>


                <div class="progress">

                    <div class="progress-inner"
                         style="width:<?= min($liveMatch['aces1'] * 12,100) ?>%;">

                    </div>

                </div>

            </div>


            <div class="value">

                <?= $liveMatch['aces2'] ?>

            </div>

        </div>



        <!-- ERRORS -->

        <div class="stat-row">

            <div class="value">

                <?= $liveMatch['errors1'] ?>

            </div>


            <div>

                <div class="stat-name">

                    Errors

                </div>


                <div class="progress">

                    <div class="progress-inner"
                         style="width:<?= min($liveMatch['errors1'] * 8,100) ?>%;">

                    </div>

                </div>

            </div>


            <div class="value">

                <?= $liveMatch['errors2'] ?>

            </div>

        </div>



        <!-- TIMEOUTS -->

        <div class="stat-row">

            <div class="value">

                <?= $liveMatch['timeouts1'] ?>

            </div>


            <div class="stat-name">

                Timeouts Used

            </div>


            <div class="value">

                <?= $liveMatch['timeouts2'] ?>

            </div>

        </div>


    </div>

</div>



<!-- =========================================================
     QUICK STATS
========================================================= -->

<div class="section-title">

    <h2>

        <i class="fa-solid fa-chart-simple"></i>

        Match Overview

    </h2>

</div>



<div class="three-grid">


    <div class="quick-stat">

        <i class="fa-solid fa-volleyball"></i>


        <h3>

            <?= $liveMatch['sets1'] ?>

            -

            <?= $liveMatch['sets2'] ?>

        </h3>


        <p>

            Current Set Score

        </p>

    </div>



    <div class="quick-stat">

        <i class="fa-solid fa-layer-group"></i>


        <h3>

            <?= htmlspecialchars($liveMatch['currentSet']) ?>

        </h3>


        <p>

            Current Set

        </p>

    </div>



    <div class="quick-stat">

        <i class="fa-solid fa-bolt"></i>


        <h3>

            <?= $liveMatch['aces1'] + $liveMatch['aces2'] ?>

        </h3>


        <p>

            Total Aces

        </p>

    </div>


</div>



<!-- =========================================================
     UPCOMING + RESULTS
========================================================= -->

<div class="section-title">

    <h2>

        <i class="fa-solid fa-calendar-days"></i>

        Matches

    </h2>

</div>



<div class="two-grid">


    <!-- UPCOMING -->

    <div class="box">


        <div class="box-header">

            <h3>

                Upcoming Fixtures

            </h3>


            <i class="fa-solid fa-calendar-plus"></i>

        </div>


        <div class="box-body">


            <?php foreach ($upcomingMatches as $match): ?>


                <div class="fixture">


                    <div class="fixture-date">

                        <strong>

                            <?= htmlspecialchars($match['date']) ?>

                        </strong>


                        <span>

                            <?= htmlspecialchars($match['time']) ?>

                        </span>

                    </div>



                    <div class="fixture-teams">

                        <strong>

                            <?= htmlspecialchars($match['team1']) ?>

                        </strong>


                        <span class="vs">

                            VS

                        </span>


                        <strong>

                            <?= htmlspecialchars($match['team2']) ?>

                        </strong>


                        <span>

                            <?= htmlspecialchars($match['venue']) ?>

                        </span>

                    </div>


                </div>


            <?php endforeach; ?>


        </div>

    </div>



    <!-- RESULTS -->

    <div class="box">


        <div class="box-header">

            <h3>

                Recent Results

            </h3>


            <i class="fa-solid fa-trophy"></i>

        </div>


        <div class="box-body">


            <?php foreach ($results as $result): ?>


                <div class="result">


                    <div class="result-header">


                        <div>

                            <strong style="font-size:11px;">

                                <?= htmlspecialchars($result['team1']) ?>

                            </strong>


                            <br>


                            <strong style="font-size:11px;">

                                <?= htmlspecialchars($result['team2']) ?>

                            </strong>


                        </div>


                        <div class="result-score">

                            <?= $result['sets1'] ?>

                            -

                            <?= $result['sets2'] ?>

                        </div>


                        <div class="result-status">

                            <?= htmlspecialchars($result['result']) ?>

                        </div>


                    </div>


                    <div class="result-date">

                        <?= htmlspecialchars($result['date']) ?>

                    </div>


                    <div class="result-details">

                        <?= htmlspecialchars($result['score']) ?>

                    </div>


                </div>


            <?php endforeach; ?>


        </div>

    </div>


</div>



<!-- =========================================================
     STANDINGS
========================================================= -->

<div class="section-title">

    <h2>

        <i class="fa-solid fa-ranking-star"></i>

        League Standings

    </h2>

</div>



<div class="box">


    <div class="table-wrapper">


        <table>


            <thead>

                <tr>

                    <th>Pos</th>

                    <th>Team</th>

                    <th>P</th>

                    <th>W</th>

                    <th>L</th>

                    <th>SW</th>

                    <th>SL</th>

                    <th>PTS</th>

                </tr>

            </thead>


            <tbody>


                <?php foreach ($standings as $row): ?>


                    <tr>


                        <td class="position">

                            <?= $row['pos'] ?>

                        </td>


                        <td class="team-name">

                            <?= htmlspecialchars($row['team']) ?>

                        </td>


                        <td>

                            <?= $row['p'] ?>

                        </td>


                        <td>

                            <?= $row['w'] ?>

                        </td>


                        <td>

                            <?= $row['l'] ?>

                        </td>


                        <td>

                            <?= $row['setsWon'] ?>

                        </td>


                        <td>

                            <?= $row['setsLost'] ?>

                        </td>


                        <td class="points">

                            <?= $row['pts'] ?>

                        </td>


                    </tr>


                <?php endforeach; ?>


            </tbody>


        </table>

    </div>

</div>



<!-- =========================================================
     PLAYER STATISTICS
========================================================= -->

<div class="section-title">

    <h2>

        <i class="fa-solid fa-user-group"></i>

        Player Statistics

    </h2>

</div>



<div class="three-grid">


    <!-- ATTACKERS -->

    <div class="box">


        <div class="box-header">

            <h3>

                Top Attackers

            </h3>


            <i class="fa-solid fa-bolt"></i>

        </div>


        <div class="box-body">


            <?php foreach ($topAttackers as $player): ?>


                <div class="player">


                    <div class="player-icon">

                        <i class="fa-solid fa-user"></i>

                    </div>


                    <div class="player-info">

                        <strong>

                            <?= htmlspecialchars($player['player']) ?>

                        </strong>


                        <span>

                            <?= htmlspecialchars($player['team']) ?>

                        </span>

                    </div>


                    <div class="player-number">

                        <?= $player['kills'] ?>


                        <small>

                            KILLS

                        </small>

                    </div>


                </div>


            <?php endforeach; ?>


        </div>

    </div>



    <!-- SERVERS -->

    <div class="box">


        <div class="box-header">

            <h3>

                Top Servers

            </h3>


            <i class="fa-solid fa-bullseye"></i>

        </div>


        <div class="box-body">


            <?php foreach ($topServers as $player): ?>


                <div class="player">


                    <div class="player-icon">

                        <i class="fa-solid fa-user"></i>

                    </div>


                    <div class="player-info">

                        <strong>

                            <?= htmlspecialchars($player['player']) ?>

                        </strong>


                        <span>

                            <?= htmlspecialchars($player['team']) ?>

                        </span>

                    </div>


                    <div class="player-number">

                        <?= $player['aces'] ?>


                        <small>

                            ACES

                        </small>

                    </div>


                </div>


            <?php endforeach; ?>


        </div>

    </div>



    <!-- BLOCKERS -->

    <div class="box">


        <div class="box-header">

            <h3>

                Top Blockers

            </h3>


            <i class="fa-solid fa-shield-halved"></i>

        </div>


        <div class="box-body">


            <?php foreach ($topBlockers as $player): ?>


                <div class="player">


                    <div class="player-icon">

                        <i class="fa-solid fa-user"></i>

                    </div>


                    <div class="player-info">

                        <strong>

                            <?= htmlspecialchars($player['player']) ?>

                        </strong>


                        <span>

                            <?= htmlspecialchars($player['team']) ?>

                        </span>

                    </div>


                    <div class="player-number">

                        <?= $player['blocks'] ?>


                        <small>

                            BLOCKS

                        </small>

                    </div>


                </div>


            <?php endforeach; ?>


        </div>

    </div>


</div>



<!-- =========================================================
     TEAMS
========================================================= -->

<div class="section-title">

    <h2>

        <i class="fa-solid fa-people-group"></i>

        Volleyball Teams

    </h2>

</div>



<div class="three-grid">


    <?php foreach ($teams as $team): ?>


        <div class="box">


            <div class="team-card">


                <div class="team-card-icon">

                    <i class="fa-solid fa-volleyball"></i>

                </div>


                <h3>

                    <?= htmlspecialchars($team['name']) ?>

                </h3>


                <p>

                    <i class="fa-solid fa-location-dot"></i>

                    <?= htmlspecialchars($team['city']) ?>

                </p>


                <div class="team-details">

                    <span>

                        Coach:

                        <?= htmlspecialchars($team['coach']) ?>

                    </span>


                    <span>

                        <?= $team['players'] ?>

                        Players

                    </span>

                </div>


            </div>

        </div>


    <?php endforeach; ?>


</div>


</main>



<!-- =========================================================
     FOOTER
========================================================= -->

<footer class="footer">

    <div class="container">

        © <?= date('Y') ?> SPORTZONE

        • LOCAL SPORTS

        • Volleyball

    </div>

</footer>


</body>

</html>

