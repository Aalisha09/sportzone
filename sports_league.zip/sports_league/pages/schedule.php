<?php
$page_title = "Schedule | SportZone";
require_once '../includes/header.php';
?>

<style>

/* =====================================================
   SCHEDULE PAGE
===================================================== */

.schedule-page {
    background: #080c11;
    color: #ffffff;
    min-height: 100vh;
}


/* =====================================================
   PAGE HERO
===================================================== */

.page-hero {

    padding: 75px 0 65px;

    background:
        radial-gradient(
            circle at 80% 30%,
            rgba(255,91,37,0.18),
            transparent 35%
        ),
        #080c11;

    border-bottom: 1px solid #202932;
}


.page-hero .container {
    width: min(1200px, 92%);
    margin: auto;
}


.page-label {

    color: #ff5b25;

    font-size: 12px;

    font-weight: 800;

    letter-spacing: 2px;

    margin-bottom: 18px;
}


.page-label i {
    margin-right: 8px;
}


.page-hero h1 {

    margin: 0 0 18px;

    font-size: clamp(45px, 6vw, 68px);

    line-height: 1;

    font-weight: 900;

    letter-spacing: -2px;
}


.page-hero h1 span {
    color: #ff5b25;
}


.page-hero p {

    max-width: 700px;

    color: #8995a1;

    font-size: 14px;

    line-height: 1.8;

    margin: 0;
}


/* =====================================================
   FILTER SECTION
===================================================== */

.filter-section {

    padding: 30px 0 10px;

    background: #080c11;
}


.filter-section .container {

    width: min(1200px, 92%);

    margin: auto;
}


.filters {

    display: flex;

    align-items: center;

    gap: 10px;

    flex-wrap: wrap;
}


.filter-btn {

    border: 1px solid #2a3540;

    background: #111820;

    color: #9ca7b2;

    padding: 11px 18px;

    border-radius: 8px;

    font-family: inherit;

    font-size: 11px;

    font-weight: 700;

    cursor: pointer;

    transition: 0.3s;
}


.filter-btn:hover,
.filter-btn.active {

    background: #ff5b25;

    border-color: #ff5b25;

    color: #ffffff;

    transform: translateY(-2px);
}


/* =====================================================
   SCHEDULE SECTION
===================================================== */

.schedule-section {

    padding: 35px 0 90px;

    background: #080c11;
}


.schedule-section .container {

    width: min(1200px, 92%);

    margin: auto;
}


/* =====================================================
   DAY HEADER
===================================================== */

.day-header {

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 16px 20px;

    margin-top: 25px;

    margin-bottom: 12px;

    background: #111820;

    border: 1px solid #29343f;

    border-left: 4px solid #ff5b25;

    border-radius: 10px;

    transition: 0.3s;
}


.day-header:hover {

    border-color: #ff5b25;
}


.day-header h2 {

    margin: 0;

    font-size: 15px;

    font-weight: 800;
}


.day-header h2 i {

    color: #ff5b25;

    margin-right: 8px;
}


.day-header span {

    color: #707c88;

    font-size: 10px;

    font-weight: 600;
}


/* =====================================================
   SCHEDULE CARD
===================================================== */

.schedule-card {

    display: grid;

    grid-template-columns: 105px 1fr 160px;

    align-items: center;

    gap: 25px;

    padding: 21px;

    margin-bottom: 12px;

    background: #111820;

    border: 1px solid #29343f;

    border-radius: 12px;

    transition: 0.35s ease;
}


.schedule-card:hover {

    border-color: #ff5b25;

    transform: translateY(-4px);

    box-shadow:
        0 18px 40px rgba(0,0,0,0.35);
}


/* =====================================================
   TIME
===================================================== */

.match-time {

    text-align: center;

    border-right: 1px solid #29343f;

    padding-right: 20px;
}


.match-time strong {

    display: block;

    color: #ffffff;

    font-size: 18px;

    font-weight: 900;
}


.match-time span {

    display: block;

    color: #ff5b25;

    font-size: 9px;

    font-weight: 800;

    margin-top: 5px;

    letter-spacing: 1px;
}


/* =====================================================
   MATCH INFO
===================================================== */

.match-info {

    display: flex;

    align-items: center;

    gap: 18px;
}


.sport-icon {

    width: 52px;

    height: 52px;

    flex-shrink: 0;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 12px;

    background: rgba(255,91,37,0.11);

    color: #ff5b25;

    font-size: 21px;

    transition: 0.3s;
}


.schedule-card:hover .sport-icon {

    transform: scale(1.08);

    background: rgba(255,91,37,0.17);
}


.match-info h3 {

    margin: 0 0 7px;

    font-size: 14px;

    font-weight: 800;
}


.match-info p {

    margin: 7px 0 0;

    color: #707c88;

    font-size: 9px;
}


.match-info p i {

    color: #ff5b25;

    margin-right: 5px;
}


/* =====================================================
   BADGE
===================================================== */

.badge {

    display: inline-block;

    padding: 4px 8px;

    margin-bottom: 5px;

    background: rgba(255,91,37,0.10);

    color: #ff5b25;

    border-radius: 4px;

    font-size: 8px;

    font-weight: 800;

    letter-spacing: 0.5px;
}


/* =====================================================
   TEAMS
===================================================== */

.teams {

    display: flex;

    align-items: center;

    gap: 10px;
}


.team-name {

    color: #b7c0c9;

    font-size: 10px;

    font-weight: 700;
}


.vs {

    color: #ff5b25;

    font-size: 9px;

    font-weight: 900;
}


/* =====================================================
   DETAILS BUTTON
===================================================== */

.details-btn {

    display: inline-flex;

    justify-content: center;

    align-items: center;

    width: 100%;

    gap: 7px;

    padding: 11px 15px;

    border: 1px solid #303b46;

    background: #151d25;

    color: #aab4be;

    border-radius: 7px;

    font-size: 10px;

    font-weight: 700;

    transition: 0.3s;
}


.details-btn:hover {

    background: #ff5b25;

    border-color: #ff5b25;

    color: #ffffff;

    transform: translateY(-2px);
}


/* =====================================================
   UPCOMING LABEL
===================================================== */

.upcoming-label {

    margin-top: 45px;

    margin-bottom: 15px;

    color: #ff5b25;

    font-size: 11px;

    font-weight: 800;

    letter-spacing: 2px;
}


/* =====================================================
   RESPONSIVE
===================================================== */

@media (max-width: 1000px) {

    .schedule-card {

        grid-template-columns: 90px 1fr 140px;

        gap: 15px;

    }

}


@media (max-width: 700px) {

    .page-hero {

        padding: 60px 0 50px;

    }


    .page-hero h1 {

        font-size: 45px;

    }


    .schedule-card {

        grid-template-columns: 1fr;

        gap: 18px;

        text-align: center;

    }


    .match-time {

        border-right: none;

        border-bottom: 1px solid #29343f;

        padding-right: 0;

        padding-bottom: 14px;

    }


    .match-info {

        justify-content: center;

        text-align: center;

    }


    .teams {

        justify-content: center;

    }


    .match-info p {

        margin-top: 10px;

    }


    .details-btn {

        width: 100%;

    }


    .day-header {

        flex-direction: column;

        align-items: flex-start;

        gap: 7px;

    }

}


@media (max-width: 450px) {

    .filters {

        gap: 7px;

    }


    .filter-btn {

        padding: 9px 12px;

        font-size: 10px;

    }


    .page-hero h1 {

        font-size: 38px;

    }


    .schedule-card {

        padding: 18px;

    }

}

</style>


<div class="schedule-page">


<!-- =====================================================
     PAGE HERO
===================================================== -->

<section class="page-hero">

    <div class="container">

        <div class="page-label">

            <i class="fa-solid fa-calendar-days"></i>

            MATCH CENTER

        </div>


        <h1>

            MATCH

            <span>SCHEDULE</span>

        </h1>


        <p>

            Explore upcoming local league matches,
            tournament fixtures and game timings
            all in one place.

        </p>

    </div>

</section>



<!-- =====================================================
     FILTERS
===================================================== -->

<section class="filter-section">

    <div class="container">

        <div class="filters">

            <button class="filter-btn active">
                All Matches
            </button>

            <button class="filter-btn" onclick="window.location.href='football.php';">
                ⚽ Football
            </button>

  <button class="filter-btn" onclick="window.location.href='cricket.php';">
    🏏 Cricket
</button>

            <button class="filter-btn"onclick="window.location.href='basketball.php';">
                🏀 Basketball
            </button>

            <button class="filter-btn" onclick="window.location.href='volleyball.php';">
                🏐 Volleyball
            </button>

        </div>

    </div>

</section>



<!-- =====================================================
     SCHEDULE
===================================================== -->

<section class="schedule-section">

    <div class="container">


        <!-- =================================================
             TODAY
        ================================================= -->

        <div class="day-header">

            <h2>

                <i class="fa-solid fa-calendar-day"></i>

                TODAY

            </h2>

            <span>
                Sunday • 23 August 2026
            </span>

        </div>



        <!-- MATCH 1 -->

        <div class="schedule-card">


            <div class="match-time">

                <strong>
                    05:00 PM
                </strong>

                <span>
                    TODAY
                </span>

            </div>



            <div class="match-info">

                <div class="sport-icon">

                    <i class="fa-solid fa-futbol"></i>

                </div>


                <div>

                    <div class="badge">
                        FOOTBALL
                    </div>

                    <h3>
                        City Football League
                    </h3>


                    <div class="teams">

                        <span class="team-name">
                            Eagles FC
                        </span>

                        <span class="vs">
                            VS
                        </span>

                        <span class="team-name">
                            Tigers United
                        </span>

                    </div>


                    <p>

                        <i class="fa-solid fa-location-dot"></i>

                        Sardar Patel Stadium

                    </p>

                </div>

            </div>



            <div>

                <a
                    href="live-scores.php"
                    class="details-btn"
                >

                    <i class="fa-solid fa-bolt"></i>

                    Match Details

                </a>

            </div>


        </div>



        <!-- MATCH 2 -->

        <div class="schedule-card">


            <div class="match-time">

                <strong>
                    06:30 PM
                </strong>

                <span>
                    TODAY
                </span>

            </div>



            <div class="match-info">

                <div class="sport-icon">

                    <i class="fa-solid fa-basketball"></i>

                </div>


                <div>

                    <div class="badge">
                        BASKETBALL
                    </div>

                    <h3>
                        Ahmedabad City League
                    </h3>


                    <div class="teams">

                        <span class="team-name">
                            Warriors
                        </span>

                        <span class="vs">
                            VS
                        </span>

                        <span class="team-name">
                            Panthers
                        </span>

                    </div>


                    <p>

                        <i class="fa-solid fa-location-dot"></i>

                        City Sports Arena

                    </p>

                </div>

            </div>



            <div>

                <a
                    href="live-scores.php"
                    class="details-btn"
                >

                    <i class="fa-solid fa-bolt"></i>

                    Match Details

                </a>

            </div>


        </div>



        <!-- =================================================
             TOMORROW
        ================================================= -->

        <div class="day-header">

            <h2>

                <i class="fa-solid fa-calendar-day"></i>

                TOMORROW

            </h2>

            <span>
                Monday • 24 August 2026
            </span>

        </div>



        <!-- MATCH 3 -->

        <div class="schedule-card">


            <div class="match-time">

                <strong>
                    04:00 PM
                </strong>

                <span>
                    TOMORROW
                </span>

            </div>



            <div class="match-info">

                <div class="sport-icon">

                    <i class="fa-solid fa-baseball-bat-ball"></i>

                </div>


                <div>

                    <div class="badge">
                        CRICKET
                    </div>

                    <h3>
                        Gujarat T20 League
                    </h3>


                    <div class="teams">

                        <span class="team-name">
                            Ahmedabad Kings
                        </span>

                        <span class="vs">
                            VS
                        </span>

                        <span class="team-name">
                            Gujarat Warriors
                        </span>

                    </div>


                    <p>

                        <i class="fa-solid fa-location-dot"></i>

                        Narendra Modi Sports Ground

                    </p>

                </div>

            </div>



            <div>

                <a
                    href="live-scores.php"
                    class="details-btn"
                >

                    <i class="fa-solid fa-circle-info"></i>

                    Match Details

                </a>

            </div>


        </div>



        <!-- MATCH 4 -->

        <div class="schedule-card">


            <div class="match-time">

                <strong>
                    07:00 PM
                </strong>

                <span>
                    TOMORROW
                </span>

            </div>



            <div class="match-info">

                <div class="sport-icon">

                    <i class="fa-solid fa-volleyball"></i>

                </div>


                <div>

                    <div class="badge">
                        VOLLEYBALL
                    </div>

                    <h3>
                        Gujarat Volleyball Cup
                    </h3>


                    <div class="teams">

                        <span class="team-name">
                            Smashers
                        </span>

                        <span class="vs">
                            VS
                        </span>

                        <span class="team-name">
                            Spikers
                        </span>

                    </div>


                    <p>

                        <i class="fa-solid fa-location-dot"></i>

                        Indoor Sports Complex

                    </p>

                </div>

            </div>



            <div>

                <a
                    href="live-scores.php"
                    class="details-btn"
                >

                    <i class="fa-solid fa-circle-info"></i>

                    Match Details

                </a>

            </div>


        </div>



        <!-- =================================================
             UPCOMING
        ================================================= -->

        <div class="day-header">

            <h2>

                <i class="fa-solid fa-calendar-days"></i>

                WEDNESDAY • 26 AUGUST

            </h2>

            <span>
                Upcoming Matches
            </span>

        </div>



        <!-- MATCH 5 -->

        <div class="schedule-card">


            <div class="match-time">

                <strong>
                    05:30 PM
                </strong>

                <span>
                    WEDNESDAY
                </span>

            </div>



            <div class="match-info">

                <div class="sport-icon">

                    <i class="fa-solid fa-futbol"></i>

                </div>


                <div>

                    <div class="badge">
                        FOOTBALL
                    </div>

                    <h3>
                        Local Championship
                    </h3>


                    <div class="teams">

                        <span class="team-name">
                            Stars FC
                        </span>

                        <span class="vs">
                            VS
                        </span>

                        <span class="team-name">
                            Royal FC
                        </span>

                    </div>


                    <p>

                        <i class="fa-solid fa-location-dot"></i>

                        Ahmedabad Sports Ground

                    </p>

                </div>

            </div>



            <div>

                <a
                    href="live-scores.php"
                    class="details-btn"
                >

                    <i class="fa-solid fa-circle-info"></i>

                    Match Details

                </a>

            </div>


        </div>



        <!-- MATCH 6 -->

        <div class="schedule-card">


            <div class="match-time">

                <strong>
                    08:00 PM
                </strong>

                <span>
                    WEDNESDAY
                </span>

            </div>



            <div class="match-info">

                <div class="sport-icon">

                    <i class="fa-solid fa-basketball"></i>

                </div>


                <div>

                    <div class="badge">
                        BASKETBALL
                    </div>

                    <h3>
                        City Basketball Championship
                    </h3>


                    <div class="teams">

                        <span class="team-name">
                            Falcons
                        </span>

                        <span class="vs">
                            VS
                        </span>

                        <span class="team-name">
                            Bulls
                        </span>

                    </div>


                    <p>

                        <i class="fa-solid fa-location-dot"></i>

                        City Basketball Court

                    </p>

                </div>

            </div>



            <div>

                <a
                    href="live-scores.php"
                    class="details-btn"
                >

                    <i class="fa-solid fa-circle-info"></i>

                    Match Details

                </a>

            </div>


        </div>


    </div>

</section>


</div>


<?php
require_once '../includes/footer.php';
?>