<?php
$page_title = "Players | SportZone";

require_once '../includes/header.php';
require_once '../includes/db.php';

/* =====================================================
   FETCH PLAYERS
===================================================== */

$players = [];

$query = "SELECT * FROM players ORDER BY id DESC";
$result = mysqli_query($conn, $query);

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $players[] = $row;
    }
}
?>

<style>

/* =====================================================
   PLAYERS PAGE
===================================================== */

.players-page {
    background: #080c11;
    color: #ffffff;
    min-height: 100vh;
}


/* =====================================================
   PAGE HERO
===================================================== */

.page-hero {
    padding: 75px 0 65px;

    background:
        radial-gradient(
            circle at 80% 30%,
            rgba(255,91,37,0.18),
            transparent 35%
        ),
        #080c11;

    border-bottom: 1px solid #202932;
}

.page-hero .container {
    width: min(1200px, 92%);
    margin: auto;
}

.page-label {
    color: #ff5b25;
    font-size: 12px;
    font-weight: 800;
    letter-spacing: 2px;
    margin-bottom: 18px;
}

.page-label i {
    margin-right: 8px;
}

.page-hero h1 {
    margin: 0 0 18px;
    font-size: clamp(45px, 6vw, 68px);
    line-height: 1;
    font-weight: 900;
    letter-spacing: -2px;
}

.page-hero h1 span {
    color: #ff5b25;
}

.page-hero p {
    max-width: 700px;
    color: #8995a1;
    font-size: 14px;
    line-height: 1.8;
    margin: 0;
}


/* =====================================================
   PLAYER SECTION
===================================================== */

.players-section {
    padding: 45px 0 90px;
    background: #080c11;
}

.players-section .container {
    width: min(1200px, 92%);
    margin: auto;
}


/* =====================================================
   TOP BAR
===================================================== */

.players-topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    margin-bottom: 30px;
    flex-wrap: wrap;
}

.players-count {
    color: #8995a1;
    font-size: 12px;
}

.players-count strong {
    color: #ffffff;
}


/* =====================================================
   SEARCH
===================================================== */

.search-box {
    position: relative;
    width: 300px;
}

.search-box input {
    width: 100%;
    box-sizing: border-box;

    padding: 13px 42px 13px 16px;

    background: #111820;
    border: 1px solid #29343f;
    border-radius: 8px;

    color: #ffffff;

    outline: none;

    font-family: inherit;
    font-size: 11px;

    transition: 0.3s;
}

.search-box input::placeholder {
    color: #707c88;
}

.search-box input:focus {
    border-color: #ff5b25;
    box-shadow: 0 0 0 3px rgba(255,91,37,0.08);
}

.search-box i {
    position: absolute;

    right: 15px;
    top: 50%;

    transform: translateY(-50%);

    color: #707c88;

    font-size: 13px;
}


/* =====================================================
   PLAYER GRID
===================================================== */

.players-grid {
    display: grid;

    grid-template-columns:
        repeat(3, minmax(0, 1fr));

    gap: 20px;
}


/* =====================================================
   PLAYER CARD
===================================================== */

.player-card {
    position: relative;

    overflow: hidden;

    background: #111820;

    border: 1px solid #29343f;

    border-radius: 14px;

    transition: 0.35s ease;
}

.player-card:hover {
    border-color: #ff5b25;

    transform: translateY(-6px);

    box-shadow:
        0 20px 45px rgba(0,0,0,0.35);
}


/* =====================================================
   PLAYER IMAGE
===================================================== */

.player-image {
    height: 245px;

    position: relative;

    display: flex;
    align-items: center;
    justify-content: center;

    background:
        radial-gradient(
            circle at center,
            rgba(255,91,37,0.16),
            transparent 60%
        ),
        #0d141b;

    overflow: hidden;
}

.player-image img {
    width: 100%;
    height: 100%;

    object-fit: cover;

    transition: 0.45s ease;
}

.player-card:hover .player-image img {
    transform: scale(1.06);
}


/* =====================================================
   DEFAULT PLAYER ICON
===================================================== */

.player-placeholder {
    width: 95px;
    height: 95px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 50%;

    background: rgba(255,91,37,0.12);

    border: 2px solid rgba(255,91,37,0.3);

    color: #ff5b25;

    font-size: 38px;
}


/* =====================================================
   SPORT BADGE
===================================================== */

.sport-badge {
    position: absolute;

    top: 14px;
    left: 14px;

    padding: 6px 10px;

    background: rgba(8,12,17,0.88);

    border: 1px solid #29343f;

    border-radius: 5px;

    color: #ff5b25;

    font-size: 8px;
    font-weight: 800;

    letter-spacing: 1px;

    z-index: 2;
}


/* =====================================================
   PLAYER NUMBER
===================================================== */

.player-number {
    position: absolute;

    right: 15px;
    bottom: 14px;

    width: 38px;
    height: 38px;

    display: flex;
    align-items: center;
    justify-content: center;

    background: #ff5b25;

    color: #ffffff;

    border-radius: 8px;

    font-size: 13px;
    font-weight: 900;

    z-index: 2;
}


/* =====================================================
   PLAYER INFO
===================================================== */

.player-info {
    padding: 20px;
}

.player-info h2 {
    margin: 0 0 6px;

    font-size: 18px;
    font-weight: 900;
}

.player-role {
    color: #ff5b25;

    font-size: 9px;
    font-weight: 800;

    letter-spacing: 1px;

    margin-bottom: 17px;
}


/* =====================================================
   PLAYER DETAILS
===================================================== */

.player-details {
    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 8px;
}

.detail-item {
    padding: 11px;

    background: #0d141b;

    border: 1px solid #222d37;

    border-radius: 7px;
}

.detail-item span {
    display: block;

    color: #65717d;

    font-size: 8px;
    font-weight: 700;

    margin-bottom: 5px;

    text-transform: uppercase;
}

.detail-item strong {
    color: #c4ccd4;

    font-size: 10px;
}


/* =====================================================
   NO PLAYERS
===================================================== */

.no-players {
    padding: 70px 20px;

    text-align: center;

    background: #111820;

    border: 1px solid #29343f;

    border-radius: 12px;
}

.no-players i {
    color: #ff5b25;

    font-size: 40px;

    margin-bottom: 15px;
}

.no-players h3 {
    margin: 0 0 8px;

    font-size: 18px;
}

.no-players p {
    margin: 0;

    color: #707c88;

    font-size: 11px;
}


/* =====================================================
   HIDDEN SEARCH
===================================================== */

.player-card.hidden {
    display: none;
}


/* =====================================================
   RESPONSIVE
===================================================== */

@media (max-width: 1000px) {

    .players-grid {
        grid-template-columns:
            repeat(2, minmax(0, 1fr));
    }

}


@media (max-width: 700px) {

    .page-hero {
        padding: 60px 0 50px;
    }

    .page-hero h1 {
        font-size: 45px;
    }

    .players-topbar {
        align-items: stretch;
    }

    .search-box {
        width: 100%;
    }

    .players-grid {
        grid-template-columns: 1fr;
    }

}


@media (max-width: 450px) {

    .page-hero h1 {
        font-size: 38px;
    }

    .player-image {
        height: 220px;
    }

    .player-info {
        padding: 17px;
    }

}

</style>

<div class="players-page">

<!-- =====================================================
     PAGE HERO
===================================================== -->

<section class="page-hero">


<div class="container">

    <div class="page-label">

        <i class="fa-solid fa-users"></i>

        SPORTZONE PLAYERS

    </div>


    <h1>

        OUR

        <span>PLAYERS</span>

    </h1>


    <p>

        Explore player profiles, teams, sports and
        player information from local leagues and
        tournaments.

    </p>

</div>


</section>

<!-- =====================================================
     PLAYERS SECTION
===================================================== -->

<section class="players-section">


<div class="container">


    <div class="players-topbar">

        <div class="players-count">

            <i class="fa-solid fa-users"></i>

            Total Players:

            <strong>
                <?php echo count($players); ?>
            </strong>

        </div>


        <div class="search-box">

            <input
                type="text"
                id="playerSearch"
                placeholder="Search player, team or sport..."
                autocomplete="off"
            >

            <i class="fa-solid fa-magnifying-glass"></i>

        </div>

    </div>



    <?php if (count($players) > 0): ?>

        <div class="players-grid" id="playersGrid">


            <?php foreach ($players as $player): ?>

                <?php

                /*
                 * These column names are expected:
                 * id
                 * name
                 * sport
                 * team
                 * position
                 * number
                 * image
                 */

                $playerName =
                    isset($player['name'])
                    ? $player['name']
                    : 'Unknown Player';

                $sport =
                    isset($player['sport'])
                    ? $player['sport']
                    : 'Sports';

                $team =
                    isset($player['team'])
                    ? $player['team']
                    : 'No Team';

                $position =
                    isset($player['position'])
                    ? $player['position']
                    : 'Player';

                $number =
                    isset($player['number'])
                    ? $player['number']
                    : '--';

                $image =
                    isset($player['image'])
                    ? $player['image']
                    : '';

                ?>


                <div
                    class="player-card"
                    data-search="<?php
                        echo htmlspecialchars(
                            strtolower(
                                $playerName . ' ' .
                                $sport . ' ' .
                                $team . ' ' .
                                $position
                            )
                        );
                    ?>"
                >


                    <!-- PLAYER IMAGE -->

                    <div class="player-image">


                        <div class="sport-badge">

                            <?php
                            echo strtoupper(
                                htmlspecialchars($sport)
                            );
                            ?>

                        </div>


                        <?php if (!empty($image)): ?>

                            <img
                                src="../<?php echo htmlspecialchars($image); ?>"
                                alt="<?php echo htmlspecialchars($playerName); ?>"
                            >

                        <?php else: ?>

                            <div class="player-placeholder">

                                <i class="fa-solid fa-user"></i>

                            </div>

                        <?php endif; ?>


                        <div class="player-number">

                            <?php
                            echo htmlspecialchars($number);
                            ?>

                        </div>


                    </div>



                    <!-- PLAYER INFORMATION -->

                    <div class="player-info">


                        <h2>

                            <?php
                            echo htmlspecialchars($playerName);
                            ?>

                        </h2>


                        <div class="player-role">

                            <?php
                            echo strtoupper(
                                htmlspecialchars($position)
                            );
                            ?>

                        </div>


                        <div class="player-details">


                            <div class="detail-item">

                                <span>
                                    Team
                                </span>

                                <strong>

                                    <?php
                                    echo htmlspecialchars($team);
                                    ?>

                                </strong>

                            </div>


                            <div class="detail-item">

                                <span>
                                    Sport
                                </span>

                                <strong>

                                    <?php
                                    echo htmlspecialchars($sport);
                                    ?>

                                </strong>

                            </div>


                        </div>


                    </div>


                </div>


            <?php endforeach; ?>


        </div>


        <!-- NO SEARCH RESULT -->

        <div
            id="noSearchResult"
            class="no-players"
            style="display:none;"
        >

            <i class="fa-solid fa-magnifying-glass"></i>

            <h3>
                No Players Found
            </h3>

            <p>
                Try searching with another player name,
                team or sport.
            </p>

        </div>


    <?php else: ?>


        <div class="no-players">

            <i class="fa-solid fa-users-slash"></i>

            <h3>
                No Players Available
            </h3>

            <p>
                Players will appear here once they are
                added from the admin panel.
            </p>

        </div>


    <?php endif; ?>


</div>


</section>

</div>

<script>

/* =====================================================
   PLAYER SEARCH
===================================================== */

const searchInput =
    document.getElementById("playerSearch");

const playerCards =
    document.querySelectorAll(".player-card");

const noSearchResult =
    document.getElementById("noSearchResult");


if (searchInput) {

    searchInput.addEventListener("input", function () {

        const searchValue =
            this.value.toLowerCase().trim();

        let visiblePlayers = 0;


        playerCards.forEach(function (card) {

            const searchData =
                card.getAttribute("data-search");


            if (searchData.includes(searchValue)) {

                card.classList.remove("hidden");

                visiblePlayers++;

            } else {

                card.classList.add("hidden");

            }

        });


        if (noSearchResult) {

            if (visiblePlayers === 0 && searchValue !== "") {

                noSearchResult.style.display = "block";

            } else {

                noSearchResult.style.display = "none";

            }

        }

    });

}

</script>

<?php
require_once '../includes/footer.php';
?>
