<?php
require_once 'includes/header.php';
?>

<!-- =====================================================
     HERO SECTION
===================================================== -->

<section class="hero-section">


<div class="hero-overlay"></div>

<div class="hero-content">

    <!-- HERO TEXT -->

    <div class="hero-text">

        <span class="hero-small-title">
            <i class="fa-solid fa-trophy"></i>
            LOCAL SPORTS LEAGUE 2026
        </span>

        <h1>
            THE GAME
            <br>
            <span>STARTS HERE.</span>
        </h1>

        <p>
            Follow your favorite local teams, check live scores,
            explore upcoming matches and stay updated with every
            tournament.
        </p>

        <div class="hero-buttons">

            <a href="pages/live-scores.php"
               class="hero-btn primary-btn">

                <i class="fa-solid fa-bolt"></i>
                Live Scores

            </a>

            <a href="pages/schedule.php"
               class="hero-btn secondary-btn">

                <i class="fa-solid fa-calendar-days"></i>
                View Schedule

            </a>

        </div>

    </div>


    <!-- HERO SCORE CARD -->

    <div class="hero-match-card">

        <div class="match-card-top">

            <span class="live-label">

                <span class="live-dot"></span>
                LIVE

            </span>

            <span>SEMI FINAL</span>

        </div>

        <p class="match-title">
            CITY CHAMPIONSHIP
        </p>


        <div class="hero-teams">

            <div class="hero-team">

                <div class="team-badge blue-badge">
                    E
                </div>

                <h3>Eagles FC</h3>

                <strong>2</strong>

            </div>


            <div class="hero-vs">
                VS
            </div>


            <div class="hero-team">

                <div class="team-badge red-badge">
                    T
                </div>

                <h3>Tigers United</h3>

                <strong>1</strong>

            </div>

        </div>


        <div class="match-minute">

            <i class="fa-regular fa-clock"></i>
            67' MINUTE

        </div>


        <div class="score-events">

            <div>
                ⚽ Eagles FC — 23'
            </div>

            <div>
                ⚽ Eagles FC — 51'
            </div>

            <div>
                ⚽ Tigers United — 62'
            </div>

        </div>

    </div>

</div>

</section>

<!-- =====================================================
     STATISTICS
===================================================== -->

<section class="stats-section">

<div class="container">

    <div class="stats-grid">

        <div class="stat-box">

            <div class="stat-icon">
                <i class="fa-solid fa-users"></i>
            </div>

            <div>
                <h2>24+</h2>
                <p>Teams</p>
            </div>

        </div>


        <div class="stat-box">

            <div class="stat-icon">
                <i class="fa-solid fa-futbol"></i>
            </div>

            <div>
                <h2>68+</h2>
                <p>Matches</p>
            </div>

        </div>


        <div class="stat-box">

            <div class="stat-icon">
                <i class="fa-solid fa-trophy"></i>
            </div>

            <div>
                <h2>08</h2>
                <p>Tournaments</p>
            </div>

        </div>


        <div class="stat-box">

            <div class="stat-icon">
                <i class="fa-solid fa-location-dot"></i>
            </div>

            <div>
                <h2>12</h2>
                <p>Venues</p>
            </div>

        </div>

    </div>

</div>


</section>

<!-- =====================================================
     LIVE SCORES
===================================================== -->

<section class="home-section" id="live">

<div class="container">

    <div class="section-heading">

        <div>

            <span class="section-label">

                <span class="live-dot"></span>
                LIVE NOW

            </span>

            <h2>
                Live <span>Scores</span>
            </h2>

            <p>
                Follow matches happening right now.
            </p>

        </div>


        <a href="pages/live-scores.php"
           class="view-link">

            View All

            <i class="fa-solid fa-arrow-right"></i>

        </a>

    </div>


    <div class="score-grid">


        <!-- FOOTBALL SCORE -->

        <div class="score-card">

            <div class="score-card-header">

                <span>
                    ⚽ FOOTBALL
                </span>

                <span class="live-status">
                    LIVE
                </span>

            </div>


            <div class="score-teams">

                <div class="score-team">

                    <div class="small-team-logo">
                        E
                    </div>

                    <h3>Eagles FC</h3>

                </div>


                <div class="score-number">

                    <strong>2</strong>

                    <span>:</span>

                    <strong>1</strong>

                </div>


                <div class="score-team">

                    <div class="small-team-logo red">
                        T
                    </div>

                    <h3>Tigers United</h3>

                </div>

            </div>


            <div class="score-location">

                <i class="fa-solid fa-location-dot"></i>
                City Sports Arena

            </div>

        </div>


        <!-- BASKETBALL SCORE -->

        <div class="score-card">

            <div class="score-card-header">

                <span>
                    🏀 BASKETBALL
                </span>

                <span class="live-status">
                    LIVE
                </span>

            </div>


            <div class="score-teams">

                <div class="score-team">

                    <div class="small-team-logo">
                        W
                    </div>

                    <h3>Warriors</h3>

                </div>


                <div class="score-number">

                    <strong>78</strong>

                    <span>:</span>

                    <strong>72</strong>

                </div>


                <div class="score-team">

                    <div class="small-team-logo red">
                        P
                    </div>

                    <h3>Panthers</h3>

                </div>

            </div>


            <div class="score-location">

                <i class="fa-solid fa-location-dot"></i>
                Community Court

            </div>

        </div>


        <!-- CRICKET SCORE -->

        <div class="score-card">

            <div class="score-card-header">

                <span>
                    🏏 CRICKET
                </span>

                <span class="live-status">
                    LIVE
                </span>

            </div>


            <div class="score-teams">

                <div class="score-team">

                    <div class="small-team-logo">
                        AK
                    </div>

                    <h3>Ahmedabad Kings</h3>

                </div>


                <div class="score-number cricket-score">

                    <strong>45</strong>

                    <span>:</span>

                    <strong>6</strong>

                </div>


                <div class="score-team">

                    <div class="small-team-logo red">
                        GS
                    </div>

                    <h3>Gujarat Stars</h3>

                </div>

            </div>


            <div class="score-location">

                <i class="fa-solid fa-location-dot"></i>
                City Cricket Ground

            </div>

        </div>

    </div>

</div>


</section>

<!-- =====================================================
     SPORTS
===================================================== -->

<section class="sports-home-section"
         id="sports">

<div class="container">

    <div class="center-heading">

        <span class="section-label">
            OUR SPORTS
        </span>

        <h2>
            Choose Your <span>Game</span>
        </h2>

        <p>
            Discover tournaments and matches
            across different sports.
        </p>

    </div>


    <!-- SPORTS CARDS -->

    <div class="sports-home-grid">


        <!-- FOOTBALL -->

        <a href="pages/football.php"
           class="sport-home-card football-card">

            <div class="sport-card-icon">

                <i class="fa-solid fa-futbol"></i>

            </div>

            <div>

                <h3>Football</h3>

                <p>12 Teams • 32 Matches</p>

            </div>

            <i class="fa-solid fa-arrow-right sport-arrow"></i>

        </a>


        <!-- CRICKET -->

        <a href="pages/cricket.php"
           class="sport-home-card cricket-card">

            <div class="sport-card-icon">

                <i class="fa-solid fa-baseball-bat-ball"></i>

            </div>

            <div>

                <h3>Cricket</h3>

                <p>10 Teams • 20 Matches</p>

            </div>

            <i class="fa-solid fa-arrow-right sport-arrow"></i>

        </a>


        <!-- BASKETBALL -->

        <a href="pages/basketball.php"
           class="sport-home-card basketball-card">

            <div class="sport-card-icon">

                <i class="fa-solid fa-basketball"></i>

            </div>

            <div>

                <h3>Basketball</h3>

                <p>08 Teams • 16 Matches</p>

            </div>

            <i class="fa-solid fa-arrow-right sport-arrow"></i>

        </a>


        <!-- VOLLEYBALL -->

        <a href="pages/volleyball.php"
           class="sport-home-card volleyball-card">

            <div class="sport-card-icon">

                <i class="fa-solid fa-volleyball"></i>

            </div>

            <div>

                <h3>Volleyball</h3>

                <p>06 Teams • 12 Matches</p>

            </div>

            <i class="fa-solid fa-arrow-right sport-arrow"></i>

        </a>


    </div>

</div>


</section>

<!-- =====================================================
     UPCOMING MATCHES
===================================================== -->

<section class="home-section"
         id="schedule">


<div class="container">

    <div class="section-heading">

        <div>

            <span class="section-label">

                <i class="fa-solid fa-calendar-days"></i>
                UPCOMING

            </span>

            <h2>
                Match <span>Schedule</span>
            </h2>

            <p>
                Don't miss the next big game.
            </p>

        </div>


        <a href="pages/schedule.php"
           class="view-link">

            Full Schedule

            <i class="fa-solid fa-arrow-right"></i>

        </a>

    </div>


    <div class="schedule-home-list">


        <!-- MATCH 1 -->

        <div class="schedule-home-card">

            <div class="date-box">

                <strong>24</strong>
                <span>AUG</span>

            </div>


            <div class="schedule-match">

                <span>
                    ⚽ FOOTBALL
                </span>

                <h3>

                    Eagles FC
                    <b>VS</b>
                    Panthers FC

                </h3>

                <p>

                    <i class="fa-solid fa-location-dot"></i>
                    City Sports Arena

                </p>

            </div>


            <div class="schedule-time">

                <strong>06:30 PM</strong>
                <span>Sunday</span>

            </div>


            <a href="pages/schedule.php"
               class="details-btn">

                Details

            </a>

        </div>


        <!-- MATCH 2 -->

        <div class="schedule-home-card">

            <div class="date-box">

                <strong>25</strong>
                <span>AUG</span>

            </div>


            <div class="schedule-match">

                <span>
                    🏀 BASKETBALL
                </span>

                <h3>

                    Warriors
                    <b>VS</b>
                    Panthers

                </h3>

                <p>

                    <i class="fa-solid fa-location-dot"></i>
                    Community Court

                </p>

            </div>


            <div class="schedule-time">

                <strong>07:00 PM</strong>
                <span>Monday</span>

            </div>


            <a href="pages/schedule.php"
               class="details-btn">

                Details

            </a>

        </div>


        <!-- MATCH 3 -->

        <div class="schedule-home-card">

            <div class="date-box">

                <strong>27</strong>
                <span>AUG</span>

            </div>


            <div class="schedule-match">

                <span>
                    🏏 CRICKET
                </span>

                <h3>

                    Ahmedabad Kings
                    <b>VS</b>
                    Gujarat Stars

                </h3>

                <p>

                    <i class="fa-solid fa-location-dot"></i>
                    Local Cricket Ground

                </p>

            </div>


            <div class="schedule-time">

                <strong>05:00 PM</strong>
                <span>Wednesday</span>

            </div>


            <a href="pages/schedule.php"
               class="details-btn">

                Details

            </a>

        </div>

    </div>

</div>


</section>

<!-- =====================================================
     STANDINGS
===================================================== -->

<section class="standings-home-section"
         id="standings">


<div class="container">

    <div class="section-heading">

        <div>

            <span class="section-label">

                <i class="fa-solid fa-ranking-star"></i>
                LEAGUE TABLE

            </span>

            <h2>
                Top <span>Standings</span>
            </h2>

            <p>
                Current football league rankings.
            </p>

        </div>


        <a href="pages/standing.php"
           class="view-link">

            Full Table

            <i class="fa-solid fa-arrow-right"></i>

        </a>

    </div>


    <div class="standings-table">


        <!-- TABLE HEADER -->

        <div class="table-row table-header">

            <span>#</span>
            <span>TEAM</span>
            <span>MP</span>
            <span>W</span>
            <span>D</span>
            <span>L</span>
            <span>PTS</span>

        </div>


        <!-- TEAM 1 -->

        <div class="table-row">

            <span class="rank-number first">
                1
            </span>

            <span class="table-team">

                <span class="table-logo">
                    E
                </span>

                Eagles FC

            </span>

            <span>8</span>
            <span>6</span>
            <span>1</span>
            <span>1</span>

            <strong>19</strong>

        </div>


        <!-- TEAM 2 -->

        <div class="table-row">

            <span class="rank-number">
                2
            </span>

            <span class="table-team">

                <span class="table-logo red">
                    T
                </span>

                Tigers United

            </span>

            <span>8</span>
            <span>5</span>
            <span>1</span>
            <span>2</span>

            <strong>16</strong>

        </div>


        <!-- TEAM 3 -->

        <div class="table-row">

            <span class="rank-number">
                3
            </span>

            <span class="table-team">

                <span class="table-logo green">
                    P
                </span>

                Panthers FC

            </span>

            <span>8</span>
            <span>4</span>
            <span>2</span>
            <span>2</span>

            <strong>14</strong>

        </div>


        <!-- TEAM 4 -->

        <div class="table-row">

            <span class="rank-number">
                4
            </span>

            <span class="table-team">

                <span class="table-logo orange">
                    W
                </span>

                Warriors FC

            </span>

            <span>8</span>
            <span>3</span>
            <span>2</span>
            <span>3</span>

            <strong>11</strong>

        </div>

    </div>

</div>


</section>

<!-- =====================================================
     CALL TO ACTION
===================================================== -->

<section class="home-cta">

<div class="container">

    <div class="cta-content">

        <span>
            READY FOR THE NEXT MATCH?
        </span>

        <h2>
            Support Your
            <strong>Local Team.</strong>
        </h2>

        <p>
            Stay connected with your local sports
            community and never miss a match.
        </p>

        <a href="pages/teams.php"
           class="hero-btn primary-btn">

            Explore Teams

            <i class="fa-solid fa-arrow-right"></i>

        </a>

    </div>

</div>


</section>

<!-- =====================================================
     FOOTER
===================================================== -->

<?php
require_once 'includes/footer.php';
?>
